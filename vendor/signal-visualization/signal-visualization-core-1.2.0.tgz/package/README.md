# @signal-visualization/core

## C++/Qt binary realtime input

Core `1.2.0` provides an optional `@signal-visualization/core/binary` subpath. It decodes native SVB1 messages, the current packed 36-byte little-endian `0x1122AABB` backend format, and its legacy 28-byte variant into zero-copy `Float32Array` views without putting transport ownership inside the renderer. The current backend header's `MinValue` and `MaxValue` drive Spectrum bounds and Waterfall color normalization in Core.

```ts
import { applySignalBinaryFrame, decodeSignalBinaryFrame } from '@signal-visualization/core/binary'

socket.binaryType = 'arraybuffer'
socket.onmessage = ({ data }) => {
  if (data instanceof ArrayBuffer) {
    applySignalBinaryFrame(chart, decodeSignalBinaryFrame(data))
  }
}
```

See `docs/BINARY_PROTOCOL_V1.md` in the repository for the exact 48-byte header and Qt/C++ encoder.

Backend DataType values remain business-owned and are supplied when decoding. One backend Spectrum message produces both a Spectrum snapshot and a Waterfall row.

```ts
import { decodeSignalBinaryFrames } from '@signal-visualization/core/binary'

const frames = decodeSignalBinaryFrames(data, {
  backendDataTypes: { spectrum: 5, constellation: 6 },
})
```

Framework-agnostic TypeScript and WebGL2 Spectrum, Waterfall, Constellation, Waveform, and Multi Chart visualization SDK.

```ts
import { SignalChart } from '@signal-visualization/core'

const chart = new SignalChart('#chart', { type: 'spectrum' })
chart.setData({
  startFrequency: 100e6,
  frequencyStep: 25e3,
  values: new Float32Array(8192),
})
```

Waterfall uses a fixed-capacity GPU texture ring. Constellation uses a bounded VBO persistence ring. Waveform provides one/two-channel Time/Amplitude rendering through the shared internal LineRenderer. Requires WebGL2 and `ResizeObserver`; call `dispose()` when the owner unmounts.

Core `1.2.0` adds ranked/fixed/delta markers, selected-band power and occupied-bandwidth measurements, SDK-owned right-rail trace controls, and Waterfall freeze/cursor/history snapshots for replay. Existing `setData()` / `appendData()` calls and binary wire layouts remain compatible.

Explicitly owned `SignalChartLinkGroup` instances provide loop-free Spectrum/Waterfall frequency View, Crosshair, and Selection synchronization. Charts automatically leave their group during disposal.
