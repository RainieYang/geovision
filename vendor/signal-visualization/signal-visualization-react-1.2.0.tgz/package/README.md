# @signal-visualization/react

React lifecycle adapter for `@signal-visualization/core` with discriminated Spectrum, Waterfall, Constellation, and Waveform Props.

```tsx
import { SignalChart, useSignalChart } from '@signal-visualization/react'

<SignalChart option={{ type: 'spectrum' }} data={data} style={{ height: 480 }} />

const { chartRef, appendData } = useSignalChart()
<SignalChart ref={chartRef} option={{ type: 'waterfall' }} style={{ height: 480 }} />
appendData(frame)
```

The adapter creates Core only after the container commits, maps `option` and `data` changes without rebuilding the instance, and disposes Core on unmount. Waterfall event streams use the synchronous, non-queuing `appendData()` command rather than React state. Development StrictMode intentionally calls `onReady` for each committed instance. The module is safe to import during SSR; WebGL initialization happens only in the client effect.

`option.type` is required and selects the corresponding `data` type. Changing it calls Core `setOption()` and hot-switches the renderer while preserving the React component, Core facade, container, and Canvas.

React `1.2.0` re-exports `SignalChartLinkGroup`. Join Core instances from `onReady` or through `SignalChartHandle.link()`; Core synchronizes frequency View/Crosshair/Selection state without routing pointer updates through React state. The handle also exposes peak search, selected-band measurement, and Waterfall freeze/cursor/history commands.
