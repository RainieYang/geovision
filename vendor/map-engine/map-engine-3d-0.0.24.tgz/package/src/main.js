﻿import "./style.css";
import "./polyfills/qtWebEngine";
import MapEngine from "./index";
import { registerQtMapBridge } from "./bridge/QtMapBridge";

const query = new URLSearchParams(window.location.search);
const requestedCenter = query.get("center")?.split(",").map(Number);
const defaultCenter = requestedCenter?.length === 2 && requestedCenter.every(Number.isFinite)
  ? requestedCenter
  : [121.4737, 31.2304];
const zoomQuery = query.get("zoom");
const requestedZoom = zoomQuery === null ? Number.NaN : Number(zoomQuery);
const defaultZoom = Number.isFinite(requestedZoom) ? requestedZoom : 10;
const vectorServiceUrl = query.get("vectorService") ||
  `${window.location.protocol}//${window.location.hostname}:8080`;
const replayDemoEnabled = query.get("replayDemo") === "1";

window.MapEngine = MapEngine;
bootstrap();

async function bootstrap() {
  const map = await MapEngine.create("map", {
    mode: "2d",
    center2d: defaultCenter,
    zoom2d: defaultZoom,
    baseMapProvider2d: "auto",
    localVectorServiceUrl: vectorServiceUrl,
    baseMapLanguage: "en",
    ...(replayDemoEnabled ? { preserveViewOnSwitch3d: true } : {}),
    controls: {
      mapToolbar: true,
      featureToolbar: false,
      replayTimeline: {
        enabled: true,
        speeds: [1, 2, 4, 8],
        autoHide: true,
      },
    },
  });

  window.map = map;
  window.QtMapBridge = registerQtMapBridge(map);

  if (replayDemoEnabled) {
    const startTime = Date.now();
    map.loadReplay({
      initialState: {
        version: 1,
        view: { center: defaultCenter, zoom: defaultZoom },
        layers: [],
        objects: [],
      },
      entities: [{
        id: "replay-demo-1",
        type: "marker",
        properties: { name: "Replay Demo" },
        track: true,
        samples: [
          { time: startTime, position: [defaultCenter[0] - 0.08, defaultCenter[1] - 0.03, 100] },
          { time: startTime + 10000, position: [defaultCenter[0], defaultCenter[1] + 0.04, 300], properties: { heading: 350 } },
          { time: startTime + 20000, position: [defaultCenter[0] + 0.08, defaultCenter[1] - 0.02, 180], properties: { heading: 10 } },
        ],
      }],
    });
  }

  window.setInterval(() => {
    const viewer = window.map?.engine?.viewer;
    const imagery = [];
    if (viewer) {
      for (let index = 0; index < viewer.imageryLayers.length; index += 1) {
        const layer = viewer.imageryLayers.get(index);
        imagery.push({
          show: layer.show,
          alpha: layer.alpha,
          ready: layer.imageryProvider?.ready,
        });
      }
    }
    document.documentElement.dataset.mapEngineDebug = JSON.stringify({
      type: window.map?.getType?.(),
      provider: window.map?.engine?.options?.baseMapProvider,
      url: window.map?.engine?.options?.baseMapUrl,
      imagery,
      globeShow: viewer?.scene?.globe?.show,
      terrainReady: viewer?.terrainProvider?.ready,
      globeTilesLoaded: viewer?.scene?.globe?.tilesLoaded,
      tilesToRender: viewer?.scene?.globe?._surface?._tilesToRender?.length,
      contextLost: viewer?.scene?.context?._gl?.isContextLost?.(),
      renderRequested: viewer?.scene?._renderRequested,
      providerMinimumLevel: viewer?.imageryLayers?.length
        ? viewer.imageryLayers.get(0).imageryProvider?.minimumLevel
        : null,
      providerMaximumLevel: viewer?.imageryLayers?.length
        ? viewer.imageryLayers.get(0).imageryProvider?.maximumLevel
        : null,
    });
  }, 500);

  console.log("MapEngine automatic 2D basemap initialized", {
    type: map.getType(),
    provider: map.options.baseMapProvider2d,
    status: map.options.baseMapStatus2d,
    hasQtMapBridge: Boolean(window.QtMapBridge),
  });
}
