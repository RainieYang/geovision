﻿import OpenLayersMap from "../engine2d/OpenLayersMap";
import CesiumMap from "../engine3d/CesiumMap";
import AnimationEngine from "../animation/AnimationEngine";
import MapControls from "../control/MapControls";
import DrawManager from "../draw/DrawManager";
import FenceManager from "../fence/FenceManager";
import MeasureManager from "../measure/MeasureManager";
import TrackManager from "../track/TrackManager";
import ClusterManager from "../cluster/ClusterManager";
import PlotManager from "../plot/PlotManager";
import RadarManager from "../radar/RadarManager";
import HeatmapManager from "../heatmap/HeatmapManager";
import ReplayEngine from "../replay/ReplayEngine";
import { sampleTemporalObjects } from "../temporal/TemporalState";
import TrackLayerRuntime from "../track-layer/TrackLayerRuntime";
import { createFeatureCollection, getGeometryCenter } from "../draw/geojson";

export default class MapEngine {
  constructor(options = {}) {
    this.options = options;
    this.type = options.type === "3d" ? "3d" : "2d";
    this.engine = this.createEngine(this.type);
    this.controls = null;
    this.drawManager = null;
    this.fenceManager = null;
    this.measureManager = null;
    this.trackManager = null;
    this.clusterManager = null;
    this.plotManager = null;
    this.radarManager = null;
    this.heatmapManager = null;
    this.drawStore = createFeatureCollection();
    this.measureStore = createFeatureCollection();
    this.plotStore = createFeatureCollection();
    this.radarStore = { type: "RadarCollection", radars: [] };
    this.heatmapStore = { type: "HeatmapCollection", visible: true, options: { ...(options.heatmap || {}) }, points: [] };
    this.trackStore = null;
    this.clusterStore = {
      enabled: Boolean(options.cluster?.enabled),
      options: { ...(options.cluster || {}) },
    };
    this.selectedDrawingId = null;
    this.selectedPlotId = null;
    this.localEvents = new Map();
    this.markerStore = new Map();
    this.compatObjects = new Map();
    this.compatLayers = new Map();
    this.temporalStore = [];
    this.runtimeTracks = [];
    this.layerGroups = new Map();
    this.replayEngine = new ReplayEngine(this);
    this.trackLayerRuntime = new TrackLayerRuntime(this);
    this.animationEngine = new AnimationEngine(this);
    this.last3dViewState = null;
  }

  createEngine(type) {
    const engineOptions = this.createEngineOptions(type);
    return type === "3d" ? new CesiumMap(engineOptions) : new OpenLayersMap(engineOptions);
  }

  createEngineOptions(type) {
    if (type === "2d") {
      const center = this.options.preserveViewOnSwitch
        ? this.options.center
        : this.options.center2d || this.options.center;
      const zoom = this.options.preserveViewOnSwitch
        ? this.options.zoom
        : this.options.zoom2d ?? this.options.zoom;

      return {
        ...this.options,
        mapEngine: this,
        type,
        center,
        zoom,
        baseMapProvider: this.options.baseMapProvider2d || this.options.baseMapProvider || "tianditu",
        baseMapType: this.options.baseMapType2d || "vec",
        baseMapUrl: this.options.baseMapUrl2d || this.options.baseMapUrl,
        minimumLevel: this.options.minimumLevel2d ?? this.options.minimumLevel,
        maximumLevel: this.options.maximumLevel2d ?? this.options.maximumLevel,
        bounds: this.options.bounds2d || this.options.bounds,
        overlayLayers: this.options.overlayLayers2d || this.options.overlayLayers || [],
      };
    }

    const center = this.options.preserveViewOnSwitch
      ? this.options.center
      : this.options.center3d || this.options.center;
    const zoom = this.options.preserveViewOnSwitch
      ? this.options.zoom
      : this.options.zoom3d ?? this.options.zoom;

    return {
      ...this.options,
      mapEngine: this,
      type,
      center,
      zoom,
      baseMapProvider: this.options.baseMapProvider3d || this.options.baseMapProvider || "tianditu",
      baseMapType: this.options.baseMapType3d || this.options.baseMapType || "img",
      baseMapUrl: this.options.baseMapUrl3d || this.options.baseMapUrl,
      minimumLevel: this.options.minimumLevel3d ?? this.options.minimumLevel,
      maximumLevel: this.options.maximumLevel3d ?? this.options.maximumLevel,
      bounds: this.options.bounds3d || this.options.bounds,
      terrainProvider: this.options.terrainProvider3d || this.options.terrainProvider,
      terrainUrl: this.options.terrainUrl3d || this.options.terrainUrl,
      overlayLayers: this.options.overlayLayers3d || this.options.overlayLayers || [],
    };
  }

  init() {
    const result = this.engine.init();
    this.initDrawManager();
    this.initFenceManager();
    this.initMeasureManager();
    this.initTrackManager();
    this.initClusterManager();
    this.initPlotManager();
    this.initRadarManager();
    this.initHeatmapManager();
    this.initControls();
    return result;
  }

  initDrawManager() {
    this.drawManager?.destroy();
    this.drawManager = new DrawManager(this, this.engine, this.options.draw || {});
    this.drawManager.importGeoJSON(this.drawStore);
  }

  initFenceManager() {
    if (!this.fenceManager) {
      this.fenceManager = new FenceManager(this, this.options.fence || {});
    }
  }

  initMeasureManager() {
    this.measureManager?.destroy();
    this.measureManager = new MeasureManager(this, this.engine, this.options.measure || {});
    this.measureManager.importGeoJSON(this.measureStore);
  }

  initTrackManager() {
    this.trackManager?.destroy();
    this.trackManager = new TrackManager(this, this.engine, this.options.track || {});
    if (this.trackStore?.track) this.trackManager.restoreState(this.trackStore);
  }

  initClusterManager() {
    this.clusterManager?.destroy();
    this.clusterManager = new ClusterManager(this, this.engine, {
      ...(this.options.cluster || {}),
      ...(this.clusterStore?.options || {}),
      enabled: this.clusterStore?.enabled ?? this.options.cluster?.enabled,
    });
  }

  initPlotManager() {
    this.plotManager?.destroy();
    this.plotManager = new PlotManager(this, this.engine, this.options.plot || {});
    this.plotManager.importGeoJSON(this.plotStore);
  }

  initRadarManager() {
    this.radarManager?.destroy();
    this.radarManager = new RadarManager(this, this.engine, this.options.radar || {});
    this.radarManager.importRadars(this.radarStore);
  }

  initHeatmapManager() {
    this.heatmapManager?.destroy();
    this.heatmapManager = new HeatmapManager(this, this.engine, {
      ...(this.options.heatmap || {}),
      ...(this.heatmapStore?.options || {}),
      visible: this.heatmapStore?.visible ?? this.options.heatmap?.visible,
    });
    this.heatmapManager.importHeatmap(this.heatmapStore);
  }

  initControls() {
    if (this.options.controls === false) return;
    const controlOptions = this.options.controls || {};
    const replayTimelineEnabled = controlOptions.replayTimeline === true
      || controlOptions.replayTimeline?.enabled === true;
    if (controlOptions.mapToolbar === false && !replayTimelineEnabled) return;

    this.controls?.unmount();
    this.controls = new MapControls(this, controlOptions);
    this.controls.mount();
  }

  getType() {
    return this.type;
  }

  getViewState() {
    return this.engine?.getViewState?.() || null;
  }

  switchView(type) {
    const nextType = type || (this.type === "3d" ? "2d" : "3d");
    if (nextType === this.type) return this;

    const viewState = this.getViewState();
    if (this.type === "3d" && viewState) {
      this.last3dViewState = viewState;
    }
    this.drawStore = this.exportGeoJSON();
    this.measureStore = this.exportMeasurements();
    this.plotStore = this.exportPlots();
    this.radarStore = this.exportRadars();
    this.heatmapStore = this.exportHeatmap();
    this.trackStore = this.getTrackState();
    this.clusterStore = this.getClusterState();
    this.controls?.unmount();
    this.clusterManager?.destroy();
    this.clusterManager = null;
    this.plotManager?.destroy();
    this.plotManager = null;
    this.radarManager?.destroy();
    this.radarManager = null;
    this.heatmapManager?.destroy();
    this.heatmapManager = null;
    this.trackManager?.destroy();
    this.trackManager = null;
    this.measureManager?.destroy();
    this.measureManager = null;
    this.drawManager?.destroy();
    this.drawManager = null;
    this.engine?.destroy();

    this.type = nextType;
    this.options = {
      ...this.options,
      ...this.createSwitchViewOptions(nextType, viewState),
      type: nextType,
    };
    this.engine = this.createEngine(nextType);
    try {
      this.engine.init();
      this.initDrawManager();
      this.initFenceManager();
      this.initMeasureManager();
      this.initTrackManager();
      this.initClusterManager();
      this.initPlotManager();
      this.initRadarManager();
      this.initHeatmapManager();
      this.replayMarkers();
      this.replaySpatialObjects();
      this.refreshCluster();
    } finally {
      this.initControls();
    }

    return this;
  }

  createSwitchViewOptions(nextType, viewState) {
    if (nextType === "3d" && this.options.preserveViewOnSwitch3d === false) {
      const last3d = this.last3dViewState;
      if (last3d?.center && Number.isFinite(Number(last3d.zoom))) {
        return {
          center: [
            Number(last3d.center[0]),
            Number(last3d.center[1]),
          ],
          zoom: Number(last3d.zoom),
          cameraHeight: last3d.cameraHeight,
          heading: last3d.heading ?? 0,
          pitch: last3d.pitch ?? -Math.PI / 2,
          roll: last3d.roll ?? 0,
          preserveViewOnSwitch: true,
        };
      }

      return {
        preserveViewOnSwitch: false,
        cameraHeight: undefined,
      };
    }

    if (nextType === "2d" && this.options.preserveViewOnSwitch2d === false) {
      return {
        preserveViewOnSwitch: false,
      };
    }

    if (!viewState?.center || !Number.isFinite(Number(viewState.zoom))) {
      return {};
    }

    const center = [Number(viewState.center[0]), Number(viewState.center[1])];
    const zoom = Number(viewState.zoom);
    if (!Number.isFinite(center[0]) || !Number.isFinite(center[1])) return {};

    if (nextType === "3d") {
      const last3d = this.last3dViewState;
      return {
        center,
        zoom,
        cameraHeight: undefined,
        heading: last3d?.heading ?? viewState.heading ?? 0,
        pitch: last3d?.pitch ?? viewState.pitch ?? -Math.PI / 2,
        roll: last3d?.roll ?? viewState.roll ?? 0,
        preserveViewOnSwitch: true,
      };
    }

    return {
      center,
      zoom: Math.max(zoom, getConfiguredMinZoom2d(this.options)),
      preserveViewOnSwitch: true,
    };
  }

  zoomIn() {
    return this.engine?.zoomIn?.();
  }

  zoomOut() {
    return this.engine?.zoomOut?.();
  }

  resetView() {
    return this.engine?.resetView?.();
  }

  getCameraOrientation() {
    return this.engine?.getCameraOrientation?.() || null;
  }

  setCameraOrientation(options) {
    return this.engine?.setCameraOrientation?.(options) || null;
  }

  resetCameraOrientation() {
    return this.engine?.resetCameraOrientation?.() || null;
  }

  centerAt(position, options) {
    return this.engine?.centerAt?.(position, options) || null;
  }

  focusOnTarget(id, options) {
    return this.engine?.focusOnTarget?.(id, options) || null;
  }

  setOcclusion3d(options) {
    return this.engine?.setOcclusion3d?.(options) || null;
  }

  getOcclusion3d() {
    return this.engine?.getOcclusion3d?.() || null;
  }

  getStatus() {
    return this.engine?.getStatus?.() || {};
  }

  setBaseLayer(options) {
    return this.engine?.setBaseLayer(options);
  }

  setBaseMapStyle(name) {
    return this.engine?.setBaseMapStyle?.(name) || Promise.resolve(false);
  }

  setBaseMapLanguage(language) {
    const baseMapLanguage = String(language || "zh").toLowerCase() === "en" ? "en" : "zh";
    this.options.baseMapLanguage = baseMapLanguage;
    return this.engine?.setBaseMapLanguage?.(baseMapLanguage) || Promise.resolve({ applied: false, baseMapLanguage });
  }

  getBaseMapPerformanceStats(options) {
    return this.engine?.getBaseMapPerformanceStats?.(options) || null;
  }

  waitForBaseMapReady(options) {
    return this.engine?.waitForBaseMapReady?.(options) || Promise.resolve(true);
  }

  addLayer(options) {
    const layer = this.engine?.addLayer(options);
    if (options?.id) this.compatLayers.set(String(options.id), { ...options, id: String(options.id) });
    return layer;
  }

  addLayers(layers) {
    return this.engine?.addLayers(layers);
  }

  removeLayer(id) {
    this.compatLayers.delete(String(id));
    return this.engine?.removeLayer(id);
  }

  getLayer(id) {
    return this.engine?.getLayer(id);
  }

  getNativeLayer(id) {
    return this.engine?.getNativeLayer(id);
  }

  getLayerInfo(id) {
    return this.engine?.getLayerInfo(id);
  }

  listLayers() {
    return this.engine?.listLayers();
  }

  hasLayer(id) {
    return this.engine?.hasLayer(id);
  }

  showLayer(id) {
    return this.engine?.showLayer(id);
  }

  hideLayer(id) {
    return this.engine?.hideLayer(id);
  }

  setLayerVisible(id, visible) {
    return this.engine?.setLayerVisible(id, visible);
  }

  setLayerOpacity(id, opacity) {
    return this.engine?.setLayerOpacity(id, opacity);
  }

  setLayerZIndex(id, zIndex) {
    return this.engine?.setLayerZIndex(id, zIndex);
  }

  clearLayers() {
    return this.engine?.clearLayers();
  }

  clearOverlayLayers() {
    return this.engine?.clearOverlayLayers?.();
  }

  clearBaseLayers() {
    return this.engine?.clearBaseLayers();
  }

  getBaseLayerIds() {
    return this.engine?.getBaseLayerIds();
  }

  getLayerManager() {
    return this.engine?.getLayerManager();
  }

  on(eventName, callback) {
    if (this.isLocalEvent(eventName)) {
      if (!this.localEvents.has(eventName)) this.localEvents.set(eventName, []);
      this.localEvents.get(eventName).push(callback);
      return () => this.off(eventName, callback);
    }

    return this.engine?.on(eventName, callback);
  }

  off(eventName, callback) {
    if (this.isLocalEvent(eventName)) {
      const callbacks = this.localEvents.get(eventName);
      if (!callbacks) return;
      const index = callbacks.indexOf(callback);
      if (index > -1) callbacks.splice(index, 1);
      return;
    }

    return this.engine?.off(eventName, callback);
  }

  isLocalEvent(eventName) {
    return (
      eventName?.startsWith("draw:") ||
      eventName === "state:changed" ||
      eventName === "object:created" ||
      eventName === "object:updated" ||
      eventName === "object:removed" ||
      eventName?.startsWith("fence:") ||
      eventName?.startsWith("measure:") ||
      eventName?.startsWith("track:") ||
      eventName?.startsWith("cluster:") ||
      eventName?.startsWith("plot:") ||
      eventName?.startsWith("radar:") ||
      eventName?.startsWith("heatmap:") ||
      eventName?.startsWith("replay:") ||
      eventName?.startsWith("runtime-track:") ||
      eventName?.startsWith("animation:") ||
      eventName?.startsWith("temporal:")
    );
  }

  emit(eventName, data) {
    return this.emitLocal(eventName, data);
  }

  emitLocal(eventName, data) {
    this.syncStateForLocalEvent(eventName, data);
    const callbacks = this.localEvents.get(eventName);
    if (callbacks) callbacks.forEach((callback) => callback(data));
  }

  syncStateForLocalEvent(eventName, data) {
    if (eventName === "draw:create" || eventName === "draw:update") {
      const object = this.featureToSpatialObject(data);
      if (!object) return;
      this.compatObjects.set(object.id, object);
      this.emitStateObjectEvent(eventName === "draw:create" ? "object:created" : "object:updated", object);
      this.emitStateChanged();
      return;
    }

    if (eventName === "draw:delete") {
      const object = this.featureToSpatialObject(data);
      if (!object) return;
      this.compatObjects.delete(object.id);
      this.emitStateObjectEvent("object:removed", object);
      this.emitStateChanged();
      return;
    }

    if (eventName === "draw:clear") {
      const removed = Array.from(this.compatObjects.values()).filter(
        (object) => object.properties?.source === "draw"
      );
      removed.forEach((object) => {
        this.compatObjects.delete(object.id);
        this.emitStateObjectEvent("object:removed", object);
      });
      this.emitStateChanged();
    }
  }

  emitStateObjectEvent(eventName, object) {
    const callbacks = this.localEvents.get(eventName);
    if (!callbacks) return;
    callbacks.forEach((callback) => callback({ id: object.id, object }));
  }

  emitStateChanged() {
    const callbacks = this.localEvents.get("state:changed");
    if (!callbacks) return;
    callbacks.forEach((callback) => callback(this.getState()));
  }

  setState(state = {}) {
    this.clearMarkers();
    this.clearOverlayLayers();

    (state.layers || []).forEach((layer) => this.addLayer(layer));
    this.temporalStore = Array.isArray(state.temporal) ? [...state.temporal] : [];
    this.runtimeTracks = Array.isArray(state.tracks) ? [...state.tracks] : [];
    this.layerGroups = new Map((state.groups || []).map((group) => [String(group.id), { ...group, id: String(group.id) }]));
    (state.objects || []).forEach((object) => {
      this.compatObjects.set(object.id, { ...object });
      if (object.type === "marker" || object.type === "text") {
        this.engine?.addMarker?.(this.spatialObjectToMarker(object));
      } else {
        this.engine?.renderObject?.(object);
      }
    });

    if (state.view) this.setView?.(state.view);
    this.emitStateChanged();
    return this;
  }

  getState() {
    const objects = new Map(this.compatObjects);
    this.listMarkers().forEach((marker) => {
      const object = this.markerToSpatialObject(marker);
      if (object) objects.set(object.id, object);
    });

    return {
      version: Date.now(),
      objects: Array.from(objects.values()).filter(Boolean),
      layers: this.listLayers?.() || Array.from(this.compatLayers.values()),
      temporal: [...this.temporalStore],
      tracks: [...this.runtimeTracks],
      groups: Array.from(this.layerGroups.values()),
      view: this.getViewState?.() || {
        center: this.options.center || [104.0668, 30.5728],
        zoom: this.options.zoom ?? 10,
      },
    };
  }

  applyPatch(patch = {}) {
    (patch.remove || []).forEach((id) => {
      const object = this.compatObjects.get(String(id));
      this.compatObjects.delete(String(id));
      this.removeMarker(String(id));
      this.engine?.removeObject?.(String(id));
      if (object) this.emitStateObjectEvent("object:removed", object);
    });

    (patch.add || []).forEach((object) => {
      const result = this.addSpatialObject(object);
      if (result) this.emitStateObjectEvent("object:created", object);
    });
    (patch.update || []).forEach((object) => {
      const result = this.updateSpatialObject(object);
      if (result) this.emitStateObjectEvent("object:updated", this.compatObjects.get(object.id) || object);
    });

    (patch.addLayers || []).forEach((layer) => this.addLayer(layer));
    (patch.updateLayers || []).forEach((layer) => {
      if (typeof layer.visible === "boolean") this.setLayerVisible(layer.id, layer.visible);
      if (typeof layer.opacity === "number") this.setLayerOpacity(layer.id, layer.opacity);
      this.compatLayers.set(String(layer.id), { ...(this.compatLayers.get(String(layer.id)) || {}), ...layer });
    });
    (patch.removeLayers || []).forEach((id) => this.removeLayer(id));
    if (Array.isArray(patch.removeTemporal)) {
      const removeIds = new Set(patch.removeTemporal.map(String));
      this.temporalStore = this.temporalStore.filter((object) => !removeIds.has(String(object.id)));
    }
    if (Array.isArray(patch.addTemporal)) this.temporalStore.push(...patch.addTemporal);
    if (Array.isArray(patch.updateTemporal)) {
      patch.updateTemporal.forEach((object) => {
        const index = this.temporalStore.findIndex((item) => String(item.id) === String(object.id));
        if (index >= 0) this.temporalStore[index] = { ...this.temporalStore[index], ...object };
      });
    }
    if (Array.isArray(patch.removeTracks)) {
      const removeIds = new Set(patch.removeTracks.map(String));
      this.runtimeTracks = this.runtimeTracks.filter((track) => !removeIds.has(String(track.id)));
    }
    if (Array.isArray(patch.addTracks)) this.runtimeTracks.push(...patch.addTracks);
    if (Array.isArray(patch.updateTracks)) {
      patch.updateTracks.forEach((track) => {
        const index = this.runtimeTracks.findIndex((item) => String(item.id) === String(track.id));
        if (index >= 0) this.runtimeTracks[index] = { ...this.runtimeTracks[index], ...track };
      });
    }
    (patch.removeGroups || []).forEach((id) => this.layerGroups.delete(String(id)));
    (patch.addGroups || []).forEach((group) => this.layerGroups.set(String(group.id), { ...group, id: String(group.id) }));
    (patch.updateGroups || []).forEach((group) => {
      this.layerGroups.set(String(group.id), { ...(this.layerGroups.get(String(group.id)) || {}), ...group, id: String(group.id) });
    });

    if (patch.view) this.setView?.(patch.view);
    this.emitLocal("state:changed", this.getState());
    return this.getState();
  }

  exportSnapshot() {
    return {
      type: "MapEngineSnapshot",
      engineType: this.type,
      exportedAt: new Date().toISOString(),
      state: this.getState(),
    };
  }

  importSnapshot(snapshot = {}) {
    return this.setState(snapshot.state || snapshot);
  }

  enterReplay(options) {
    return this.replayEngine.enterReplay(options);
  }

  exitReplay(options) {
    return this.replayEngine.exitReplay(options);
  }

  loadReplay(data) {
    return this.replayEngine.loadReplay(data);
  }

  seek(time) {
    return this.replayEngine.seek(time);
  }

  play(options) {
    return this.replayEngine.play(options);
  }

  pause() {
    return this.replayEngine.pause();
  }

  stop() {
    return this.replayEngine.stop();
  }

  setSpeed(speed) {
    return this.replayEngine.setSpeed(speed);
  }

  setLoop(loop) {
    return this.replayEngine.setLoop(loop);
  }

  getReplayState() {
    return this.replayEngine.getState();
  }

  setTemporalState(temporal = []) {
    return this.applyPatch({
      removeTemporal: this.temporalStore.map((object) => object.id),
      addTemporal: temporal,
    });
  }

  applyTemporalAt(time) {
    const sampled = sampleTemporalObjects(this.temporalStore, time);
    if (!sampled.length) return [];
    const existingIds = new Set(this.getState().objects.map((object) => object.id));
    this.applyPatch({
      add: sampled.filter((object) => !existingIds.has(object.id)),
      update: sampled.filter((object) => existingIds.has(object.id)),
    });
    this.emitLocal("temporal:sample", { time, objects: sampled });
    return sampled;
  }

  addTrack(track) {
    return this.trackLayerRuntime.addTrack(track);
  }

  updateTrack(id, patch) {
    if (typeof id === "object") return this.trackLayerRuntime.updateTrack(id.id, id);
    return this.trackLayerRuntime.updateTrack(id, patch);
  }

  appendTrackPoint(id, point, options) {
    return this.trackLayerRuntime.appendTrackPoint(id, point, options);
  }

  removeTrack(id) {
    return this.trackLayerRuntime.removeTrack(id);
  }

  clearTracks() {
    return this.trackLayerRuntime.clearTracks();
  }

  getTrack(id) {
    return this.trackLayerRuntime.getTrack(id);
  }

  listTracks() {
    return this.trackLayerRuntime.listTracks();
  }

  moveObject(id, options) {
    return this.animationEngine.moveTo(id, options);
  }

  blinkObject(id, options) {
    return this.animationEngine.blink(id, options);
  }

  pulseCoverage(id, options) {
    return this.animationEngine.pulseCoverage(id, options);
  }

  stopAnimation(id) {
    return this.animationEngine.stopAnimation(id);
  }

  clearAnimations() {
    return this.animationEngine.clearAnimations();
  }

  addHeatmapLayer(id, points = [], options = {}) {
    const object = {
      id: String(id),
      type: "custom",
      geometry: { type: "MultiPoint", coordinates: points.map((point) => point.position || point.coordinates || point) },
      style: { renderer: "heatmap", radius: options.radius ?? 24, opacity: options.opacity ?? 0.65 },
      properties: { ...(options.properties || {}), runtimeType: "heatmap", points },
    };
    this.applyPatch({ add: [object] });
    return object;
  }

  addCoverage(id, coverage = {}) {
    const object = createRuntimeCoverageObject(id, coverage);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateCoverage(id, coverage = {}) {
    const object = createRuntimeCoverageObject(id, coverage);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeCoverage(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addSector(id, sector = {}) {
    const object = createRuntimeSectorObject(id, sector);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateSector(id, sector = {}) {
    const object = createRuntimeSectorObject(id, sector);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeSector(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addDirectionLine(id, line = {}) {
    const object = createRuntimeDirectionLineObject(id, line);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateDirectionLine(id, line = {}) {
    const object = createRuntimeDirectionLineObject(id, line);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeDirectionLine(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addLayerGroup(group = {}) {
    this.applyPatch({ addGroups: [group] });
    return this.layerGroups.get(String(group.id));
  }

  updateLayerGroup(id, patch = {}) {
    const group = typeof id === "object" ? id : { ...patch, id };
    this.applyPatch({ updateGroups: [group] });
    return this.layerGroups.get(String(group.id));
  }

  removeLayerGroup(id) {
    this.applyPatch({ removeGroups: [id] });
    return true;
  }

  setLayerGroupVisible(id, visible) {
    const group = this.layerGroups.get(String(id));
    if (!group) return false;
    this.applyPatch({
      updateGroups: [{ id, visible }],
      updateLayers: (group.layerIds || []).map((layerId) => ({ id: layerId, visible })),
      update: (group.objectIds || []).map((objectId) => ({ id: objectId, properties: { hiddenByGroup: !visible } })),
    });
    return true;
  }

  listLayerGroups() {
    return Array.from(this.layerGroups.values());
  }

  queryFeatureAtPixel(pixel, options = {}) {
    return this.engine?.queryFeatureAtPixel?.(pixel, options) || null;
  }

  queryObjectsByBounds(bounds, options = {}) {
    return this.engine?.queryObjectsByBounds?.(bounds, options) || [];
  }

  queryObjectsByPoint(point, options = {}) {
    return this.engine?.queryObjectsByPoint?.(point, options) || [];
  }

  setView(view = {}) {
    this.engine?.setView?.(view);
    return this.getViewState();
  }

  flyTo(view = {}) {
    return this.engine?.flyTo?.(view);
  }

  resize() {
    return this.engine?.resize?.();
  }

  addSpatialObject(object = {}) {
    if (!object?.id) return null;
    this.compatObjects.set(object.id, { ...object });
    if (object.type === "marker" || object.type === "text") return this.addMarker(this.spatialObjectToMarker(object));
    return this.engine?.renderObject?.(object);
  }

  updateSpatialObject(object = {}) {
    if (!object?.id) return null;
    const previous = this.compatObjects.get(object.id) || {};
    const next = { ...previous, ...object, style: { ...(previous.style || {}), ...(object.style || {}) }, properties: { ...(previous.properties || {}), ...(object.properties || {}) } };
    this.compatObjects.set(object.id, next);
    if (next.type === "marker" || next.type === "text") return this.updateMarker(next.id, this.spatialObjectToMarker(next));
    return this.engine?.updateObject?.(next);
  }

  markerToSpatialObject(marker = {}) {
    if (!marker?.id) return null;
    return {
      id: marker.id,
      type: "marker",
      position: marker.position,
      style: {
        icon: marker.icon,
        iconWidth: marker.iconWidth,
        iconHeight: marker.iconHeight,
        iconAnchor: marker.iconAnchor,
        rotationDegrees: marker.rotationDegrees,
        rotationReference: marker.rotationReference,
        color: marker.color,
        label: marker.label,
      },
      properties: {
        ...(marker.data || {}),
        name: marker.name,
        popup: marker.popup,
        cluster: marker.cluster,
      },
    };
  }

  spatialObjectToMarker(object = {}) {
    return {
      id: object.id,
      name: object.properties?.name || object.id,
      position: object.position,
      icon: object.style?.icon,
      iconWidth: object.style?.iconWidth,
      iconHeight: object.style?.iconHeight,
      iconAnchor: object.style?.iconAnchor,
      rotationDegrees: object.style?.rotationDegrees,
      rotationReference: object.style?.rotationReference,
      color: object.style?.color,
      label: object.style?.label,
      popup: object.properties?.popup,
      cluster: object.properties?.cluster,
      data: object.properties || {},
    };
  }

  featureToSpatialObject(feature = {}) {
    const geometry = feature.geometry;
    const properties = feature.properties || {};
    const id = properties.id || feature.id;
    if (!id || !geometry) return null;

    const base = {
      id,
      geometry,
      style: properties.style || {},
      properties: {
        ...properties,
        source: "draw",
        geojson: feature,
      },
    };

    if (geometry.type === "Point") {
      return {
        ...base,
        type: "marker",
        position: geometry.coordinates,
      };
    }

    if (geometry.type === "LineString") {
      return {
        ...base,
        type: "line",
        geometry: {
          coordinates: geometry.coordinates,
        },
      };
    }

    if (geometry.type === "Polygon") {
      return {
        ...base,
        type: "polygon",
        position: getGeometryCenter(geometry),
        geometry: {
          coordinates: geometry.coordinates,
        },
      };
    }

    return {
      ...base,
      type: "custom",
      position: getGeometryCenter(geometry),
    };
  }

  radarToSpatialObject(radar = {}) {
    if (!radar?.id) return null;
    return {
      id: radar.id,
      type: "circle",
      position: radar.position,
      style: {
        radius: radar.radius,
        strokeColor: radar.style?.strokeColor || "#22d3ee",
        fillColor: radar.style?.fillColor || "rgba(34, 211, 238, 0.16)",
      },
      properties: {
        ...radar,
        legacyType: "radar",
      },
    };
  }

  heatmapPointToSpatialObject(point = {}, options = {}) {
    if (!point?.id) return null;
    return {
      id: point.id,
      type: "custom",
      position: point.position,
      style: {
        renderer: "heatmap",
        weight: point.weight,
        ...(options || {}),
      },
      properties: {
        ...(point.data || {}),
        legacyType: "heatmap",
        weight: point.weight,
      },
    };
  }

  syncHeatmapObjects(points = [], options = {}) {
    Array.from(this.compatObjects.values()).forEach((object) => {
      if (object.properties?.legacyType === "heatmap") this.compatObjects.delete(object.id);
    });
    (points || []).forEach((point, index) => {
      const id = point.id || `heatmap-${index + 1}`;
      this.compatObjects.set(id, this.heatmapPointToSpatialObject({ ...point, id }, options));
    });
  }

  trackToSpatialObject(track = {}) {
    const points = track?.points || [];
    if (!track?.id || !Array.isArray(points) || !points.length) return null;
    const coordinates = points
      .map((point) => point.position || [point.lng, point.lat])
      .filter((position) => Array.isArray(position) && position.length >= 2);
    return {
      id: track.id,
      type: "line",
      geometry: { coordinates },
      style: {
        strokeColor: track.style?.strokeColor || "#f97316",
        strokeWidth: track.style?.strokeWidth || 3,
      },
      properties: {
        ...track,
        legacyType: "track",
      },
    };
  }

  addMarker(marker) {
    if (!marker?.id) {
      console.warn("MapEngine: marker.id is required");
      return null;
    }

    this.markerStore.set(marker.id, { ...marker });
    this.compatObjects.set(marker.id, this.markerToSpatialObject(marker));
    const result = this.engine.addMarker?.(marker);
    this.refreshCluster();
    return result;
  }

  addMarkers(markers = []) {
    if (!Array.isArray(markers)) return [];
    return markers.map((marker) => this.addMarker(marker)).filter(Boolean);
  }

  updateMarker(id, patch = {}) {
    if (!id || !this.markerStore.has(id)) return null;
    const next = { ...this.markerStore.get(id), ...patch, id };
    this.markerStore.set(id, next);
    this.compatObjects.set(id, this.markerToSpatialObject(next));
    const result = this.engine.updateMarker?.(id, next) || this.engine.addMarker?.(next);
    if (next.cluster !== false) this.refreshCluster();
    return result;
  }

  removeMarker(id) {
    this.markerStore.delete(id);
    this.compatObjects.delete(String(id));
    const result = this.engine.removeMarker?.(id);
    this.refreshCluster();
    return result;
  }

  removeMarkers(ids = []) {
    if (!Array.isArray(ids)) return [];
    return ids.map((id) => this.removeMarker(id));
  }

  getMarker(id) {
    return this.markerStore.get(id) || null;
  }

  hasMarker(id) {
    return this.markerStore.has(id);
  }

  listMarkers() {
    return Array.from(this.markerStore.values()).map((marker) => ({ ...marker }));
  }

  clearMarkers() {
    this.listMarkers().forEach((marker) => this.compatObjects.delete(marker.id));
    this.markerStore.clear();
    const result = this.engine.clearMarkers?.();
    this.refreshCluster();
    return result;
  }

  replayMarkers() {
    try {
      this.engine.addMarkers?.(this.listMarkers());
      this.refreshCluster();
    } catch (error) {
      console.warn("MapEngine: replay markers failed", error);
    }
  }

  replaySpatialObjects() {
    try {
      this.compatObjects.forEach((object, id) => {
        // Marker/Text 已由 replayMarkers() 恢复；这里只补齐扇形、边界线、
        // 轴线等静态空间对象，避免等待下一次业务数据更新才显示。
        if (!object || this.markerStore.has(String(id))) return;
        if (object.type === "marker" || object.type === "text") return;
        this.engine.renderObject?.(object);
      });
    } catch (error) {
      console.warn("MapEngine: replay spatial objects failed", error);
    }
  }

  enableCluster(options) {
    const state = this.clusterManager?.enable(options);
    this.clusterStore = state;
    return state;
  }

  disableCluster() {
    const state = this.clusterManager?.disable();
    this.clusterStore = state;
    return state;
  }

  isClusterEnabled() {
    return Boolean(this.clusterManager?.isEnabled());
  }

  setClusterOptions(options) {
    const state = this.clusterManager?.setOptions(options);
    this.clusterStore = state;
    return state;
  }

  refreshCluster() {
    const state = this.clusterManager?.refresh();
    if (state) this.clusterStore = state;
    return state;
  }

  getClusterState() {
    return this.clusterManager?.getState() || this.clusterStore || { enabled: false, options: {} };
  }

  getClusterManager() {
    return this.clusterManager;
  }

  drawCommandPost(options) {
    return this.plotManager?.drawCommandPost(options);
  }

  drawRoute(options) {
    return this.plotManager?.drawRoute(options);
  }

  drawAssemblyArea(options) {
    return this.plotManager?.drawAssemblyArea(options);
  }

  drawDefenseArea(options) {
    return this.plotManager?.drawDefenseArea(options);
  }

  drawAttackArrow(options) {
    return this.plotManager?.drawAttackArrow(options);
  }

  enablePlotSelect() {
    return this.plotManager?.enableSelect();
  }

  selectPlot(id) {
    return this.plotManager?.selectPlot(id);
  }

  unselectPlot() {
    return this.plotManager?.unselectPlot();
  }

  getSelectedPlot() {
    return this.plotManager?.getSelectedPlot() || null;
  }

  removePlot(id) {
    return this.plotManager?.removePlot(id);
  }

  removeSelectedPlot() {
    return this.plotManager?.removeSelectedPlot();
  }

  clearPlots() {
    this.plotManager?.clear();
    this.plotStore = createFeatureCollection();
    this.selectedPlotId = null;
  }

  listPlots() {
    return this.plotManager?.listPlots() || [];
  }

  updatePlotProperties(id, properties) {
    return this.plotManager?.updatePlotProperties(id, properties);
  }

  updateSelectedPlotProperties(properties) {
    return this.plotManager?.updateSelectedPlotProperties(properties);
  }

  exportPlots() {
    this.plotStore = this.plotManager?.exportGeoJSON() || this.plotStore;
    return this.plotStore;
  }

  importPlots(geojson) {
    this.plotStore = geojson || createFeatureCollection();
    return this.plotManager?.importGeoJSON(this.plotStore);
  }

  getPlotManager() {
    return this.plotManager;
  }

  addRadar(radar) {
    const result = this.radarManager?.addRadar(radar);
    if (radar?.id) this.compatObjects.set(radar.id, this.radarToSpatialObject(result || radar));
    return result;
  }

  addRadars(radars) {
    const result = this.radarManager?.addRadars(radars) || [];
    (result.length ? result : radars || []).forEach((radar) => {
      if (radar?.id) this.compatObjects.set(radar.id, this.radarToSpatialObject(radar));
    });
    return result;
  }

  removeRadar(id) {
    this.compatObjects.delete(String(id));
    return this.radarManager?.removeRadar(id);
  }

  clearRadars() {
    this.radarManager?.clearRadars();
    Array.from(this.compatObjects.values()).forEach((object) => {
      if (object.properties?.legacyType === "radar") this.compatObjects.delete(object.id);
    });
    this.radarStore = { type: "RadarCollection", radars: [] };
  }

  updateRadar(id, patch) {
    const result = this.radarManager?.updateRadar(id, patch);
    if (result?.id) this.compatObjects.set(result.id, this.radarToSpatialObject(result));
    return result;
  }

  getRadar(id) {
    return this.radarManager?.getRadar(id) || null;
  }

  listRadars() {
    return this.radarManager?.listRadars() || [];
  }

  startRadarScan(id) {
    return this.radarManager?.startRadarScan(id);
  }

  stopRadarScan(id) {
    return this.radarManager?.stopRadarScan(id);
  }

  setRadarScanAngle(id, angle) {
    return this.radarManager?.setRadarScanAngle(id, angle);
  }

  setRadarTargets(radarId, targets) {
    return this.radarManager?.setRadarTargets(radarId, targets);
  }

  addRadarTarget(radarId, target) {
    return this.radarManager?.addRadarTarget(radarId, target);
  }

  removeRadarTarget(radarId, targetId) {
    return this.radarManager?.removeRadarTarget(radarId, targetId);
  }

  clearRadarTargets(radarId) {
    return this.radarManager?.clearRadarTargets(radarId);
  }

  clearRadarTargetTrail(radarId, targetId) {
    return this.radarManager?.clearRadarTargetTrail(radarId, targetId);
  }

  clearRadarTrails(radarId) {
    return this.radarManager?.clearRadarTrails(radarId);
  }

  trackRadarTarget(radarId, targetId) {
    return this.radarManager?.trackRadarTarget(radarId, targetId);
  }

  untrackRadarTarget(radarId) {
    return this.radarManager?.untrackRadarTarget(radarId);
  }

  linkRadarTargetToMarker(radarId, targetId, markerId) {
    return this.radarManager?.linkRadarTargetToMarker(radarId, targetId, markerId);
  }

  exportRadars() {
    this.radarStore = this.radarManager?.exportRadars() || this.radarStore;
    return this.radarStore;
  }

  importRadars(data) {
    this.radarStore = data || { type: "RadarCollection", radars: [] };
    return this.radarManager?.importRadars(this.radarStore);
  }

  getRadarManager() {
    return this.radarManager;
  }

  setHeatmapData(points, options) {
    const result = this.heatmapManager?.setData(points, options);
    this.syncHeatmapObjects(points, options);
    return result;
  }

  addHeatmapPoint(point) {
    const result = this.heatmapManager?.addPoint(point);
    if (point?.id) this.compatObjects.set(point.id, this.heatmapPointToSpatialObject(point));
    return result;
  }

  addHeatmapPoints(points) {
    const result = this.heatmapManager?.addPoints(points) || [];
    (points || []).forEach((point) => {
      if (point?.id) this.compatObjects.set(point.id, this.heatmapPointToSpatialObject(point));
    });
    return result;
  }

  updateHeatmapPoint(id, patch) {
    const result = this.heatmapManager?.updatePoint(id, patch);
    if (result?.id) this.compatObjects.set(result.id, this.heatmapPointToSpatialObject(result));
    return result;
  }

  removeHeatmapPoint(id) {
    this.compatObjects.delete(String(id));
    return this.heatmapManager?.removePoint(id);
  }

  clearHeatmap() {
    this.heatmapManager?.clear();
    Array.from(this.compatObjects.values()).forEach((object) => {
      if (object.properties?.legacyType === "heatmap") this.compatObjects.delete(object.id);
    });
    this.heatmapStore = this.heatmapManager?.exportHeatmap() || {
      type: "HeatmapCollection",
      visible: true,
      options: { ...(this.options.heatmap || {}) },
      points: [],
    };
  }

  showHeatmap() {
    return this.heatmapManager?.show();
  }

  hideHeatmap() {
    return this.heatmapManager?.hide();
  }

  setHeatmapOptions(options) {
    return this.heatmapManager?.setOptions(options);
  }

  listHeatmapPoints() {
    return this.heatmapManager?.listPoints() || [];
  }

  exportHeatmap() {
    this.heatmapStore = this.heatmapManager?.exportHeatmap() || this.heatmapStore;
    return this.heatmapStore;
  }

  importHeatmap(data) {
    this.heatmapStore = data || { type: "HeatmapCollection", visible: true, options: { ...(this.options.heatmap || {}) }, points: [] };
    return this.heatmapManager?.importHeatmap(this.heatmapStore);
  }

  getHeatmapManager() {
    return this.heatmapManager;
  }

  drawPoint(options) {
    this.plotManager?.stop?.();
    return this.drawManager?.drawPoint(options);
  }

  drawLine(options) {
    this.plotManager?.stop?.();
    return this.drawManager?.drawLine(options);
  }

  drawPolygon(options) {
    this.plotManager?.stop?.();
    return this.drawManager?.drawPolygon(options);
  }

  drawRectangle(options) {
    this.plotManager?.stop?.();
    return this.drawManager?.drawRectangle(options);
  }

  drawCircle(options) {
    this.plotManager?.stop?.();
    return this.drawManager?.drawCircle(options);
  }

  enableDrawSelect() {
    this.plotManager?.stop?.();
    return this.drawManager?.enableSelect();
  }

  enableDrawEdit() {
    this.plotManager?.stop?.();
    return this.drawManager?.enableGeometryEdit();
  }

  selectDrawing(id) {
    return this.drawManager?.selectDrawing(id);
  }

  unselectDrawing() {
    return this.drawManager?.unselectDrawing();
  }

  getSelectedDrawing() {
    return this.drawManager?.getSelectedDrawing() || null;
  }

  removeDrawing(id) {
    return this.drawManager?.removeDrawing(id);
  }

  removeSelectedDrawing() {
    return this.drawManager?.removeSelectedDrawing();
  }

  updateDrawingProperties(id, properties) {
    return this.drawManager?.updateDrawingProperties(id, properties);
  }

  updateSelectedDrawingProperties(properties) {
    return this.drawManager?.updateSelectedDrawingProperties(properties);
  }

  listDrawings() {
    return this.drawManager?.listDrawings() || [];
  }

  createFenceFromDrawing(id, options) {
    return this.fenceManager?.createFenceFromDrawing(id, options);
  }

  createFenceFromSelectedDrawing(options) {
    return this.fenceManager?.createFenceFromSelectedDrawing(options);
  }

  listFences() {
    return this.fenceManager?.listFences() || [];
  }

  getFence(fenceId) {
    return this.fenceManager?.getFence(fenceId) || null;
  }

  removeFence(fenceId) {
    return this.fenceManager?.removeFence(fenceId);
  }

  enableFence(fenceId) {
    return this.fenceManager?.enableFence(fenceId);
  }

  disableFence(fenceId) {
    return this.fenceManager?.disableFence(fenceId);
  }

  exportFences() {
    return this.fenceManager?.exportFences() || createFeatureCollection();
  }

  importFences(geojson) {
    return this.fenceManager?.importFences(geojson);
  }

  checkFencePoint(target) {
    return this.fenceManager?.checkFencePoint(target);
  }

  checkFencePoints(targets) {
    return this.fenceManager?.checkFencePoints(targets) || [];
  }

  getFenceManager() {
    return this.fenceManager;
  }

  measureDistance(options) {
    this.plotManager?.stop?.();
    return this.measureManager?.measureDistance(options);
  }

  measureArea(options) {
    this.plotManager?.stop?.();
    return this.measureManager?.measureArea(options);
  }

  clearMeasurements() {
    this.measureManager?.clear();
    this.measureStore = createFeatureCollection();
  }

  exportMeasurements() {
    this.measureStore = this.measureManager?.exportGeoJSON() || this.measureStore;
    return this.measureStore;
  }

  importMeasurements(geojson) {
    this.measureStore = geojson || createFeatureCollection();
    return this.measureManager?.importGeoJSON(this.measureStore);
  }

  listMeasurements() {
    return this.measureManager?.listMeasurements() || [];
  }

  getMeasureManager() {
    return this.measureManager;
  }

  loadTrack(track, options) {
    const result = this.trackManager?.loadTrack(track, options);
    const object = this.trackToSpatialObject(track);
    if (object) this.compatObjects.set(object.id, object);
    return result;
  }

  playTrack() {
    return this.trackManager?.playTrack();
  }

  pauseTrack() {
    return this.trackManager?.pauseTrack();
  }

  resumeTrack() {
    return this.trackManager?.resumeTrack();
  }

  stopTrack() {
    return this.trackManager?.stopTrack();
  }

  seekTrack(progress) {
    return this.trackManager?.seekTrack(progress);
  }

  setTrackSpeed(speed) {
    return this.trackManager?.setTrackSpeed(speed);
  }

  setTrackFollow(enabled, options) {
    return this.trackManager?.setFollow(enabled, options);
  }

  clearTrack() {
    this.trackManager?.clearTrack();
    Array.from(this.compatObjects.values()).forEach((object) => {
      if (object.properties?.legacyType === "track") this.compatObjects.delete(object.id);
    });
    this.trackStore = null;
  }

  getTrackState() {
    return this.trackManager?.getTrackState() || this.trackStore || { track: null, status: "idle" };
  }

  getTrackManager() {
    return this.trackManager;
  }

  clearDrawings() {
    this.drawManager?.clear();
    this.drawStore = createFeatureCollection();
    this.selectedDrawingId = null;
  }

  exportGeoJSON() {
    this.drawStore = this.drawManager?.exportGeoJSON() || this.drawStore;
    return this.drawStore;
  }

  importGeoJSON(geojson) {
    this.drawStore = geojson || createFeatureCollection();
    return this.drawManager?.importGeoJSON(this.drawStore);
  }

  getDrawManager() {
    return this.drawManager;
  }

  addPolyline(options) {
    return this.engine.addPolyline?.(options);
  }

  removePolyline(id) {
    return this.engine.removePolyline?.(id);
  }

  clearPolylines() {
    return this.engine.clearPolylines?.();
  }

  destroy() {
    this.replayEngine?.destroy?.();
    this.animationEngine?.destroy?.();
    this.drawStore = this.exportGeoJSON();
    this.plotStore = this.exportPlots();
    this.radarStore = this.exportRadars();
    this.heatmapStore = this.exportHeatmap();
    this.controls?.unmount();
    this.controls = null;
    this.trackStore = this.getTrackState();
    this.clusterStore = this.getClusterState();
    this.clusterManager?.destroy();
    this.clusterManager = null;
    this.plotManager?.destroy();
    this.plotManager = null;
    this.radarManager?.destroy();
    this.radarManager = null;
    this.heatmapManager?.destroy();
    this.heatmapManager = null;
    this.trackManager?.destroy();
    this.trackManager = null;
    this.measureStore = this.exportMeasurements();
    this.measureManager?.destroy();
    this.measureManager = null;
    this.drawManager?.destroy();
    this.drawManager = null;
    this.fenceManager?.clearTargetState?.();
    this.fenceManager = null;
    return this.engine.destroy();
  }
}

function getConfiguredMinZoom2d(options = {}) {
  const minZoom = Number(options.minZoom2d ?? options.minZoom);
  return Number.isFinite(minZoom) ? minZoom : Number.NEGATIVE_INFINITY;
}

function createRuntimeCoverageObject(id, coverage = {}) {
  return {
    id: String(id),
    type: coverage.geometry ? "polygon" : "circle",
    position: coverage.position || coverage.center,
    geometry: coverage.geometry,
    style: {
      radius: coverage.radius,
      fillColor: coverage.fillColor || coverage.color || "#22d3ee",
      strokeColor: coverage.strokeColor || coverage.color || "#0891b2",
      opacity: coverage.opacity ?? 0.25,
      ...(coverage.style || {}),
    },
    properties: { ...(coverage.properties || {}), runtimeType: "coverage", radius: coverage.radius },
  };
}

function createRuntimeSectorObject(id, sector = {}) {
  const center = sector.center || sector.position;
  return {
    id: String(id),
    type: "polygon",
    geometry: {
      type: "Polygon",
      coordinates: createRuntimeSectorCoordinates(center, sector.radius, sector.startAngle, sector.endAngle, sector.steps),
    },
    style: {
      fillColor: sector.fillColor || sector.color || "#38bdf8",
      strokeColor: sector.strokeColor || sector.color || "#0284c7",
      opacity: sector.opacity ?? 0.28,
      ...(sector.style || {}),
    },
    properties: {
      ...(sector.properties || {}),
      runtimeType: "sector",
      center,
      radius: sector.radius,
      startAngle: sector.startAngle,
      endAngle: sector.endAngle,
    },
  };
}

function createRuntimeDirectionLineObject(id, line = {}) {
  const start = line.start || line.from || line.position;
  const end = line.end || line.to || destinationRuntimePoint(start, line.bearing, line.length || line.distance || 1000);
  return {
    id: String(id),
    type: "line",
    geometry: { type: "LineString", coordinates: [start, end].filter(Boolean) },
    style: {
      strokeColor: line.strokeColor || line.color || "#f59e0b",
      strokeWidth: line.strokeWidth ?? 2,
      ...(line.style || {}),
    },
    properties: { ...(line.properties || {}), runtimeType: "direction-line", bearing: line.bearing },
  };
}

function createRuntimeSectorCoordinates(center, radius = 1000, startAngle = 0, endAngle = 90, steps = 32) {
  if (!Array.isArray(center)) return [];
  const total = Math.max(2, Number(steps) || 32);
  const coordinates = [center];
  for (let index = 0; index <= total; index += 1) {
    const angle = Number(startAngle) + ((Number(endAngle) - Number(startAngle)) * index) / total;
    coordinates.push(destinationRuntimePoint(center, angle, radius));
  }
  coordinates.push(center);
  return coordinates;
}

function destinationRuntimePoint(center, bearing = 0, distance = 1000) {
  if (!Array.isArray(center)) return null;
  const radius = 6378137;
  const angularDistance = Number(distance) / radius;
  const bearingRad = (Number(bearing) * Math.PI) / 180;
  const lat1 = (Number(center[1]) * Math.PI) / 180;
  const lon1 = (Number(center[0]) * Math.PI) / 180;
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angularDistance) +
      Math.cos(lat1) * Math.sin(angularDistance) * Math.cos(bearingRad)
  );
  const lon2 =
    lon1 +
    Math.atan2(
      Math.sin(bearingRad) * Math.sin(angularDistance) * Math.cos(lat1),
      Math.cos(angularDistance) - Math.sin(lat1) * Math.sin(lat2)
    );
  return [(lon2 * 180) / Math.PI, (lat2 * 180) / Math.PI];
}


