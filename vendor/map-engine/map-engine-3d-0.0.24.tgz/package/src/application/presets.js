const DEFAULT_BASE_URL = typeof window === "undefined"
  ? "http://127.0.0.1:8080"
  : `${window.location.protocol}//${window.location.hostname}:8080`;
const DEFAULT_TIANDITU_TK = "";

const presets = new Map();

function runtimeValue(name, fallback) {
  if (typeof window === "undefined") return fallback;
  return window[name] ?? fallback;
}

function createXianggangPreset() {
  const baseUrl = runtimeValue("MAP_ENGINE_OFFLINE_BASE_URL", DEFAULT_BASE_URL);
  const mapName = runtimeValue("MAP_ENGINE_OFFLINE_3D_MAP_NAME", "xianggang_map");
  const mapVersion = runtimeValue(
    "MAP_ENGINE_OFFLINE_3D_MAP_VERSION",
    "20260720-global-fallback-v2"
  );
  const terrainName = runtimeValue("MAP_ENGINE_OFFLINE_3D_TERRAIN_NAME", "xianggang_terrain");
  const mapUrl =
    runtimeValue("MAP_ENGINE_OFFLINE_3D_MAP_URL", null) ||
    `${baseUrl}/MapServer/mbtiles/${mapName}/{x}/{y}/{z}?v=${encodeURIComponent(mapVersion)}`;
  const terrainUrl =
    runtimeValue("MAP_ENGINE_OFFLINE_3D_TERRAIN_URL", null) ||
    `${baseUrl}/DemServer/pak/${terrainName}`;
  return {
    name: "xianggang",
    center: [114.143562, 22.355084],
    center2d: [121.4737, 31.2304],
    zoom: 14,
    zoom2d: 10,
    zoom3d: 14,
    cameraHeight: 2300,
    initialCameraHeight: 22000000,
    initialFlyDuration: 2,
    resetFlyDuration: 0.8,
    baseMapProvider2d: "auto",
    localVectorServiceUrl: runtimeValue(
      "MAP_ENGINE_VECTOR_BASE_URL",
      typeof window === "undefined"
        ? "http://127.0.0.1:8080"
        : `${window.location.protocol}//${window.location.hostname}:8080`
    ),
    localVectorDatasetId: runtimeValue(
      "MAP_ENGINE_VECTOR_DATASET_ID",
      "china-ethiopia"
    ),
    localVectorStyle: runtimeValue(
      "MAP_ENGINE_VECTOR_STYLE",
      "default"
    ),
    baseMapType2d: "vec",
    minimumLevel2d: 0,
    maximumLevel2d: 18,
    baseMapProvider3d: "xyz",
    baseMapType3d: "img",
    baseMapUrl3d: mapUrl,
    minimumLevel3d: 0,
    // Keep the complete global overview as a permanent base. Cesium will
    // overzoom z10 when a regional detail tile is transparent or absent.
    maximumLevel3d: 10,
    offlineMapUrl3d: mapUrl,
    overlayLayers3d: [
      {
        id: "xianggang-imagery-detail",
        provider: "xyz",
        url: mapUrl,
        minimumLevel: 0,
        maximumLevel: 18,
        bounds: [113.839859, 22.151076, 114.447264, 22.559092],
        zIndex: 1,
      },
    ],
    terrainProvider3d: "cesium",
    terrainUrl3d: terrainUrl,
    preserveViewOnSwitch3d: false,
    tiandituTk: runtimeValue("MAP_ENGINE_TIANDITU_TK", DEFAULT_TIANDITU_TK),
    showAnnotation: true,
    probes: {
      mapLayerJsonUrl: `${baseUrl}/MapServer/mbtiles/${mapName}/layer.json`,
      terrainLayerJsonUrl: `${baseUrl}/DemServer/pak/${terrainName}/layer.json`,
      enableTerrain: runtimeValue("MAP_ENGINE_ENABLE_OFFLINE_3D_TERRAIN", true) !== false &&
        runtimeValue("MAP_ENGINE_ENABLE_OFFLINE_3D_TERRAIN", true) !== "false",
    },
  };
}

export function registerPreset(name, preset) {
  if (!name || !preset) return null;
  presets.set(String(name), { ...preset, name: String(name) });
  return presets.get(String(name));
}

export function getPreset(name = "xianggang") {
  if (!presets.has("xianggang")) registerPreset("xianggang", createXianggangPreset());
  return presets.get(String(name)) || presets.get("xianggang");
}

export function getPresetOptions(name = "xianggang", overrides = {}) {
  return { ...getPreset(name), ...(overrides.presetOptions || {}) };
}

export async function resolvePresetOptions(name = "xianggang", overrides = {}) {
  const preset = getPresetOptions(name, overrides);
  const [mapAvailable, terrainAvailable] = await Promise.all([
    probeMap(preset),
    preset.probes?.enableTerrain !== false
      ? probeHttp(preset.probes?.terrainLayerJsonUrl)
      : Promise.resolve(false),
  ]);

  return {
    ...preset,
    baseMapProvider3d: mapAvailable ? preset.baseMapProvider3d : "none",
    baseMapUrl3d: mapAvailable ? preset.baseMapUrl3d : undefined,
    minimumLevel3d: mapAvailable ? preset.minimumLevel3d : undefined,
    maximumLevel3d: mapAvailable ? preset.maximumLevel3d : undefined,
    bounds3d: mapAvailable ? preset.bounds3d : undefined,
    overlayLayers3d: mapAvailable ? preset.overlayLayers3d : [],
    terrainProvider3d: terrainAvailable ? preset.terrainProvider3d : "ellipsoid",
    terrainUrl3d: terrainAvailable ? preset.terrainUrl3d : undefined,
    preserveViewOnSwitch3d: false,
    presetStatus: {
      name: preset.name,
      mapAvailable,
      terrainAvailable,
    },
  };
}

async function probeMap(preset) {
  if (!preset?.offlineMapUrl3d && !preset?.baseMapUrl3d) return false;
  if (await probeHttp(preset.probes?.mapLayerJsonUrl)) return true;
  return probeImage(createTileProbeUrl(preset), 1200);
}

function createTileProbeUrl(preset) {
  const center = preset.center || [0, 0];
  const level = preset.minimumLevel3d ?? preset.zoom3d ?? preset.zoom ?? 0;
  const [lng, lat] = center;
  const tileCount = 2 ** level;
  const x = Math.floor(((lng + 180) / 360) * tileCount);
  const latRad = (lat * Math.PI) / 180;
  const y = Math.floor(
    ((1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2) *
      tileCount
  );

  return withCacheBust(
    (preset.offlineMapUrl3d || preset.baseMapUrl3d)
      .replace("{x}", String(x))
      .replace("{y}", String(y))
      .replace("{z}", String(level))
  );
}

function probeHttp(url, timeout = 1200) {
  if (!url || typeof fetch !== "function") return Promise.resolve(false);

  const controller =
    typeof AbortController !== "undefined" ? new AbortController() : null;
  let timer = null;
  const request = fetch(withCacheBust(url), {
    cache: "no-store",
    signal: controller?.signal,
  })
    .then((response) => response.ok)
    .catch(() => false)
    .finally(() => {
      if (timer) clearTimeout(timer);
    });

  const deadline = new Promise((resolve) => {
    timer = setTimeout(() => {
      controller?.abort?.();
      resolve(false);
    }, timeout);
  });

  return Promise.race([request, deadline]);
}

function probeImage(url, timeout = 1200) {
  if (!url || typeof Image === "undefined") return Promise.resolve(false);

  return new Promise((resolve) => {
    const image = new Image();
    let settled = false;
    const done = (result) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      image.onload = null;
      image.onerror = null;
      resolve(result);
    };
    const timer = setTimeout(() => done(false), timeout);
    image.onload = () => done(true);
    image.onerror = () => done(false);
    image.src = url;
  });
}

function withCacheBust(url) {
  if (!url) return url;
  const separator = url.includes("?") ? "&" : "?";
  return `${url}${separator}_map_probe=${Date.now()}`;
}
