import LegacyMapEngine from "../compat/LegacyMapEngine";
import { getPreset, getPresetOptions, registerPreset, resolvePresetOptions } from "./presets";
import { getOsmVectorServiceInfo } from "../integrations/OsmVectorBasemap";

const DEFAULT_2D_CENTER = Object.freeze([121.4737, 31.2304]);
const DEFAULT_2D_ZOOM = 10;

export async function createMapEngine(container, options = {}) {
  const target = resolveContainer(container);
  if (!target) throw new Error("MapEngine.create: container is required");

  const mode = options.mode || options.type || "3d";
  const show2dLoading = mode === "2d" && options.showLoading !== false;
  if (show2dLoading) {
    target.dataset.loadingText = options.loadingText || "正在加载离线地图…";
    target.classList.add("map-engine-is-loading");
    target.setAttribute("aria-busy", "true");
  }

  try {

  const presetName = options.preset || "xianggang";
  const defer3dProbe = mode === "2d" && options.defer3dProbe !== false && options.usePreset !== false;
  const presetOptions = options.usePreset === false
    ? {}
    : defer3dProbe
      ? {
          ...getPresetOptions(presetName, options),
          presetStatus: { name: presetName, pending: true },
        }
      : await resolvePresetOptions(presetName, options);

  const controls = normalizeControls(options.controls);
  const engineOptions = {
    ...presetOptions,
    ...(options.mapOptions || {}),
    ...options,
    type: mode,
    container: target,
    center: options.center || presetOptions.center,
    center2d: options.center2d || options.center || presetOptions.center2d || DEFAULT_2D_CENTER,
    center3d: options.center3d || options.center || presetOptions.center,
    zoom: options.zoom ?? presetOptions.zoom,
    zoom2d: options.zoom2d ?? options.zoom ?? presetOptions.zoom2d ?? DEFAULT_2D_ZOOM,
    zoom3d: options.zoom3d ?? options.zoom ?? presetOptions.zoom3d ?? presetOptions.zoom,
    controls,
  };

  await resolve2dBaseMap(engineOptions, options);

  delete engineOptions.mode;
  delete engineOptions.preset;
  delete engineOptions.presetOptions;
  delete engineOptions.usePreset;
  delete engineOptions.defer3dProbe;
  delete engineOptions.mapOptions;

  const map = new LegacyMapEngine(engineOptions);
  map.init();
  await map.waitForBaseMapReady?.({ timeout: engineOptions.initialRenderTimeout ?? 4000 });
  map.presetStatus = presetOptions.presetStatus || { name: presetName };
  if (defer3dProbe) {
    resolvePresetOptions(presetName, options)
      .then((resolved) => applyDeferred3dPreset(map, resolved, options))
      .catch((error) => {
        map.presetStatus = { name: presetName, pending: false, error: error?.message || String(error) };
        console.warn("MapEngine deferred 3D availability probe failed", error);
      });
  }
  if (map.presetStatus?.mapAvailable === false) {
    console.warn("MapEngine preset offline 3D imagery unavailable; no Tianditu 3D imagery fallback is used", {
      preset: presetName,
      offlineMapUrl3d: engineOptions.offlineMapUrl3d,
    });
  }
  return map;
  } finally {
    if (show2dLoading) {
      target.classList.remove("map-engine-is-loading");
      target.setAttribute("aria-busy", "false");
    }
  }
}

const DEFERRED_3D_KEYS = [
  "baseMapProvider3d",
  "baseMapUrl3d",
  "minimumLevel3d",
  "maximumLevel3d",
  "bounds3d",
  "overlayLayers3d",
  "terrainProvider3d",
  "terrainUrl3d",
  "preserveViewOnSwitch3d",
];

function applyDeferred3dPreset(map, resolved, explicitOptions) {
  if (!map?.options) return;
  DEFERRED_3D_KEYS.forEach((key) => {
    if (explicitOptions[key] === undefined) map.options[key] = resolved[key];
  });
  map.presetStatus = resolved.presetStatus;
  if (resolved.presetStatus?.mapAvailable === false) {
    console.warn("MapEngine preset offline 3D imagery unavailable; no Tianditu 3D imagery fallback is used", {
      preset: resolved.presetStatus.name,
      offlineMapUrl3d: map.options.offlineMapUrl3d,
    });
  }
}

async function resolve2dBaseMap(engineOptions, requestedOptions) {
  const requestedProvider = engineOptions.baseMapProvider2d || engineOptions.baseMapProvider || "auto";
  if (requestedProvider !== "auto") return;

  const serviceUrl = engineOptions.localVectorServiceUrl || defaultVectorServiceUrl();
  const result = await getOsmVectorServiceInfo(
    serviceUrl,
    engineOptions.localVectorProbeTimeout ?? 1200,
    engineOptions.localVectorDatasetId || "china-ethiopia"
  );
  const fallbackProvider = engineOptions.fallbackBaseMapProvider2d || "tianditu";

  engineOptions.requestedBaseMapProvider2d = "auto";
  engineOptions.baseMapProvider2d = result.available ? "mvt" : fallbackProvider;
  engineOptions.localVectorServiceUrl = result.serviceUrl;
  engineOptions.localVectorAvailable = result.available;
  engineOptions.localVectorZoomCoverage = Array.isArray(result.tilejson?.zoom_coverage)
    ? result.tilejson.zoom_coverage
    : null;
  const configuredDataMaxZoom = Number(engineOptions.localVectorDataMaxZoom);
  const advertisedDataMaxZoom = Number(result.tilejson?.maxzoom);
  engineOptions.localVectorDataMaxZoom = Number.isFinite(configuredDataMaxZoom)
    ? Math.max(0, Math.floor(configuredDataMaxZoom))
    : Number.isFinite(advertisedDataMaxZoom)
      ? Math.max(0, Math.floor(advertisedDataMaxZoom))
      : 13;
  engineOptions.baseMapStatus2d = {
    requested: "auto",
    active: engineOptions.baseMapProvider2d,
    localAvailable: result.available,
    localVectorServiceUrl: result.serviceUrl,
    localVectorDatasetId: result.datasetId,
    localVectorDatasetVersion: result.datasetVersion,
    localVectorDataMaxZoom: engineOptions.localVectorDataMaxZoom,
    localVectorZoomCoverage: engineOptions.localVectorZoomCoverage,
    overzoom: result.available,
  };

  if (!result.available) {
    engineOptions.baseMapType2d = engineOptions.fallbackBaseMapType2d || "vec";
    return;
  }

  const tileTemplate = result.tilejson?.tiles?.[0];
  if (tileTemplate) engineOptions.baseMapUrl2d = tileTemplate;
  engineOptions.minimumLevel2d = result.tilejson?.minzoom ?? engineOptions.minimumLevel2d;
  engineOptions.maximumLevel2d = result.tilejson?.maxzoom ?? engineOptions.maximumLevel2d;
  if (Array.isArray(result.tilejson?.bounds) && result.tilejson.bounds.length >= 4) {
    engineOptions.bounds2d = result.tilejson.bounds.slice(0, 4).map(Number);
  }
  if (requestedOptions.preserveViewOnSwitch2d === undefined) {
    engineOptions.preserveViewOnSwitch2d = false;
  }

  const tileCenter = result.tilejson?.center;
  if (
    requestedOptions.useTileJsonCenter2d === true &&
    !requestedOptions.center &&
    !requestedOptions.center2d &&
    Array.isArray(tileCenter)
  ) {
    engineOptions.center2d = tileCenter.slice(0, 2);
    if (
      requestedOptions.zoom === undefined &&
      requestedOptions.zoom2d === undefined &&
      Number.isFinite(tileCenter[2])
    ) {
      engineOptions.zoom2d = tileCenter[2];
    }
  }
}

function defaultVectorServiceUrl() {
  if (typeof window === "undefined") return "http://127.0.0.1:8080";
  return `${window.location.protocol}//${window.location.hostname}:8080`;
}

export { getPreset, registerPreset };

function resolveContainer(container) {
  if (typeof container !== "string") return container;
  if (typeof document === "undefined") return null;
  return document.getElementById(container) || document.querySelector(container);
}

function normalizeControls(controls) {
  if (controls === false) return false;
  return {
    mapToolbar: true,
    featureToolbar: false,
    ...(controls || {}),
  };
}
