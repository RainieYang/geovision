import MapEngine from "./core/MapEngine";
import LegacyMapEngine from "./compat/LegacyMapEngine";
import { createMapEngine, getPreset, registerPreset } from "./application/createMapEngine";

MapEngine.create = createMapEngine;
MapEngine.registerPreset = registerPreset;
MapEngine.getPreset = getPreset;

export { MapEngine, LegacyMapEngine, createMapEngine, registerPreset, getPreset };
export default MapEngine;
