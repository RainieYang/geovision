export default class CesiumCameraObserver {
  constructor(viewer, callback, options = {}) {
    this.viewer = viewer;
    this.callback = callback;
    this.delay = Math.max(100, Math.min(200, Number(options.delay) || 150));
    this.timer = null;
    this.changedListener = () => this.schedule();
    this.moveEndListener = () => this.flush("moveEnd");
    this.triggerCount = 0;
    this.bound = false;
  }

  bind() {
    if (this.bound || !this.viewer?.camera) return;
    this.viewer.camera.changed.addEventListener(this.changedListener);
    this.viewer.camera.moveEnd.addEventListener(this.moveEndListener);
    this.bound = true;
  }

  schedule() {
    if (this.timer) return;
    this.timer = setTimeout(() => this.flush("changed"), this.delay);
  }

  flush(source) {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (!this.bound || !this.viewer || this.viewer.isDestroyed?.()) return;
    this.triggerCount += 1;
    this.callback?.({ source, triggerCount: this.triggerCount });
  }

  getListenerCount() {
    return this.bound ? 2 : 0;
  }

  destroy() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    if (this.bound && this.viewer?.camera) {
      this.viewer.camera.changed.removeEventListener(this.changedListener);
      this.viewer.camera.moveEnd.removeEventListener(this.moveEndListener);
    }
    this.bound = false;
    this.viewer = null;
    this.callback = null;
  }
}
