export default class TargetFocusController {
  constructor(viewer, Cesium) {
    this.viewer = viewer;
    this.Cesium = Cesium;
  }

  focus(entity, options = {}) {
    if (!entity || !this.viewer || this.viewer.isDestroyed?.()) return null;
    const position = entity.position?.getValue?.(this.viewer.clock.currentTime) || entity.position;
    if (!position) return null;
    const cartographic = this.Cesium.Cartographic.fromCartesian(position);
    const altitude = Math.max(0, Number(cartographic?.height) || 0);
    const range = Math.max(700, Number(options.range) || altitude * 0.45);
    const offset = new this.Cesium.HeadingPitchRange(
      Number.isFinite(Number(options.heading)) ? Number(options.heading) : 0,
      Number.isFinite(Number(options.pitch)) ? Number(options.pitch) : this.Cesium.Math.toRadians(-30),
      range
    );
    this.viewer.camera.cancelFlight?.();
    this.viewer.camera.flyToBoundingSphere(new this.Cesium.BoundingSphere(position, 1), {
      offset,
      duration: normalizeDuration(options.duration ?? 0.8),
      easingFunction: this.Cesium.EasingFunction.CUBIC_IN_OUT,
    });
    return { range, position };
  }

  destroy() {
    this.viewer = null;
  }
}

function normalizeDuration(value) {
  const duration = Number(value);
  if (!Number.isFinite(duration) || duration <= 0) return 0;
  return duration > 10 ? duration / 1000 : duration;
}
