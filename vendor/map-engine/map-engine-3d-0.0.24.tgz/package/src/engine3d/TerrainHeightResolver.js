export default class TerrainHeightResolver {
  constructor(viewer, Cesium, options = {}) {
    this.viewer = viewer;
    this.Cesium = Cesium;
    this.precision = Math.max(3, Math.min(6, Number(options.precision) || 5));
    this.cache = new Map();
    this.pending = new Map();
  }

  get(lng, lat) {
    return this.cache.get(this.getKey(lng, lat));
  }

  resolve(lng, lat) {
    const key = this.getKey(lng, lat);
    if (this.cache.has(key)) return Promise.resolve(this.cache.get(key));
    if (this.pending.has(key)) return this.pending.get(key);

    const provider = this.viewer?.terrainProvider;
    if (!provider || provider instanceof this.Cesium.EllipsoidTerrainProvider) {
      this.cache.set(key, 0);
      return Promise.resolve(0);
    }

    const cartographic = this.Cesium.Cartographic.fromDegrees(Number(lng), Number(lat));
    const request = this.Cesium.sampleTerrainMostDetailed(provider, [cartographic]).then(
      (positions) => {
        const height = Number(positions?.[0]?.height);
        const resolved = Number.isFinite(height) ? height : 0;
        this.cache.set(key, resolved);
        this.pending.delete(key);
        return resolved;
      },
      (error) => {
        console.warn("TerrainHeightResolver: terrain sampling failed", error);
        this.cache.set(key, 0);
        this.pending.delete(key);
        return 0;
      }
    );
    this.pending.set(key, request);
    return request;
  }

  clear() {
    this.cache.clear();
    this.pending.clear();
  }

  destroy() {
    this.clear();
    this.viewer = null;
  }

  getKey(lng, lat) {
    return `${Number(lng).toFixed(this.precision)}:${Number(lat).toFixed(this.precision)}`;
  }
}
