export default class CesiumDeviceSituationLayer {
  constructor(viewer, Cesium, options = {}) {
    this.viewer = viewer;
    this.Cesium = Cesium;
    this.options = { guideDistance: 50000, headingLength: 180, ...options };
    this.terrainHeightResolver = options.terrainHeightResolver || null;
    this.onTerrainHeightResolved = options.onTerrainHeightResolved || null;
    this.records = new Map();
    this.lines = new Cesium.PolylineCollection();
    this.points = new Cesium.PointPrimitiveCollection();
    viewer.scene.primitives.add(this.lines);
    viewer.scene.primitives.add(this.points);
  }

  upsert(id, object, context = {}) {
    const position = getPosition(object);
    if (!position) return this.remove(id);
    const selected = object.properties?.selected === true;
    const visible = object.properties?.visible !== false && (selected || Number(context.cameraDistance) <= this.options.guideDistance);
    if (!visible) return this.remove(id);
    let record = this.records.get(String(id));
    if (!record) {
      const meta = { devicePresentationId: String(id), kind: "situation" };
      record = {
        altitudeLine: this.lines.add({ id: { ...meta, part: "altitude" }, width: 1.5 }),
        headingLine: this.lines.add({ id: { ...meta, part: "heading" }, width: 2.5 }),
        groundPoint: this.points.add({ id: { ...meta, part: "ground" }, pixelSize: 7 }),
      };
      this.records.set(String(id), record);
    }
    const aircraft = this.Cesium.Cartesian3.fromDegrees(position[0], position[1], position[2]);
    const groundHeight = this.terrainHeightResolver?.get(position[0], position[1]);
    if (!Number.isFinite(groundHeight)) {
      this.requestTerrainHeight(id, position[0], position[1]);
      this.hideGroundRecord(record);
      return;
    }
    const ground = this.Cesium.Cartesian3.fromDegrees(position[0], position[1], groundHeight);
    const accent = selected ? this.Cesium.Color.fromCssColorString("#ffe66d") : this.Cesium.Color.fromCssColorString("#22d3ee");
    record.altitudeLine.positions = [ground, aircraft];
    record.altitudeLine.material = this.Cesium.Material.fromType("Color", { color: accent.withAlpha(selected ? 0.9 : 0.48) });
    record.altitudeLine.show = Boolean(position[2] > 1);
    record.groundPoint.position = ground;
    record.groundPoint.color = accent.withAlpha(selected ? 0.95 : 0.72);
    record.groundPoint.outlineColor = this.Cesium.Color.WHITE.withAlpha(0.8);
    record.groundPoint.outlineWidth = selected ? 2 : 1;
    record.groundPoint.pixelSize = selected ? 10 : 7;
    record.groundPoint.show = true;
    const endpoint = headingEndpoint(this.Cesium, aircraft, object.properties?.heading, this.options.headingLength);
    record.headingLine.positions = [aircraft, endpoint];
    record.headingLine.material = this.Cesium.Material.fromType("Color", { color: accent });
    record.headingLine.show = true;
  }

  requestTerrainHeight(id, lng, lat) {
    this.terrainHeightResolver?.resolve(lng, lat).then(() => this.onTerrainHeightResolved?.(id));
  }

  hideGroundRecord(record) {
    record.altitudeLine.show = false;
    record.headingLine.show = false;
    record.groundPoint.show = false;
  }

  remove(id) {
    const record = this.records.get(String(id));
    if (!record) return false;
    this.lines.remove(record.altitudeLine);
    this.lines.remove(record.headingLine);
    this.points.remove(record.groundPoint);
    this.records.delete(String(id));
    return true;
  }

  getDeviceIdFromPicked(picked) {
    return picked?.primitive?.id?.devicePresentationId || picked?.id?.devicePresentationId || null;
  }

  getPrimitiveCount() {
    return { altitudeLineCount: this.records.size, headingLineCount: this.records.size, groundPointCount: this.records.size };
  }

  destroy() {
    this.records.clear();
    if (this.viewer && !this.viewer.isDestroyed?.()) {
      this.viewer.scene.primitives.remove(this.lines);
      this.viewer.scene.primitives.remove(this.points);
    }
    this.viewer = null;
  }
}

function getPosition(object) {
  const position = object?.position;
  if (!Array.isArray(position) || position.length < 3) return null;
  return position.every((value) => Number.isFinite(Number(value))) ? position.map(Number) : null;
}

function headingEndpoint(Cesium, origin, headingDegrees, length) {
  const heading = Number.isFinite(Number(headingDegrees)) ? Number(headingDegrees) * Math.PI / 180 : 0;
  const local = new Cesium.Cartesian3(Math.sin(heading) * length, Math.cos(heading) * length, 0);
  return Cesium.Matrix4.multiplyByPoint(Cesium.Transforms.eastNorthUpToFixedFrame(origin), local, new Cesium.Cartesian3());
}
