export const defaultOcclusionConfig = Object.freeze({
  enabled: true,
  depthTestAgainstTerrain: true,
  hideLabelWhenOccluded: true,
  hideGroundMarkerWhenOccluded: true,
  allowSelectedTargetXRay: false,
  allowHistoryTrackXRay: false,
});

export function resolveOcclusionConfig(options = {}) {
  return {
    ...defaultOcclusionConfig,
    ...(options && typeof options === "object" ? options : {}),
  };
}
