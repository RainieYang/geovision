export const DEFAULT_DEVICE_LOD = Object.freeze({
  detailEnterDistance: 3000,
  detailExitDistance: 3600,
  simplifiedEnterDistance: 12000,
  simplifiedExitDistance: 14000,
  billboardEnterDistance: 50000,
  billboardExitDistance: 55000,
});

/**
 * Resolve a presentation level without reading Cesium state.
 * heading/pitch/roll are deliberately not part of this static policy.
 */
export function resolveDeviceLod(context = {}, config = {}) {
  const thresholds = normalizeLodConfig(config);
  if (context.isVisible === false) return { level: "hidden", reason: "not-visible" };
  const distance = Number(context.cameraDistance);
  if (!Number.isFinite(distance) || distance < 0) return { level: "hidden", reason: "distance" };

  const previous = context.previousLevel || "hidden";
  if (previous === "detail" && distance <= thresholds.detailExitDistance) return { level: "detail", reason: "distance" };
  if (previous === "simplified" && distance > thresholds.detailEnterDistance && distance <= thresholds.simplifiedExitDistance) return { level: "simplified", reason: "distance" };
  if (previous === "billboard" && distance > thresholds.simplifiedEnterDistance && distance <= thresholds.billboardExitDistance) return { level: "billboard", reason: "distance" };
  if (previous === "hidden" && distance > thresholds.billboardEnterDistance) return { level: "hidden", reason: "distance" };

  if (distance <= thresholds.detailEnterDistance) return { level: "detail", reason: "distance" };
  if (distance <= thresholds.simplifiedEnterDistance) return { level: "simplified", reason: "distance" };
  if (distance <= thresholds.billboardEnterDistance) return { level: "billboard", reason: "distance" };
  return { level: "hidden", reason: "distance" };
}

export function normalizeLodConfig(config = {}) {
  const next = { ...DEFAULT_DEVICE_LOD, ...(config || {}) };
  const keys = Object.keys(DEFAULT_DEVICE_LOD);
  keys.forEach((key) => {
    const value = Number(next[key]);
    next[key] = Number.isFinite(value) && value >= 0 ? value : DEFAULT_DEVICE_LOD[key];
  });
  if (next.detailEnterDistance > next.detailExitDistance || next.detailExitDistance > next.simplifiedEnterDistance || next.simplifiedEnterDistance > next.simplifiedExitDistance || next.simplifiedExitDistance > next.billboardEnterDistance || next.billboardEnterDistance > next.billboardExitDistance) {
    return { ...DEFAULT_DEVICE_LOD };
  }
  return next;
}
