export default class ScreenEffectController {
  constructor(viewer, Cesium) {
    this.viewer = viewer;
    this.Cesium = Cesium;
    this.selectedEntity = null;
    this.terrainVisible = true;
    this.element = document.createElement("div");
    this.element.className = "map-engine-device-pulse";
    Object.assign(this.element.style, {
      position: "absolute", width: "46px", height: "46px", border: "2px solid #ffe66d", borderRadius: "50%",
      pointerEvents: "none", display: "none", transform: "translate(-50%, -50%)", boxSizing: "border-box",
      animation: "map-engine-device-pulse 1.2s ease-out infinite", zIndex: "8",
    });
    this.styleElement = ensureStyle();
    viewer.container.appendChild(this.element);
    this.onPostRender = () => this.render();
    viewer.scene.postRender.addEventListener(this.onPostRender);
  }

  setSelectedEntity(entity) { this.selectedEntity = entity || null; this.terrainVisible = true; this.render(); }

  setTerrainVisible(visible) { this.terrainVisible = visible !== false; this.render(); }

  render() {
    if (!this.selectedEntity || !this.terrainVisible || !this.viewer || this.viewer.isDestroyed?.()) return this.hide();
    const position = this.selectedEntity.position?.getValue?.(this.viewer.clock.currentTime) || this.selectedEntity.position;
    const windowPosition = position && this.Cesium.SceneTransforms.wgs84ToWindowCoordinates(this.viewer.scene, position);
    if (!windowPosition) return this.hide();
    this.element.style.display = "block";
    this.element.style.left = `${windowPosition.x}px`;
    this.element.style.top = `${windowPosition.y}px`;
  }

  hide() { if (this.element) this.element.style.display = "none"; }

  destroy() {
    this.viewer?.scene?.postRender?.removeEventListener(this.onPostRender);
    this.element?.remove();
    if (!document.querySelector(".map-engine-device-pulse")) this.styleElement?.remove();
    this.selectedEntity = null;
    this.viewer = null;
  }
}

function ensureStyle() {
  const existing = document.getElementById("map-engine-device-pulse-style");
  if (existing) return existing;
  const style = document.createElement("style");
  style.id = "map-engine-device-pulse-style";
  style.textContent = "@keyframes map-engine-device-pulse{0%{opacity:.95;transform:translate(-50%,-50%) scale(.65)}100%{opacity:0;transform:translate(-50%,-50%) scale(1.65)}}";
  document.head.appendChild(style);
  return style;
}
