import CesiumCameraObserver from "./CesiumCameraObserver";
import CesiumDeviceSituationLayer from "./CesiumDeviceSituationLayer";
import ModelResourceResolver from "./ModelResourceResolver";
import ScreenEffectController from "./ScreenEffectController";
import TerrainHeightResolver from "./TerrainHeightResolver";
import { resolveDeviceLabel } from "./deviceLabelPolicy";
import { resolveDeviceLod } from "./deviceLodPolicy";

export default class CesiumDevicePresentationAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.viewer = engine.viewer;
    this.Cesium = engine.CesiumLib;
    this.defaultBillboardImage = options.defaultBillboardImage || "/cesium/Assets/Textures/maki/rocket.png";
    this.bundles = new Map();
    this.resources = new ModelResourceResolver();
    this.occlusionConfig = engine.getOcclusion3d?.() || {};
    this.terrainHeightResolver = new TerrainHeightResolver(this.viewer, this.Cesium, options.terrain);
    this.situationLayer = new CesiumDeviceSituationLayer(this.viewer, this.Cesium, {
      ...options.situation,
      terrainHeightResolver: this.terrainHeightResolver,
      onTerrainHeightResolved: (id) => this.refreshSituationFor(id),
    });
    this.screenEffectController = new ScreenEffectController(this.viewer, this.Cesium);
    this.lodSwitchCount = 0;
    this.renderUpdateCount = 0;
    this.modelReadyListener = () => this.syncModelReadiness();
    this.cameraObserver = new CesiumCameraObserver(this.viewer, () => this.refreshLods(), options.cameraObserver);
    this.cameraObserver.bind();
    this.viewer.scene.postRender.addEventListener(this.modelReadyListener);
  }

  handles(object) {
    return object?.type === "marker" && Boolean(
      object.properties?.presentation3d || object.properties?.role === "uav"
    );
  }

  upsert(object) {
    if (!this.handles(object)) return null;
    let bundle = this.bundles.get(object.id);
    if (!bundle) {
      bundle = { id: object.id, object: null, level: "hidden", detailModelEntity: null, simplifiedModelEntity: null, markerEntity: null, coverageEntity: null };
      this.bundles.set(object.id, bundle);
    }
    bundle.object = object;
    this.updateBundle(bundle, true);
    if (object.properties?.selected === true) this.screenEffectController.setSelectedEntity(this.getDeviceEntity(object.id));
    return bundle.markerEntity || bundle.detailModelEntity || bundle.simplifiedModelEntity;
  }

  remove(id) {
    const bundle = this.bundles.get(String(id));
    if (!bundle) return false;
    ["detailModelEntity", "simplifiedModelEntity", "markerEntity", "coverageEntity"].forEach((key) => {
      if (bundle[key]) this.viewer.entities.remove(bundle[key]);
    });
    this.situationLayer.remove(id);
    this.bundles.delete(String(id));
    return true;
  }

  refreshLods() {
    this.bundles.forEach((bundle) => this.updateBundle(bundle, false));
    this.refreshSelectedTerrainVisibility();
    this.viewer.scene.requestRender?.();
  }

  updateBundle(bundle, allowCreate) {
    const object = bundle.object;
    const position = getPosition(object);
    const presentation = object.properties?.presentation3d || {};
    if (!position) {
      this.situationLayer.remove(bundle.id);
      this.applyLevel(bundle, "hidden", presentation, allowCreate);
      return;
    }
    const cartesian = this.Cesium.Cartesian3.fromDegrees(position[0], position[1], position[2]);
    const distance = this.Cesium.Cartesian3.distance(this.viewer.camera.positionWC, cartesian);
    const decision = resolveDeviceLod({
      previousLevel: bundle.level,
      cameraDistance: distance,
      cameraHeight: this.viewer.camera.positionCartographic.height,
      isVisible: object.properties?.visible !== false,
      isSelected: object.properties?.selected === true,
      isFollowed: object.properties?.followed === true,
    }, presentation.lod);
    this.applyLevel(bundle, decision.level, presentation, allowCreate, position, distance);
  }

  applyLevel(bundle, requestedLevel, presentation, allowCreate, position = getPosition(bundle.object), distance = Infinity) {
    // A partial object update may temporarily omit position. Do not let that
    // remove the whole Viewer: keep existing resources hidden until a valid
    // geographic position is available again.
    if (!position) {
      this.situationLayer.remove(bundle.id);
      this.setVisibility(bundle, "hidden", distance);
      if (bundle.level !== "hidden") this.lodSwitchCount += 1;
      bundle.level = "hidden";
      return;
    }
    const hasHeight = hasReliableHeight(bundle.object);
    const detailUrl = hasHeight ? presentation.detailModelUrl : null;
    const simplifiedUrl = hasHeight ? presentation.simplifiedModelUrl : null;
    const detailFailed = detailUrl && this.resources.get(detailUrl)?.status === "failed";
    const simpleFailed = simplifiedUrl && this.resources.get(simplifiedUrl)?.status === "failed";
    let level = requestedLevel;
    if (level === "detail" && (!detailUrl || detailFailed)) level = simplifiedUrl && !simpleFailed ? "simplified" : "billboard";
    if (level === "simplified" && (!simplifiedUrl || simpleFailed)) level = "billboard";

    if (level === "detail" && allowCreate) this.ensureModel(bundle, "detail", detailUrl, presentation, position);
    if (level === "simplified" && allowCreate) this.ensureModel(bundle, "simplified", simplifiedUrl, presentation, position);
    // Keep the marker visible until Cesium reports a model resource ready.
    if ((level === "detail" || level === "simplified") && !this.isBundleModelReady(bundle, level)) {
      if (allowCreate) this.ensureMarker(bundle, presentation, position);
    } else if (level === "billboard" && allowCreate) {
      this.ensureMarker(bundle, presentation, position);
    }

    this.updateDynamicProperties(bundle, position, presentation, distance, level);
    this.setVisibility(bundle, level, distance);
    if (bundle.level !== level) this.lodSwitchCount += 1;
    bundle.level = level;
    this.renderUpdateCount += 1;
  }

  ensureModel(bundle, kind, url, presentation, position) {
    if (!url) return null;
    const key = kind === "detail" ? "detailModelEntity" : "simplifiedModelEntity";
    if (bundle[key]) return bundle[key];
    this.resources.request(url);
    const entity = this.viewer.entities.add({
      id: `device:${bundle.id}:${kind}`,
      position: this.toCartesian(position),
      orientation: this.toOrientation(bundle.object, presentation),
      model: {
        uri: url,
        scale: positiveNumber(presentation.modelScale, 1),
        minimumPixelSize: positiveNumber(presentation.modelMinimumPixelSize, 24),
        color: cssColor(this.Cesium, presentation.modelColor),
        colorBlendMode: presentation.modelColor ? this.Cesium.ColorBlendMode.MIX : undefined,
        colorBlendAmount: presentation.modelColor ? clampNumber(presentation.modelColorBlendAmount, 1, 0, 1) : undefined,
        silhouetteColor: cssColor(this.Cesium, presentation.modelSilhouetteColor),
        silhouetteSize: positiveNumber(presentation.modelSilhouetteSize, 0),
        heightReference: this.Cesium.HeightReference.NONE,
      },
      properties: { deviceId: bundle.id, devicePresentationKind: kind },
      // Cesium 1.91 skips ModelVisualizer loading entirely when an Entity is
      // created hidden. The current LOD pass immediately controls visibility,
      // but creation must start visible so readyPromise can resolve.
      show: true,
    });
    bundle[key] = entity;
    return entity;
  }

  syncModelReadiness() {
    // Cesium 1.91 exposes Entity model readiness only through ModelVisualizer's model instance.
    // This is isolated here so the resolver remains URL-state-only and never fetches assets.
    const visualizers = this.getModelVisualizers();
    if (!visualizers.length) return;
    let readinessChanged = false;
    this.bundles.forEach((bundle) => {
      ["detail", "simplified"].forEach((kind) => {
        const entity = bundle[`${kind}ModelEntity`];
        const url = bundle.object?.properties?.presentation3d?.[kind === "detail" ? "detailModelUrl" : "simplifiedModelUrl"];
        const modelData = entity ? this.findModelData(entity, visualizers) : null;
        const model = modelData?.modelPrimitive;
        if (!model || !url) return;
        if (modelData.loadFail) {
          this.resources.markFailed(url, new Error(`Cesium failed to load model: ${url}`));
          this.updateBundle(bundle, true);
          return;
        }
        // Cesium 1.91 exposes `ready` on the primitive. Check it directly on
        // every scene render; this is more reliable than waiting only on the
        // private promise callback when entities are hidden by LOD meanwhile.
        if (model.ready) {
          const wasReady = this.isModelReady(url);
          this.resources.markReady(url);
          this.hideMarkerBillboardForReadyModel(bundle, kind);
          readinessChanged = readinessChanged || !wasReady;
          return;
        }
        if (!model._devicePresentationReadyBound && model.readyPromise?.then) {
          model._devicePresentationReadyBound = true;
          model.readyPromise
            .then(() => {
              this.resources.markReady(url);
              this.hideMarkerBillboardForReadyModel(bundle, kind);
              this.updateBundle(bundle, true);
              this.viewer?.scene?.requestRender?.();
            })
            .otherwise?.((error) => {
              this.resources.markFailed(url, error);
              this.updateBundle(bundle, true);
            });
        }
      });
    });
    // The marker's Billboard visibility is derived from resource readiness.
    // Re-run the current LOD once per URL-state transition, never per frame.
    if (readinessChanged) this.refreshLods();
  }

  getModelVisualizers() {
    const visualizers = this.viewer?.dataSourceDisplay?._defaultDataSource?._visualizers
      || this.viewer?.dataSourceDisplay?._visualizers
      || [];
    return visualizers.filter((item) => item?._modelHash);
  }

  findModelData(entity, visualizers = this.getModelVisualizers()) {
    return visualizers.reduce((found, visualizer) => found || visualizer._modelHash?.[entity.id], null);
  }

  hideMarkerBillboardForReadyModel(bundle, kind) {
    if (bundle.level !== kind || !bundle.markerEntity?.billboard) return;
    // Keep the Marker Entity itself for the label and picking, but remove only
    // its fallback billboard after this exact model primitive is render-ready.
    bundle.markerEntity.billboard.show = false;
  }

  ensureMarker(bundle, presentation, position) {
    if (bundle.markerEntity) return bundle.markerEntity;
    const style = bundle.object.style || {};
    const label = style.label || {};
    const image = presentation.billboardImage || style.icon || presentation.defaultBillboardImage || this.defaultBillboardImage;
    const options = {
      id: `device:${bundle.id}:marker`,
      position: this.toCartesian(position),
      properties: { deviceId: bundle.id, devicePresentationKind: "marker", spatialObject: bundle.object },
      show: false,
    };
    if (image) {
      options.billboard = {
        image,
        width: style.iconWidth || 36,
        height: style.iconHeight || 36,
        verticalOrigin: this.Cesium.VerticalOrigin.BOTTOM,
        heightReference: this.resolveHeightReference(bundle.object),
        disableDepthTestDistance: 0,
      };
    } else {
      options.point = { pixelSize: style.pixelSize || 12, color: this.Cesium.Color.ROYALBLUE, outlineColor: this.Cesium.Color.WHITE, outlineWidth: 2, heightReference: this.resolveHeightReference(bundle.object), disableDepthTestDistance: 0 };
    }
    if (label.show !== false) options.label = this.createLabel(label, bundle.object.properties?.name || bundle.id);
    bundle.markerEntity = this.viewer.entities.add(options);
    return bundle.markerEntity;
  }

  updateDynamicProperties(bundle, position, presentation, distance, level) {
    const cartesian = this.toCartesian(position);
    const orientation = this.toOrientation(bundle.object, presentation);
    [bundle.detailModelEntity, bundle.simplifiedModelEntity, bundle.markerEntity].filter(Boolean).forEach((entity) => {
      entity.position = cartesian;
      if (entity.model) entity.orientation = orientation;
      if (entity.label) {
        const label = resolveDeviceLabel({ object: bundle.object, cameraDistance: distance }, presentation.label);
        entity.label.text = label.text;
        entity.label.show = label.show;
        entity.label.disableDepthTestDistance = 0;
      }
      if (entity.properties) entity.properties.spatialObject = bundle.object;
    });
    this.situationLayer.upsert(bundle.id, bundle.object, { cameraDistance: distance, level });
  }

  setVisibility(bundle, level, distance) {
    if (bundle.detailModelEntity) bundle.detailModelEntity.show = level === "detail";
    if (bundle.simplifiedModelEntity) bundle.simplifiedModelEntity.show = level === "simplified";
    if (bundle.markerEntity) {
      const modelLoading = (level === "detail" || level === "simplified") && !this.isBundleModelReady(bundle, level);
      const label = resolveDeviceLabel({ object: bundle.object, cameraDistance: distance }, bundle.object.properties?.presentation3d?.label);
      bundle.markerEntity.show = level !== "hidden";
      if (bundle.markerEntity.billboard) bundle.markerEntity.billboard.show = level === "billboard" || modelLoading;
      if (bundle.markerEntity.label) bundle.markerEntity.label.show = label.show;
    }
  }

  getObjectFromPicked(picked) {
    const deviceId = this.situationLayer.getDeviceIdFromPicked(picked) || getDeviceIdFromEntity(picked?.id);
    return deviceId ? this.bundles.get(String(deviceId))?.object || null : null;
  }

  getDeviceEntity(id) {
    const bundle = this.bundles.get(String(id));
    return bundle?.markerEntity || bundle?.detailModelEntity || bundle?.simplifiedModelEntity || null;
  }

  setSelectedDevice(id) {
    this.screenEffectController.setSelectedEntity(id ? this.getDeviceEntity(id) : null);
    this.refreshSelectedTerrainVisibility();
  }

  getFocusEntity(id) {
    const bundle = this.bundles.get(String(id));
    return bundle?.detailModelEntity || bundle?.simplifiedModelEntity || bundle?.markerEntity || null;
  }

  setOcclusionConfig(config = {}) {
    this.occlusionConfig = { ...this.occlusionConfig, ...config };
    this.refreshSelectedTerrainVisibility();
  }

  handleTerrainChanged() {
    this.terrainHeightResolver.clear();
    this.refreshLods();
  }

  refreshSituationFor(id) {
    const bundle = this.bundles.get(String(id));
    if (!bundle?.object) return;
    const position = getPosition(bundle.object);
    if (!position) return;
    const cartesian = this.toCartesian(position);
    const distance = this.Cesium.Cartesian3.distance(this.viewer.camera.positionWC, cartesian);
    this.situationLayer.upsert(bundle.id, bundle.object, { cameraDistance: distance, level: bundle.level });
    this.viewer.scene.requestRender?.();
  }

  resolveHeightReference(object) {
    const mode = object?.properties?.presentation3d?.heightReference3d;
    if (mode === "relativeToGround") return this.Cesium.HeightReference.RELATIVE_TO_GROUND;
    if (mode === "clampToGround") return this.Cesium.HeightReference.CLAMP_TO_GROUND;
    return this.Cesium.HeightReference.NONE;
  }

  refreshSelectedTerrainVisibility() {
    const selected = Array.from(this.bundles.values()).find((bundle) => bundle.object?.properties?.selected === true);
    const entity = selected && this.getFocusEntity(selected.id);
    if (!entity || !this.occlusionConfig.hideLabelWhenOccluded) {
      this.screenEffectController.setTerrainVisible(true);
      return;
    }
    this.screenEffectController.setTerrainVisible(this.isEntityTerrainVisible(entity));
  }

  isEntityTerrainVisible(entity) {
    if (!this.viewer?.scene?.globe || !this.viewer.scene.globe.depthTestAgainstTerrain) return true;
    const position = entity.position?.getValue?.(this.viewer.clock.currentTime) || entity.position;
    const screenPosition = position && this.Cesium.SceneTransforms.wgs84ToWindowCoordinates(this.viewer.scene, position);
    if (!screenPosition) return false;
    const ray = this.viewer.camera.getPickRay(screenPosition);
    const terrainPosition = ray && this.viewer.scene.globe.pick(ray, this.viewer.scene);
    if (!terrainPosition) return true;
    return this.Cesium.Cartesian3.distance(this.viewer.camera.positionWC, position)
      <= this.Cesium.Cartesian3.distance(this.viewer.camera.positionWC, terrainPosition) + 2;
  }

  isModelReady(url) {
    return this.resources.get(url)?.status === "ready";
  }

  isBundleModelReady(bundle, kind) {
    const entity = bundle?.[kind === "detail" ? "detailModelEntity" : "simplifiedModelEntity"];
    const model = entity ? this.findModelData(entity)?.modelPrimitive : null;
    // Resource readiness is a URL-level fallback. A marker must only disappear
    // after its own Cesium primitive is ready, otherwise another device sharing
    // the URL can cause a visible blank frame.
    return Boolean(model?.ready);
  }

  toCartesian(position) {
    if (!position) return null;
    return this.Cesium.Cartesian3.fromDegrees(position[0], position[1], position[2]);
  }

  toOrientation(object, presentation) {
    const properties = object.properties || {};
    const heading = northClockwiseDegreesToCesium(properties.heading) + degrees(presentation.headingOffsetDegrees);
    const pitch = degrees(properties.pitch) + degrees(presentation.pitchOffsetDegrees);
    const roll = degrees(properties.roll) + degrees(presentation.rollOffsetDegrees);
    return this.Cesium.Transforms.headingPitchRollQuaternion(this.toCartesian(getPosition(object)), new this.Cesium.HeadingPitchRoll(heading, pitch, roll));
  }

  createLabel(label, fallbackText) {
    return { text: label.text || fallbackText, font: label.font || "14px sans-serif", fillColor: label.fillColor ? this.Cesium.Color.fromCssColorString(label.fillColor) : this.Cesium.Color.WHITE, outlineColor: label.outlineColor ? this.Cesium.Color.fromCssColorString(label.outlineColor) : this.Cesium.Color.BLACK, outlineWidth: label.outlineWidth ?? 2, style: this.Cesium.LabelStyle.FILL_AND_OUTLINE, pixelOffset: new this.Cesium.Cartesian2(label.offsetX ?? 0, label.offsetY ?? -36) };
  }

  getDiagnostics() {
    const bundles = Array.from(this.bundles.values());
    const visualizers = this.getModelVisualizers();
    const modelStates = bundles.reduce((states, bundle) => {
      [bundle.detailModelEntity, bundle.simplifiedModelEntity].filter(Boolean).forEach((entity) => {
        if (entity.show) states.entityVisibleCount += 1;
        const model = this.findModelData(entity, visualizers)?.modelPrimitive;
        if (!model) return;
        states.primitiveCount += 1;
        if (model.ready) states.readyCount += 1;
        else states.pendingCount += 1;
        if (model.show) states.visibleCount += 1;
      });
      return states;
    }, { primitiveCount: 0, readyCount: 0, pendingCount: 0, visibleCount: 0, entityVisibleCount: 0 });
    return { bundleCount: bundles.length, deviceEntityCount: bundles.reduce((count, bundle) => count + [bundle.detailModelEntity, bundle.simplifiedModelEntity, bundle.markerEntity, bundle.coverageEntity].filter(Boolean).length, 0), detailCount: bundles.filter((bundle) => bundle.detailModelEntity).length, simplifiedCount: bundles.filter((bundle) => bundle.simplifiedModelEntity).length, markerCount: bundles.filter((bundle) => bundle.markerEntity).length, coverageCount: bundles.filter((bundle) => bundle.coverageEntity).length, ...this.situationLayer.getPrimitiveCount(), ...modelStates, lodSwitchCount: this.lodSwitchCount, renderUpdateCount: this.renderUpdateCount, modelLoadFailureCount: this.resources.getFailureCount(), cameraObserverTriggerCount: this.cameraObserver.triggerCount, listenerCount: this.cameraObserver.getListenerCount() + 2 };
  }

  destroy() {
    Array.from(this.bundles.keys()).forEach((id) => this.remove(id));
    this.cameraObserver.destroy();
    this.viewer?.scene?.postRender?.removeEventListener(this.modelReadyListener);
    this.situationLayer.destroy();
    this.terrainHeightResolver.destroy();
    this.screenEffectController.destroy();
    this.resources.clear();
    this.viewer = null;
  }
}

function getPosition(object) {
  const position = object?.position;
  if (!Array.isArray(position) || position.length < 2) return null;
  const lng = Number(position[0]); const lat = Number(position[1]);
  const height = Number.isFinite(Number(position[2])) ? Number(position[2]) : Number(object.properties?.altitude);
  return Number.isFinite(lng) && Number.isFinite(lat) && Number.isFinite(height) ? [lng, lat, height] : null;
}

function hasReliableHeight(object) {
  const mode = object?.properties?.presentation3d?.heightReference3d || "auto";
  return mode === "absolute" && getPosition(object) || (mode === "auto" && getPosition(object));
}

function degrees(value) { return Number.isFinite(Number(value)) ? Math.PI * Number(value) / 180 : 0; }
function northClockwiseDegreesToCesium(value) { return degrees(90 - (Number(value) || 0)); }
function positiveNumber(value, fallback) { const number = Number(value); return Number.isFinite(number) && number > 0 ? number : fallback; }
function clampNumber(value, fallback, min, max) { const number = Number(value); return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback; }
function cssColor(Cesium, value) { return value ? Cesium.Color.fromCssColorString(value) : undefined; }
function getDeviceIdFromEntity(entity) {
  const direct = entity?.properties?.deviceId?.getValue?.() || entity?.properties?.deviceId;
  if (direct) return String(direct);
  const match = String(entity?.id || "").match(/^device:(.+):(detail|simplified|marker)$/);
  return match?.[1] || null;
}
