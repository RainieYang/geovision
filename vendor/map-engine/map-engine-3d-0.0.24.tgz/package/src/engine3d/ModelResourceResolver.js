/** Maintains URL state only. Cesium ModelGraphics owns fetching and parsing. */
export default class ModelResourceResolver {
  constructor() {
    this.resources = new Map();
  }

  request(url) {
    if (!url) return { status: "missing", url: null };
    const existing = this.resources.get(url);
    if (existing) return existing;
    const resource = { status: "pending", url };
    this.resources.set(url, resource);
    return resource;
  }

  markReady(url) {
    const resource = this.request(url);
    resource.status = "ready";
    return resource;
  }

  markFailed(url, error) {
    const resource = this.request(url);
    if (resource.status !== "failed") resource.failureCount = (resource.failureCount || 0) + 1;
    resource.status = "failed";
    resource.error = error ? String(error.message || error) : "Cesium model failed";
    return resource;
  }

  get(url) {
    return url ? this.resources.get(url) || null : null;
  }

  getFailureCount() {
    return Array.from(this.resources.values()).reduce((count, resource) => count + (resource.failureCount || 0), 0);
  }

  clear() {
    this.resources.clear();
  }
}
