﻿import * as CesiumModule from "cesium";
import LayerManager from "../layer/LayerManager";
import { createMapPopup } from "../utils/popup";
import CesiumDevicePresentationAdapter from "./CesiumDevicePresentationAdapter";
import TargetFocusController from "./TargetFocusController";
import { resolveOcclusionConfig } from "./OcclusionConfig";

const CesiumLib = CesiumModule;

const cesiumBaseUrl =
  typeof window !== "undefined" && window.MAP_ENGINE_CESIUM_BASE_URL
    ? window.MAP_ENGINE_CESIUM_BASE_URL
    : "/cesium/";

CesiumLib.buildModuleUrl.setBaseUrl(cesiumBaseUrl);

if (typeof window !== "undefined") {
  window.Cesium = CesiumLib;
}

export default class CesiumMap {
  constructor(options = {}) {
    this.options = options;
    this.viewer = null;
    this.CesiumLib = CesiumLib;
    this.layerManager = null;
    this.watermarkEl = null;
    this.markers = new Map();
    this.spatialObjects = new Map();
    this.clickHandler = null;
    this.events = new Map();
    this.popupEl = null;
    this.pointerLngLat = null;
    this.devicePresentationAdapter = null;
    this.targetFocusController = null;
    this.occlusionConfig = resolveOcclusionConfig(options.occlusion3d || options.occlusion);
  }

  init() {
    const {
      container,
      watermark = "GeoVision",
    } = this.options;

    this.viewer = new CesiumLib.Viewer(container, {
      imageryProvider: false,
      terrainProvider: new CesiumLib.EllipsoidTerrainProvider(),
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      baseLayerPicker: false,
      navigationHelpButton: false,
      animation: false,
      timeline: false,
      fullscreenButton: false,
      infoBox: false,
      selectionIndicator: false,
      vrButton: false,
      shadows: false,
      shouldAnimate: false,
      requestRenderMode: false,
      contextOptions: {
        webgl: {
          alpha: false,
          antialias: true,
          failIfMajorPerformanceCaveat: false,
        },
      },
    });

    this.viewer.container.style.width = "100%";
    this.viewer.container.style.height = "100%";
    this.viewer.canvas.style.width = "100%";
    this.viewer.canvas.style.height = "100%";
    this.configureSceneForQt();
    this.targetFocusController = new TargetFocusController(this.viewer, CesiumLib);
    this.disableDefaultControls();

    this.layerManager = new LayerManager({
      engineType: "3d",
      viewer: this.viewer,
      CesiumLib,
    });
    this.devicePresentationAdapter = new CesiumDevicePresentationAdapter(this, this.options.devicePresentation3d || {});

    this.initBaseLayer();
    this.setSituationMode3d(this.options.situationMode3d || "balanced");
    this.initTerrain();
    this.initView();
    this.addWatermark(watermark);
    this.initClickEvent();
    this.logCesiumState("init");
  }

  configureSceneForQt() {
    if (!this.viewer) return;

    const { scene } = this.viewer;
    scene.globe.show = true;
    scene.globe.baseColor = CesiumLib.Color.fromCssColorString("#123b6d");
    scene.globe.enableLighting = false;
    scene.globe.depthTestAgainstTerrain = Boolean(
      this.occlusionConfig.enabled && this.occlusionConfig.depthTestAgainstTerrain
    );
    scene.fog.enabled = false;

    if (scene.skyAtmosphere) {
      scene.skyAtmosphere.show = true;
    }
  }

  disableDefaultControls() {
    if (!this.viewer) return;

    const selectors = [
      ".cesium-viewer-toolbar",
      ".cesium-viewer-animationContainer",
      ".cesium-viewer-timelineContainer",
      ".cesium-viewer-fullscreenContainer",
      ".cesium-viewer-bottom",
      ".cesium-credit-logoContainer",
      ".cesium-credit-textContainer",
      ".cesium-credit-expand-link",
    ];

    selectors.forEach((selector) => {
      this.viewer.container.querySelectorAll(selector).forEach((element) => {
        element.style.display = "none";
      });
    });

    if (this.viewer.cesiumWidget?.creditContainer) {
      this.viewer.cesiumWidget.creditContainer.style.display = "none";
    }
  }

  initView() {
    if (!this.viewer) return;

    const center = this.options.center || [104.0668, 30.5728];
    const zoom = this.options.zoom ?? 10;
    const height = this.options.cameraHeight || this.getCameraHeightByZoom(zoom);

    if (this.options.preserveViewOnSwitch) {
      this.viewer.camera.setView({
        destination: CesiumLib.Cartesian3.fromDegrees(center[0], center[1], height),
        orientation: {
          heading: this.options.heading ?? 0,
          pitch: this.options.pitch ?? CesiumLib.Math.toRadians(-90),
          roll: this.options.roll ?? 0,
        },
      });
      this.viewer.scene.requestRender?.();
      return;
    }

    const startHeight = this.options.initialCameraHeight || 22000000;

    this.viewer.camera.setView({
      destination: CesiumLib.Cartesian3.fromDegrees(104.0668, 30.5728, startHeight),
      orientation: {
        heading: 0,
        pitch: CesiumLib.Math.toRadians(-90),
        roll: 0,
      },
    });

    window.requestAnimationFrame(() => this.flyToHome());
    window.setTimeout(() => {
      this.flyToHome(0);
      this.viewer?.scene?.requestRender?.();
      this.logCesiumState("after-home");
    }, 300);
  }

  logCesiumState(stage) {
    if (!this.viewer) return;

    const { scene, camera, imageryLayers } = this.viewer;
    console.info("CesiumMap state", {
      stage,
      globeShow: scene.globe?.show,
      imageryLayerCount: imageryLayers?.length,
      cameraHeight: camera.positionCartographic?.height,
      heading: camera.heading,
      pitch: camera.pitch,
      roll: camera.roll,
    });
  }

  flyToHome(duration = this.options.initialFlyDuration ?? 2) {
    if (!this.viewer) return;

    const center = this.options.center || [104.0668, 30.5728];
    const zoom = this.options.zoom ?? 10;
    const height = this.options.cameraHeight || this.getCameraHeightByZoom(zoom);

    this.viewer.camera.flyTo({
      destination: CesiumLib.Cartesian3.fromDegrees(center[0], center[1], height),
      orientation: {
        heading: 0,
        pitch: CesiumLib.Math.toRadians(-90),
        roll: 0,
      },
      duration,
      easingFunction: CesiumLib.EasingFunction.CUBIC_IN_OUT,
    });
  }

  initBaseLayer() {
    const provider = this.options.baseMapProvider || "tianditu";

    if (provider !== "none") {
      this.setBaseLayer({
        provider,
        tiandituTk: this.options.tiandituTk,
        baseMapType: this.options.baseMapType || "img",
        showAnnotation: this.options.showAnnotation !== false,
        projection: this.options.projection || "w",
        minimumLevel: this.options.minimumLevel,
        maximumLevel: this.options.maximumLevel,
        url: this.options.baseMapUrl,
        bounds: this.options.bounds,
      });
    }

    this.addLayers(this.options.overlayLayers || []);
  }

  initTerrain() {
    if (!this.viewer) return null;

    const provider = this.options.terrainProvider;
    if (!provider || provider === "none" || provider === "ellipsoid") return this.viewer.terrainProvider;

    if (provider !== "cesium") {
      console.warn(`CesiumMap: unsupported terrain provider "${provider}", fallback to ellipsoid`);
      return this.viewer.terrainProvider;
    }

    const url = this.options.terrainUrl;
    if (!url) {
      console.warn("CesiumMap: terrainUrl is required when terrainProvider is cesium");
      return this.viewer.terrainProvider;
    }

    try {
      const terrainProvider = new CesiumLib.CesiumTerrainProvider({ url });
      terrainProvider.errorEvent?.addEventListener?.((error) => {
        console.warn("CesiumMap: terrain provider reported an error", error);
      });
      Promise.resolve(terrainProvider.readyPromise)
        .then(() => {
          if (!this.viewer || this.viewer.isDestroyed?.()) return;
          this.viewer.terrainProvider = terrainProvider;
          this.viewer.scene.globe.depthTestAgainstTerrain = Boolean(
            this.occlusionConfig.enabled && this.occlusionConfig.depthTestAgainstTerrain
          );
          this.devicePresentationAdapter?.handleTerrainChanged?.();
          this.viewer.scene?.requestRender?.();
        })
        .catch((error) => {
          console.warn("CesiumMap: terrain unavailable, keep ellipsoid terrain", error);
        });
      return terrainProvider;
    } catch (error) {
      console.warn("CesiumMap: terrain init failed, keep ellipsoid terrain", error);
      return this.viewer.terrainProvider;
    }
  }

  setSituationMode3d(mode = "balanced") {
    const presets = {
      default: { brightness: 1, contrast: 1, saturation: 1, gamma: 1 },
      balanced: { brightness: 0.82, contrast: 1.12, saturation: 0.66, gamma: 1.05 },
      tactical: { brightness: 0.62, contrast: 1.28, saturation: 0.38, gamma: 1.12 },
    };
    const preset = presets[mode] || presets.balanced;
    this.situationMode3d = presets[mode] ? mode : "balanced";
    const imageryLayers = this.viewer?.imageryLayers;
    for (let index = 0; index < (imageryLayers?.length || 0); index += 1) {
      const layer = imageryLayers.get(index);
      layer.brightness = preset.brightness;
      layer.contrast = preset.contrast;
      layer.saturation = preset.saturation;
      layer.gamma = preset.gamma;
    }
    this.viewer?.scene?.requestRender?.();
    return this.situationMode3d;
  }

  setOcclusion3d(options = {}) {
    this.occlusionConfig = resolveOcclusionConfig({ ...this.occlusionConfig, ...options });
    if (this.viewer?.scene?.globe) {
      this.viewer.scene.globe.depthTestAgainstTerrain = Boolean(
        this.occlusionConfig.enabled && this.occlusionConfig.depthTestAgainstTerrain
      );
      this.viewer.scene.requestRender?.();
    }
    this.devicePresentationAdapter?.setOcclusionConfig?.(this.occlusionConfig);
    return { ...this.occlusionConfig };
  }

  getOcclusion3d() {
    return { ...this.occlusionConfig };
  }

  setBaseLayer(options = {}) {
    if (!this.layerManager) {
      console.warn("CesiumMap: map is not initialized");
      return null;
    }

    const result = this.layerManager.setBaseLayer(options);
    if (this.situationMode3d) this.setSituationMode3d(this.situationMode3d);
    return result;
  }

  addLayers(layers = []) {
    return this.layerManager?.addLayers(layers) || [];
  }

  addLayer(options = {}) {
    if (!this.layerManager) {
      console.warn("CesiumMap: map is not initialized");
      return null;
    }

    return this.layerManager.addLayer(options);
  }

  removeLayer(id) {
    return this.layerManager?.removeLayer(id);
  }

  getLayer(id) {
    return this.layerManager?.getLayer(id);
  }

  getNativeLayer(id) {
    return this.layerManager?.getNativeLayer(id);
  }

  getLayerInfo(id) {
    return this.layerManager?.getLayerInfo(id);
  }

  listLayers() {
    return this.layerManager?.listLayers() || [];
  }

  hasLayer(id) {
    return this.layerManager?.hasLayer(id);
  }

  showLayer(id) {
    return this.layerManager?.showLayer(id);
  }

  hideLayer(id) {
    return this.layerManager?.hideLayer(id);
  }

  setLayerVisible(id, visible) {
    return this.layerManager?.setLayerVisible(id, visible);
  }

  setLayerOpacity(id, opacity) {
    return this.layerManager?.setOpacity(id, opacity);
  }

  setLayerZIndex(id, zIndex) {
    return this.layerManager?.setZIndex(id, zIndex);
  }

  clearLayers() {
    return this.layerManager?.clearLayers();
  }

  clearOverlayLayers() {
    return this.layerManager?.clearOverlayLayers();
  }

  clearBaseLayers() {
    return this.layerManager?.clearBaseLayers();
  }

  getBaseLayerIds() {
    return this.layerManager?.getBaseLayerIds() || [];
  }

  getLayerManager() {
    return this.layerManager;
  }

  zoomIn() {
    if (!this.viewer) return;
    this.viewer.camera.zoomIn(this.viewer.camera.positionCartographic.height * 0.45);
  }

  zoomOut() {
    if (!this.viewer) return;
    this.viewer.camera.zoomOut(this.viewer.camera.positionCartographic.height * 0.45);
  }

  resetView() {
    if (!this.viewer) return;

    const center = this.options.center || [104.0668, 30.5728];
    const zoom = this.options.zoom ?? 10;
    const height = this.options.cameraHeight || this.getCameraHeightByZoom(zoom);

    this.viewer.camera.flyTo({
      destination: CesiumLib.Cartesian3.fromDegrees(center[0], center[1], height),
      orientation: {
        heading: 0,
        pitch: CesiumLib.Math.toRadians(-90),
        roll: 0,
      },
      duration: this.options.resetFlyDuration ?? 0.8,
      easingFunction: CesiumLib.EasingFunction.CUBIC_IN_OUT,
    });
  }

  getCameraOrientation() {
    if (!this.viewer) return null;

    const camera = this.viewer.camera;
    const heading = camera.heading || 0;
    const pitch = camera.pitch || 0;
    const roll = camera.roll || 0;
    const headingDegrees = CesiumLib.Math.toDegrees(heading);
    const pitchDegrees = CesiumLib.Math.toDegrees(pitch);
    const rollDegrees = CesiumLib.Math.toDegrees(roll);
    const tilt = Math.max(0, Math.min(75, pitchDegrees + 90));

    return {
      heading,
      pitch,
      roll,
      tilt,
      headingDegrees,
      pitchDegrees,
      rollDegrees,
    };
  }

  setCameraOrientation(options = {}) {
    if (!this.viewer) return null;

    const camera = this.viewer.camera;
    const heading = normalizeHeading(
      readNumber(options.heading, degreesToRadians(options.headingDegrees), camera.heading || 0)
    );
    const pitch = normalizePitch(
      readNumber(options.pitch, tiltToPitch(options.tilt), camera.pitch || CesiumLib.Math.toRadians(-90))
    );
    const roll = 0;
    const duration = Math.max(0, Number(options.duration) || 0);
    const destination = camera.positionWC?.clone?.() || camera.position.clone();
    const orientation = { heading, pitch, roll };

    if (duration > 0) {
      camera.flyTo({
        destination,
        orientation,
        duration,
        easingFunction: CesiumLib.EasingFunction.CUBIC_IN_OUT,
      });
    } else {
      camera.setView({ destination, orientation });
    }

    return this.getCameraOrientation();
  }

  resetCameraOrientation() {
    return this.setCameraOrientation({
      heading: 0,
      pitch: CesiumLib.Math.toRadians(-90),
      duration: this.options.resetFlyDuration ?? 0.35,
    });
  }

  centerAt(position, options = {}) {
    if (!this.viewer || !Array.isArray(position) || position.length < 2) return null;

    const lng = Number(position[0]);
    const lat = Number(position[1]);
    const height = Math.max(10, Number(options.height ?? 3500));
    if (!Number.isFinite(lng) || !Number.isFinite(lat) || !Number.isFinite(height)) return null;

    const camera = this.viewer.camera;
    const heading = readNumber(options.heading, degreesToRadians(options.headingDegrees), camera.heading || 0);
    const pitch = normalizePitch(readNumber(angleToRadians(options.pitch), degreesToRadians(options.pitchDegrees), CesiumLib.Math.toRadians(-55)));
    const duration = normalizeFlyDuration(options.duration ?? 0.28);
    const target = CesiumLib.Cartesian3.fromDegrees(lng, lat);
    const range = Math.max(100, Number(options.range) || height / Math.max(0.2, Math.sin(Math.abs(pitch))));
    const offset = new CesiumLib.HeadingPitchRange(normalizeHeading(heading), pitch, range);

    camera.cancelFlight?.();

    if (duration > 0) {
      camera.flyToBoundingSphere(new CesiumLib.BoundingSphere(target, 1), {
        offset,
        duration,
        easingFunction: CesiumLib.EasingFunction.CUBIC_IN_OUT,
      });
    } else {
      camera.lookAt(target, offset);
      camera.lookAtTransform(CesiumLib.Matrix4.IDENTITY);
    }

    this.viewer.scene.requestRender?.();
    return { position: [lng, lat], height, range, orientation: { heading: normalizeHeading(heading), pitch, roll: 0 } };
  }

  getStatus() {
    if (!this.viewer) return {};

    const camera = this.viewer.camera;
    const cartographic = camera.positionCartographic;
    const cameraLng = CesiumLib.Math.toDegrees(cartographic.longitude);
    const cameraLat = CesiumLib.Math.toDegrees(cartographic.latitude);
    const lngLat = this.pointerLngLat || [cameraLng, cameraLat];
    const cameraHeight = cartographic.height;

    return {
      lng: lngLat[0],
      lat: lngLat[1],
      height: lngLat[2] ?? 0,
      cameraHeight,
      zoom: this.getApproxZoom(cameraHeight),
    };
  }

  getViewState() {
    if (!this.viewer) return null;

    const camera = this.viewer.camera;
    const cartographic = camera.positionCartographic;
    const cameraHeight = cartographic.height;
    const center = this.getCanvasCenterLngLat() || [
      CesiumLib.Math.toDegrees(cartographic.longitude),
      CesiumLib.Math.toDegrees(cartographic.latitude),
    ];
    const orientation = this.getCameraOrientation() || {};

    return {
      type: "3d",
      center,
      zoom: this.getApproxZoom(cameraHeight),
      cameraHeight,
      heading: camera.heading || 0,
      pitch: camera.pitch || CesiumLib.Math.toRadians(-90),
      roll: camera.roll || 0,
      orientation,
    };
  }

  getCanvasCenterLngLat() {
    const canvas = this.viewer?.scene?.canvas;
    if (!canvas) return null;
    return this.getLngLatFromScreen(
      new CesiumLib.Cartesian2(canvas.clientWidth / 2, canvas.clientHeight / 2)
    );
  }

  getApproxZoom(cameraHeight) {
    if (!Number.isFinite(cameraHeight) || cameraHeight <= 0) return null;
    const earthCircumference = 40075016.68557849;
    const viewportHeight = this.getViewportHeight();
    const fovy = this.getCameraFovy();
    const visibleMeters = 2 * cameraHeight * Math.tan(fovy / 2);
    const metersPerPixel = visibleMeters / viewportHeight;
    return Math.max(0, Math.min(22, Math.log2(earthCircumference / (256 * metersPerPixel))));
  }

  getCameraHeightByZoom(zoom) {
    const earthCircumference = 40075016.68557849;
    const normalizedZoom = Number.isFinite(Number(zoom)) ? Number(zoom) : 10;
    const metersPerPixel = earthCircumference / (256 * 2 ** normalizedZoom);
    const visibleMeters = metersPerPixel * this.getViewportHeight();
    return visibleMeters / (2 * Math.tan(this.getCameraFovy() / 2));
  }

  getViewportHeight() {
    const canvas = this.viewer?.scene?.canvas;
    return Math.max(1, canvas?.clientHeight || canvas?.height || 768);
  }

  getCameraFovy() {
    const fovy = this.viewer?.camera?.frustum?.fovy;
    return Number.isFinite(fovy) ? fovy : CesiumLib.Math.toRadians(60);
  }

  initClickEvent() {
    if (!this.viewer) return;

    this.clickHandler = new CesiumLib.ScreenSpaceEventHandler(
      this.viewer.scene.canvas
    );

    this.clickHandler.setInputAction((movement) => {
      this.pointerLngLat = this.getLngLatFromScreen(movement.endPosition);

      const picked = this.viewer.scene.pick(movement.endPosition);
      const isMarker = CesiumLib.defined(picked) && picked.id && this.markers.has(picked.id.id);
      const isObject = CesiumLib.defined(picked) && picked.id && this.spatialObjects.has(picked.id.id);
      const isCluster = this.options.mapEngine?.getClusterManager?.()?.adapter?.isClusterEntity?.(picked?.id);
      const isDrawFeature = Boolean(this.getDrawFeatureFromEntity(picked?.id));
      if (isObject) {
        const object = picked.id.properties?.spatialObject?.getValue?.() || picked.id.properties?.spatialObject;
        this.emit("object:hover", {
          id: picked.id.id,
          object,
          target: picked.id,
          position: this.getEntityLngLat(picked.id),
          screenPosition: movement.endPosition,
          originalEvent: movement,
        });
      }

      this.viewer.scene.canvas.style.cursor = isMarker || isObject || isCluster || isDrawFeature ? "pointer" : "";
    }, CesiumLib.ScreenSpaceEventType.MOUSE_MOVE);

    this.clickHandler.setInputAction((movement) => {
      const picked = this.viewer.scene.pick(movement.position);
      const deviceObject = this.devicePresentationAdapter?.getObjectFromPicked?.(picked);
      if (deviceObject) {
        const lnglat = this.getEntityLngLat(picked?.id) || this.getLngLatFromScreen(movement.position);
        this.pointerLngLat = lnglat;
        this.emit("object:click", {
          id: deviceObject.id,
          object: deviceObject,
          target: picked.id || picked.primitive,
          position: lnglat,
          screenPosition: movement.position,
          originalEvent: movement,
        });
        this.showSpatialObjectPopup(deviceObject, movement.position);
        return;
      }

      if (CesiumLib.defined(picked) && picked.id) {
        const entity = picked.id;
        const clusterAdapter = this.options.mapEngine?.getClusterManager?.()?.adapter;
        if (clusterAdapter?.handleClusterClick?.(entity, movement)) return;

        const drawFeature = this.getDrawFeatureFromEntity(entity);
        const lnglat = this.getEntityLngLat(entity) || this.getLngLatFromScreen(movement.position);

        this.pointerLngLat = lnglat;

        if (drawFeature) {
          this.emit("click", {
            type: "draw",
            target: entity,
            id: drawFeature.properties?.id,
            name: drawFeature.properties?.name,
            feature: drawFeature,
            lnglat,
            screenPosition: movement.position,
            originalEvent: movement,
          });

          this.showDrawFeaturePopup(drawFeature, movement.position);
          return;
        }

        if (this.spatialObjects.has(entity.id)) {
          const object = entity.properties?.spatialObject?.getValue?.() || entity.properties?.spatialObject;
          this.emit("object:click", {
            id: entity.id,
            object,
            target: entity,
            position: lnglat,
            screenPosition: movement.position,
            originalEvent: movement,
          });
          this.showSpatialObjectPopup(object, movement.position);
          return;
        }

        this.emit("click", {
          type: "marker",
          target: entity,
          id: entity.id,
          name: entity.name,
          lnglat,
          screenPosition: movement.position,
          originalEvent: movement,
        });

        this.showMarkerPopup(entity, movement.position);
        return;
      }

      const lnglat = this.getLngLatFromScreen(movement.position);
      if (!lnglat) return;

      this.pointerLngLat = lnglat;

      this.hidePopup();
      this.emit("click", {
        type: "map",
        target: this,
        lnglat,
        screenPosition: movement.position,
        originalEvent: movement,
      });
    }, CesiumLib.ScreenSpaceEventType.LEFT_CLICK);
  }

  getDrawFeatureFromEntity(entity) {
    if (!entity?.properties || !this.viewer) return null;

    const time = this.viewer.clock.currentTime;
    const property = entity.properties.drawFeature;

    return property?.getValue?.(time) || property || null;
  }

  getLngLatFromScreen(screenPosition) {
    return this.pickGroundLngLat(screenPosition, { includeHeight: true });
  }

  pickGroundLngLat(screenPosition, options = {}) {
    if (!this.viewer || !screenPosition) return null;

    const cartesian = this.pickGroundCartesian(screenPosition);
    if (!cartesian) return null;

    let cartographic;
    try {
      cartographic = CesiumLib.Cartographic.fromCartesian(cartesian);
    } catch (error) {
      return null;
    }
    if (
      !cartographic
      || !Number.isFinite(cartographic.longitude)
      || !Number.isFinite(cartographic.latitude)
      || !Number.isFinite(cartographic.height)
    ) return null;
    const result = [
      CesiumLib.Math.toDegrees(cartographic.longitude),
      CesiumLib.Math.toDegrees(cartographic.latitude),
    ];

    if (options.includeHeight) result.push(cartographic.height || 0);
    return result;
  }

  pickGroundCartesian(screenPosition) {
    if (!this.viewer || !screenPosition) return null;

    const { scene, camera } = this.viewer;
    let cartesian = null;

    const ray = camera.getPickRay(screenPosition);
    if (ray) {
      try {
        cartesian = scene.globe?.pick(ray, scene) || null;
      } catch (error) {
        cartesian = null;
      }
      if (!isFiniteCartesian3(cartesian)) cartesian = null;
    }

    if (!cartesian && scene.pickPositionSupported) {
      try {
        cartesian = scene.pickPosition(screenPosition);
      } catch (error) {
        cartesian = null;
      }
      if (!isFiniteCartesian3(cartesian)) cartesian = null;
    }

    if (!cartesian) {
      try {
        cartesian = camera.pickEllipsoid(
          screenPosition,
          scene.globe.ellipsoid
        );
      } catch (error) {
        cartesian = null;
      }
    }

    return isFiniteCartesian3(cartesian) ? cartesian : null;
  }

  getEntityLngLat(entity) {
    if (!entity || !entity.position) return null;

    const time = this.viewer.clock.currentTime;
    const cartesian = entity.position.getValue(time);

    if (!cartesian) return null;

    const cartographic = CesiumLib.Cartographic.fromCartesian(cartesian);

    return [
      CesiumLib.Math.toDegrees(cartographic.longitude),
      CesiumLib.Math.toDegrees(cartographic.latitude),
    ];
  }

  on(eventName, callback) {
    if (!eventName || typeof callback !== "function") return;

    if (!this.events.has(eventName)) {
      this.events.set(eventName, []);
    }

    this.events.get(eventName).push(callback);
  }

  off(eventName, callback) {
    const callbacks = this.events.get(eventName);
    if (!callbacks) return;

    const index = callbacks.indexOf(callback);

    if (index > -1) {
      callbacks.splice(index, 1);
    }
  }

  emit(eventName, data) {
    const callbacks = this.events.get(eventName);
    if (!callbacks) return;

    callbacks.forEach((callback) => {
      callback(data);
    });
  }

  showMarkerPopup(entity, screenPosition) {
    if (!this.viewer || !entity) return;

    const container =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!container) return;

    this.hidePopup();

    const popup = entity.properties?.popup?.getValue?.() || null;
    const rawMarker = entity.properties?.rawMarker?.getValue?.() || entity.properties?.rawMarker || {};
    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: {
        id: entity.id,
        name: entity.name,
        type: "marker",
        position: rawMarker.position || this.getEntityLngLat(entity),
        properties: rawMarker.data || {},
      },
      options: this.options.popup || {},
      popup,
    });
  }

  showSpatialObjectPopup(object, screenPosition) {
    const container = typeof this.options.container === "string"
      ? document.getElementById(this.options.container)
      : this.options.container;
    if (!container || !object) return;
    this.hidePopup();
    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: object,
      options: this.options.popup || {},
      popup: object.properties?.popup || null,
    });
  }

  showDrawFeaturePopup(feature, screenPosition) {
    if (!this.viewer || !feature) return;

    const container =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!container) return;

    this.hidePopup();

    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: feature,
      options: this.options.popup || {},
      popup: feature.properties?.popup || null,
    });
  }

  hidePopup() {
    if (this.popupEl) {
      this.popupEl.remove();
      this.popupEl = null;
    }
  }

  addMarkers(markers = []) {
    if (!Array.isArray(markers)) return [];
    return markers.map((marker) => this.addMarker(marker)).filter(Boolean);
  }

  getMarker(id) {
    return this.markers.get(id) || null;
  }

  hasMarker(id) {
    return this.markers.has(id);
  }

  listMarkers() {
    return Array.from(this.markers.values());
  }

  addMarker(marker = {}) {
    if (!this.viewer) return null;

    const {
      id,
      position,
      name = "未命名点位",
      color = "RED",
      icon,
      iconWidth = 36,
      iconHeight = 36,
      iconAnchor = [0.5, 1],
      rotationDegrees,
      rotationReference = "screen",
      occlusion3d,
      label = {},
      popup = null,
      data = {},
    } = marker;

    if (!id) {
      console.warn("addMarker failed: marker.id is required");
      return null;
    }

    if (!Array.isArray(position) || position.length < 2) {
      console.warn("addMarker failed: marker.position is required");
      return null;
    }

    if (this.markers.has(id)) {
      this.removeMarker(id);
    }

    const absoluteHeight = getAbsoluteMarkerHeight(position);
    const isOccludedGroundMarker = occlusion3d === true && absoluteHeight === null;
    const heightReference = isOccludedGroundMarker
      ? CesiumLib.HeightReference.RELATIVE_TO_GROUND
      : absoluteHeight === null
        ? CesiumLib.HeightReference.CLAMP_TO_GROUND
        : CesiumLib.HeightReference.NONE;
    const disableDepthTestDistance = occlusion3d === true || (occlusion3d !== false && absoluteHeight !== null)
      ? 0
      : Number.POSITIVE_INFINITY;
    const entityOptions = {
      id,
      name,
      position: CesiumLib.Cartesian3.fromDegrees(
        Number(position[0]),
        Number(position[1]),
        absoluteHeight ?? (isOccludedGroundMarker ? 2 : 0),
      ),
      properties: {
        markerData: data,
        popup,
        rawMarker: marker,
      },
    };

    if (icon) {
      const rotation = rotationDegrees === null || rotationDegrees === undefined ? NaN : Number(rotationDegrees);
      entityOptions.billboard = {
        image: icon,
        width: iconWidth,
        height: iconHeight,
        verticalOrigin: Array.isArray(iconAnchor) && iconAnchor[1] === 0.5
          ? CesiumLib.VerticalOrigin.CENTER
          : CesiumLib.VerticalOrigin.BOTTOM,
        rotation: this.createBillboardRotation(position, rotation, rotationReference),
        alignedAxis: CesiumLib.Cartesian3.ZERO,
        heightReference,
        // 有绝对高度的实体默认参与地形/实体深度检测；需要遮挡的地面标记
        // 会相对地面抬高 2 米，避免中心锚点与地形深度面发生闪烁。
        disableDepthTestDistance,
      };
    } else {
      entityOptions.point = {
        pixelSize: marker.pixelSize || 12,
        color: CesiumLib.Color[color] || CesiumLib.Color.RED,
        outlineColor: CesiumLib.Color.WHITE,
        outlineWidth: 2,
        heightReference,
        disableDepthTestDistance,
      };
    }

    if (label.show !== false) {
      entityOptions.label = {
        text: label.text || name,
        font: label.font || "14px sans-serif",
        fillColor: label.fillColor
          ? CesiumLib.Color.fromCssColorString(label.fillColor)
          : CesiumLib.Color.WHITE,
        outlineColor: label.outlineColor
          ? CesiumLib.Color.fromCssColorString(label.outlineColor)
          : CesiumLib.Color.BLACK,
        outlineWidth: label.outlineWidth ?? 2,
        style: CesiumLib.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new CesiumLib.Cartesian2(
          label.offsetX ?? 0,
          label.offsetY ?? -36
        ),
        distanceDisplayCondition: new CesiumLib.DistanceDisplayCondition(
          label.minDistance ?? 0,
          label.maxDistance ?? 500000
        ),
        disableDepthTestDistance,
      };
    }

    const entity = this.viewer.entities.add(entityOptions);
    this.markers.set(id, entity);
    return entity;
  }

  updateMarker(id, patch = {}) {
    if (!this.viewer) return null;

    const entity = this.markers.get(id);
    if (!entity) return null;

    const previous = entity.properties?.rawMarker?.getValue?.() || entity.properties?.rawMarker || {};
    const next = { ...previous, ...patch, id };
    const {
      position,
      name = previous.name || "未命名点位",
      icon = previous.icon,
      iconWidth = previous.iconWidth || 36,
      iconHeight = previous.iconHeight || 36,
      iconAnchor = previous.iconAnchor || [0.5, 1],
      rotationDegrees = previous.rotationDegrees,
      rotationReference = previous.rotationReference || "screen",
      occlusion3d = previous.occlusion3d,
      label = previous.label || {},
      popup = previous.popup ?? null,
      data = previous.data || {},
    } = next;

    if (Array.isArray(position) && position.length >= 2) {
      const absoluteHeight = getAbsoluteMarkerHeight(position);
      const isOccludedGroundMarker = occlusion3d === true && absoluteHeight === null;
      const heightReference = isOccludedGroundMarker
        ? CesiumLib.HeightReference.RELATIVE_TO_GROUND
        : absoluteHeight === null
          ? CesiumLib.HeightReference.CLAMP_TO_GROUND
          : CesiumLib.HeightReference.NONE;
      entity.position = CesiumLib.Cartesian3.fromDegrees(
        Number(position[0]),
        Number(position[1]),
        absoluteHeight ?? (isOccludedGroundMarker ? 2 : 0),
      );
      if (entity.billboard) entity.billboard.heightReference = heightReference;
      if (entity.point) entity.point.heightReference = heightReference;
      const disableDepthTestDistance = occlusion3d === true || (occlusion3d !== false && absoluteHeight !== null)
        ? 0
        : Number.POSITIVE_INFINITY;
      if (entity.billboard) entity.billboard.disableDepthTestDistance = disableDepthTestDistance;
      if (entity.point) entity.point.disableDepthTestDistance = disableDepthTestDistance;
      if (entity.label) entity.label.disableDepthTestDistance = disableDepthTestDistance;
    }

    entity.name = name;
    entity.properties = {
      markerData: data,
      popup,
      rawMarker: next,
    };

    if (entity.label && label.show !== false) {
      entity.label.text = label.text || name;
      if (label.fillColor) entity.label.fillColor = CesiumLib.Color.fromCssColorString(label.fillColor);
    }

    if (entity.billboard) {
      const rotation = rotationDegrees === null || rotationDegrees === undefined ? NaN : Number(rotationDegrees);
      entity.billboard.image = icon || entity.billboard.image;
      entity.billboard.width = iconWidth;
      entity.billboard.height = iconHeight;
      entity.billboard.verticalOrigin = Array.isArray(iconAnchor) && iconAnchor[1] === 0.5
        ? CesiumLib.VerticalOrigin.CENTER
        : CesiumLib.VerticalOrigin.BOTTOM;
      entity.billboard.rotation = this.createBillboardRotation(position, rotation, rotationReference);
      entity.billboard.alignedAxis = CesiumLib.Cartesian3.ZERO;
    }

    this.viewer.scene.requestRender?.();
    return entity;
  }

  createBillboardRotation(position, rotationDegrees, rotationReference = "screen") {
    if (!Number.isFinite(rotationDegrees)) return 0;
    const fallbackRotation = CesiumLib.Math.toRadians(-rotationDegrees);
    if (rotationReference !== "geographic" || !Array.isArray(position) || position.length < 2) {
      return fallbackRotation;
    }

    const directionEnd = destinationPointAtBearing(position, rotationDegrees, 10_000);
    if (!directionEnd) return fallbackRotation;
    const height = Number.isFinite(Number(position[2])) ? Number(position[2]) : 0;
    const startCartesian = CesiumLib.Cartesian3.fromDegrees(
      Number(position[0]),
      Number(position[1]),
      height,
    );
    const endCartesian = CesiumLib.Cartesian3.fromDegrees(
      directionEnd[0],
      directionEnd[1],
      height,
    );
    const startWindow = new CesiumLib.Cartesian2();
    const endWindow = new CesiumLib.Cartesian2();

    // Billboard 本身始终朝向相机，因此不能仅使用固定的 alignedAxis。
    // 每帧将设备位置和地理方位方向点投影到屏幕，箭头即可始终与地图上的
    // 方位线/扇形轴线重合，同时正确响应相机航向和俯仰变化。
    return new CesiumLib.CallbackProperty(() => {
      const viewer = this.viewer;
      if (!viewer || viewer.isDestroyed?.()) return fallbackRotation;
      const startScreen = CesiumLib.SceneTransforms.wgs84ToWindowCoordinates(
        viewer.scene,
        startCartesian,
        startWindow,
      );
      const endScreen = CesiumLib.SceneTransforms.wgs84ToWindowCoordinates(
        viewer.scene,
        endCartesian,
        endWindow,
      );
      if (!startScreen || !endScreen) return fallbackRotation;
      const deltaX = endScreen.x - startScreen.x;
      const deltaY = endScreen.y - startScreen.y;
      if (!Number.isFinite(deltaX) || !Number.isFinite(deltaY) || Math.hypot(deltaX, deltaY) < 0.5) {
        return fallbackRotation;
      }
      return -Math.atan2(deltaX, -deltaY);
    }, false);
  }

  removeMarkers(ids = []) {
    if (!Array.isArray(ids)) return [];
    return ids.map((id) => this.removeMarker(id));
  }

  removeMarker(id) {
    if (!this.viewer) return false;

    const entity = this.markers.get(id);
    if (!entity) return false;

    this.viewer.entities.remove(entity);
    this.markers.delete(id);
    return true;
  }

  clearMarkers() {
    if (!this.viewer) return;

    this.markers.forEach((entity) => {
      this.viewer.entities.remove(entity);
    });

    this.markers.clear();
  }

  focusOnTarget(targetId, options = {}) {
    const entity = this.devicePresentationAdapter?.getFocusEntity?.(targetId)
      || this.spatialObjects.get(String(targetId))
      || this.markers.get(String(targetId));
    const pitch = Number.isFinite(Number(options.pitch)) ? Number(options.pitch) : CesiumLib.Math.toRadians(-30);
    const zoom = Number(options.zoom);
    const range = Number.isFinite(zoom) && !Number.isFinite(Number(options.range))
      ? this.getCameraHeightByZoom(zoom) / Math.max(0.2, Math.sin(Math.abs(pitch)))
      : options.range;
    return this.targetFocusController?.focus(entity, { ...options, pitch, range }) || null;
  }

  renderObject(object) {
    return this.updateObject(object);
  }

  updateObject(object = {}) {
    if (!object?.id || !this.viewer) return null;
    const isDevicePresentation = object.type === "marker" && Boolean(
      object.properties?.presentation3d || object.properties?.role === "uav"
    );
    if (isDevicePresentation && this.devicePresentationAdapter) {
      this.removeMarker(object.id);
      return this.devicePresentationAdapter.upsert(object);
    }
    if (this.devicePresentationAdapter?.bundles?.has(String(object.id))) this.devicePresentationAdapter.remove(object.id);
    if (object.type === "marker" || object.type === "text") {
      return this.addMarker(this.objectToMarker(object));
    }

    // 动态地图效果（例如干扰波前）会在每一帧更新线的坐标。直接删除并重建
    // Cesium Entity 会使 3D 地形场景持续错过渲染帧，因此线对象改为原地更新。
    const existingObject = this.spatialObjects.get(String(object.id));
    if (
      existingObject?.polyline
      && object.type === "line"
      && Array.isArray(object.geometry?.coordinates)
    ) {
      const previousSpatialObject = existingObject.properties?.spatialObject?.getValue?.()
        || existingObject.properties?.spatialObject
        || {};
      const previousStyle = getCesiumPolylineStyle(previousSpatialObject.style || {});
      const nextStyle = getCesiumPolylineStyle(object.style || {});
      const polylineStyleChanged = JSON.stringify(previousStyle) !== JSON.stringify(nextStyle);
      existingObject.name = object.properties?.name || object.id;
      existingObject.properties = { spatialObject: object };
      const nextPolyline = this.createPolylineGraphics(object);
      // CallbackProperty 动态线只更新内部坐标缓存，positions 属性对象保持
      // 不变，避免高频替换 ConstantProperty 使异步几何持续失效。
      if (object.style?.dynamicPositions !== true) {
        existingObject.polyline.positions = nextPolyline.positions;
      }
      // 动态波纹每帧只改变坐标。样式未变时保留原 Cesium 材质，避免每帧
      // 创建/替换 PolylineGlowMaterialProperty 导致发光线始终无法稳定绘制。
      if (polylineStyleChanged) {
        existingObject.polyline.width = nextPolyline.width;
        existingObject.polyline.material = nextPolyline.material;
        existingObject.polyline.clampToGround = nextPolyline.clampToGround;
        if (nextPolyline.arcType !== undefined) existingObject.polyline.arcType = nextPolyline.arcType;
        if (nextPolyline.zIndex !== undefined) existingObject.polyline.zIndex = nextPolyline.zIndex;
      }
      this.viewer.scene.requestRender?.();
      return existingObject;
    }

    this.removeObject(object.id);
    const entityOptions = this.createObjectEntityOptions(object);
    if (!entityOptions) return null;
    const entity = this.viewer.entities.add(entityOptions);
    this.spatialObjects.set(object.id, entity);
    this.viewer.scene.requestRender?.();
    return entity;
  }

  removeObject(id) {
    if (this.popupEl?.dataset?.mapObjectId === String(id)) this.hidePopup();
    if (this.devicePresentationAdapter?.remove(id)) return true;
    if (this.markers.has(id)) return this.removeMarker(id);
    const entity = this.spatialObjects.get(id);
    if (!entity || !this.viewer) return false;
    this.viewer.entities.remove(entity);
    this.spatialObjects.delete(id);
    this.dynamicPolylineStates?.delete(String(id));
    this.viewer.scene.requestRender?.();
    return true;
  }

  clearObjects() {
    this.clearMarkers();
    this.devicePresentationAdapter?.destroy?.();
    this.devicePresentationAdapter = this.viewer ? new CesiumDevicePresentationAdapter(this, this.options.devicePresentation3d || {}) : null;
    this.spatialObjects.forEach((entity) => this.viewer?.entities.remove(entity));
    this.spatialObjects.clear();
    this.dynamicPolylineStates?.clear();
  }

  queryFeatureAtPixel(pixel, options = {}) {
    if (!this.viewer || !pixel) return null;
    const position = Array.isArray(pixel)
      ? new CesiumLib.Cartesian2(pixel[0], pixel[1])
      : new CesiumLib.Cartesian2(pixel.x ?? pixel.clientX ?? 0, pixel.y ?? pixel.clientY ?? 0);
    const picked = this.viewer.scene.pick(position);
    if (!CesiumLib.defined(picked) || !picked.id) return null;
    return this.entityToQueryResult(picked.id, { screenPosition: pixel, originalEvent: options.originalEvent });
  }

  queryObjectsByBounds(bounds) {
    if (!Array.isArray(bounds) || bounds.length < 4) return [];
    const [minLng, minLat, maxLng, maxLat] = bounds.map(Number);
    return this.listQueryableEntities().filter(({ object }) =>
      getObjectCoordinates(object).some(([lng, lat]) => lng >= minLng && lng <= maxLng && lat >= minLat && lat <= maxLat)
    );
  }

  queryObjectsByPoint(point, options = {}) {
    if (!Array.isArray(point)) return [];
    const [lng, lat] = point.map(Number);
    const tolerance = Number(options.tolerance ?? 0.0005);
    return this.listQueryableEntities().filter(({ object }) =>
      getObjectCoordinates(object).some(
        ([objectLng, objectLat]) => Math.abs(objectLng - lng) <= tolerance && Math.abs(objectLat - lat) <= tolerance
      )
    );
  }

  listQueryableEntities() {
    return [...Array.from(this.markers.values()), ...Array.from(this.spatialObjects.values())]
      .map((entity) => this.entityToQueryResult(entity))
      .filter(Boolean);
  }

  entityToQueryResult(entity, extra = {}) {
    const object = getEntityProperty(entity, "spatialObject") || markerToSpatialObject(getEntityProperty(entity, "rawMarker"));
    if (!object?.id) return null;
    return {
      id: String(object.id),
      object,
      target: entity,
      position: object.position || this.getEntityLngLat(entity) || getObjectCoordinates(object)[0],
      ...extra,
    };
  }

  getDevicePresentationDiagnostics() {
    return {
      viewerEntityCount: this.viewer?.entities?.values?.length || 0,
      ...(this.devicePresentationAdapter?.getDiagnostics?.() || {}),
    };
  }

  objectToMarker(object) {
    return {
      id: object.id,
      name: object.properties?.name || object.style?.label?.text || object.id,
      position: object.position,
      icon: object.style?.icon,
      iconWidth: object.style?.iconWidth,
      iconHeight: object.style?.iconHeight,
      iconAnchor: object.style?.iconAnchor,
      rotationDegrees: object.style?.rotationDegrees,
      rotationReference: object.style?.rotationReference,
      occlusion3d: object.style?.occlusion3d,
      color: object.style?.color,
      label: object.type === "text"
        ? { ...(object.style?.label || {}), text: object.properties?.text || object.style?.text || object.properties?.name || object.id }
        : object.style?.label,
      popup: object.properties?.popup,
      data: object.properties || {},
    };
  }

  createObjectEntityOptions(object) {
    const style = object.style || {};
    const entity = {
      id: object.id,
      name: object.properties?.name || object.id,
      properties: {
        spatialObject: object,
      },
    };

    if (object.type === "line" && Array.isArray(object.geometry?.coordinates)) {
      entity.polyline = this.createPolylineGraphics(object, style);
      return entity;
    }

    if (object.type === "polygon" && Array.isArray(object.geometry?.coordinates)) {
      const ring = Array.isArray(object.geometry.coordinates[0]?.[0])
        ? object.geometry.coordinates[0]
        : object.geometry.coordinates;
      const hasAbsoluteHeight = ring.some(
        (coordinate) => getAbsoluteMarkerHeight(coordinate) !== null,
      );
      entity.polygon = {
        hierarchy: ring.map((coordinate) =>
          CesiumLib.Cartesian3.fromDegrees(
            Number(coordinate[0]),
            Number(coordinate[1]),
            getAbsoluteMarkerHeight(coordinate) ?? 0,
          )
        ),
        material: this.createCesiumColor(style.fillColor || "rgba(37, 99, 235, 0.25)"),
        outline: true,
        outlineColor: this.createCesiumColor(style.strokeColor || style.color || "#2563eb"),
        ...(hasAbsoluteHeight
          ? { perPositionHeight: true }
          : {
            // Cesium 只有在声明 height 时才应用 PolygonGraphics.heightReference。
            height: 0,
            heightReference: CesiumLib.HeightReference.CLAMP_TO_GROUND,
          }),
      };
      return entity;
    }

    if (object.type === "circle" && Array.isArray(object.position)) {
      const radius = Number(style.radius || object.properties?.radius || 1000);
      entity.position = CesiumLib.Cartesian3.fromDegrees(object.position[0], object.position[1]);
      entity.ellipse = {
        semiMajorAxis: radius,
        semiMinorAxis: radius,
        material: this.createCesiumColor(style.fillColor || "rgba(37, 99, 235, 0.25)"),
        outline: true,
        outlineColor: this.createCesiumColor(style.strokeColor || style.color || "#2563eb"),
        height: 0,
        heightReference: CesiumLib.HeightReference.CLAMP_TO_GROUND,
      };
      return entity;
    }

    if (Array.isArray(object.position)) {
      entity.position = CesiumLib.Cartesian3.fromDegrees(object.position[0], object.position[1]);
      entity.point = {
        pixelSize: style.pixelSize || 10,
        color: this.createCesiumColor(style.color || "#2563eb"),
        outlineColor: CesiumLib.Color.WHITE,
        outlineWidth: 2,
        heightReference: CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      };
      return entity;
    }

    return null;
  }

  createPolylineGraphics(object, suppliedStyle = null) {
    const style = getCesiumPolylineStyle(suppliedStyle || object.style || {});
    const heightOffset = Number(style.heightOffset);
    const hasHeightOffset = Number.isFinite(heightOffset) && heightOffset !== 0;
    const coordinates = object.geometry?.coordinates || [];
    const hasAbsoluteHeight = coordinates.some(
      (coordinate) => getAbsoluteMarkerHeight(coordinate) !== null,
    );
    const color = this.createCesiumColor(style.strokeColor || style.color || "#2563eb");
    const glowPower = Number(style.glowPower);
    const taperPower = Number(style.taperPower);
    const positions = coordinates.map((coordinate) =>
      CesiumLib.Cartesian3.fromDegrees(
        Number(coordinate[0]),
        Number(coordinate[1]),
        getAbsoluteMarkerHeight(coordinate) ?? (hasHeightOffset ? heightOffset : 0),
      )
    );
    let renderedPositions = positions;
    if (style.dynamicPositions === true) {
      this.dynamicPolylineStates ||= new Map();
      const objectId = String(object.id);
      let dynamicState = this.dynamicPolylineStates.get(objectId);
      if (!dynamicState) {
        dynamicState = { positions };
        dynamicState.callback = new CesiumLib.CallbackProperty(
          () => dynamicState.positions,
          false,
        );
        this.dynamicPolylineStates.set(objectId, dynamicState);
      } else {
        dynamicState.positions = positions;
      }
      renderedPositions = dynamicState.callback;
    }
    return {
      positions: renderedPositions,
      width: style.strokeWidth ?? 3,
      material: Number.isFinite(glowPower)
        ? new CesiumLib.PolylineGlowMaterialProperty({
          color,
          glowPower,
          taperPower: Number.isFinite(taperPower) ? taperPower : 1,
        })
        : style.dashed || Array.isArray(style.lineDash)
          ? new CesiumLib.PolylineDashMaterialProperty({ color })
          : color,
      clampToGround: style.clampToGround ?? !(hasAbsoluteHeight || hasHeightOffset),
      arcType: style.arcType === "none" ? CesiumLib.ArcType.NONE : undefined,
      zIndex: Number.isFinite(Number(style.zIndex)) ? Number(style.zIndex) : undefined,
    };
  }

  createCesiumColor(value) {
    if (value instanceof CesiumLib.Color) return value;
    if (typeof value === "string") return CesiumLib.Color.fromCssColorString(value);
    return CesiumLib.Color.ROYALBLUE;
  }

  addWatermark(text) {
    if (!text) return;

    const target =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!target) return;

    target.style.position = "relative";

    const watermarkEl = document.createElement("div");
    watermarkEl.innerText = text;

    Object.assign(watermarkEl.style, {
      position: "absolute",
      right: "20px",
      bottom: "20px",
      zIndex: "999",
      padding: "6px 12px",
      fontSize: "13px",
      color: "rgba(255, 255, 255, 0.75)",
      background: "rgba(0, 0, 0, 0.35)",
      borderRadius: "4px",
      pointerEvents: "none",
      userSelect: "none",
    });

    target.appendChild(watermarkEl);
    this.watermarkEl = watermarkEl;
  }

  setView(view = {}) {
    if (!this.viewer) return null;
    const center = Array.isArray(view.center) ? view.center : this.options.center || [104.0668, 30.5728];
    const zoom = Number.isFinite(Number(view.zoom)) ? Number(view.zoom) : this.options.zoom ?? 10;
    const height = Number.isFinite(Number(view.cameraHeight)) ? Number(view.cameraHeight) : this.getCameraHeightByZoom(zoom);
    this.viewer.camera.setView({
      destination: CesiumLib.Cartesian3.fromDegrees(center[0], center[1], height),
      orientation: {
        heading: view.heading ?? 0,
        pitch: view.pitch ?? CesiumLib.Math.toRadians(-90),
        roll: view.roll ?? 0,
      },
    });
    this.viewer.scene.requestRender?.();
    return this.getViewState();
  }

  flyTo(view = {}) {
    if (!this.viewer) return null;
    const center = Array.isArray(view.center) ? view.center : this.options.center || [104.0668, 30.5728];
    const zoom = Number.isFinite(Number(view.zoom)) ? Number(view.zoom) : this.options.zoom ?? 10;
    const height = Number.isFinite(Number(view.cameraHeight)) ? Number(view.cameraHeight) : this.getCameraHeightByZoom(zoom);
    const duration = normalizeFlyDuration(view.duration ?? 0.6);
    const camera = this.viewer.camera;

    camera.cancelFlight?.();
    camera.flyTo({
      destination: CesiumLib.Cartesian3.fromDegrees(center[0], center[1], height),
      orientation: {
        heading: view.heading ?? 0,
        pitch: view.pitch ?? CesiumLib.Math.toRadians(-90),
        roll: view.roll ?? 0,
      },
      duration,
    });
    this.viewer.scene.requestRender?.();
    return { center, zoom, cameraHeight: height };
  }

  resize() {
    this.viewer?.resize?.();
    this.viewer?.scene?.requestRender?.();
  }

  destroy() {
    this.hidePopup();

    if (this.clickHandler) {
      this.clickHandler.destroy();
      this.clickHandler = null;
    }

    this.events.clear();

    if (this.viewer?.scene?.canvas) {
      this.viewer.scene.canvas.style.cursor = "";
    }

    this.clearMarkers();
    this.devicePresentationAdapter?.destroy?.();
    this.devicePresentationAdapter = null;
    this.targetFocusController?.destroy?.();
    this.targetFocusController = null;
    this.spatialObjects.forEach((entity) => {
      this.viewer?.entities.remove(entity);
    });
    this.spatialObjects.clear();

    if (this.layerManager) {
      this.layerManager.destroy();
      this.layerManager = null;
    }

    if (this.watermarkEl) {
      this.watermarkEl.remove();
      this.watermarkEl = null;
    }

    if (this.viewer && !this.viewer.isDestroyed()) {
      this.viewer.destroy();
      this.viewer = null;
    this.CesiumLib = CesiumLib;
    }
  }
}

function getEntityProperty(entity, key) {
  const value = entity?.properties?.[key];
  return value?.getValue?.() || value || null;
}

function markerToSpatialObject(marker) {
  if (!marker?.id) return null;
  return {
    id: marker.id,
    type: "marker",
    position: marker.position,
    properties: marker.data || {},
    style: { icon: marker.icon, color: marker.color, label: marker.label },
  };
}

function getCesiumPolylineStyle(style = {}) {
  return {
    strokeColor: style.strokeColor3d ?? style.strokeColor,
    color: style.color,
    strokeWidth: style.strokeWidth3d ?? style.strokeWidth,
    heightOffset: style.heightOffset,
    glowPower: style.glowPower,
    taperPower: style.taperPower,
    dashed: style.dashed,
    lineDash: style.lineDash,
    clampToGround: style.clampToGround,
    arcType: style.arcType,
    zIndex: style.zIndex,
    dynamicPositions: style.dynamicPositions,
  };
}

function destinationPointAtBearing(position, bearingDegrees, distanceMeters) {
  const longitude = Number(position?.[0]);
  const latitude = Number(position?.[1]);
  const bearing = Number(bearingDegrees);
  const distance = Number(distanceMeters);
  if (![longitude, latitude, bearing, distance].every(Number.isFinite)) return null;

  const earthRadius = 6_378_137;
  const angularDistance = distance / earthRadius;
  const bearingRadians = CesiumLib.Math.toRadians(bearing);
  const latitudeRadians = CesiumLib.Math.toRadians(latitude);
  const longitudeRadians = CesiumLib.Math.toRadians(longitude);
  const destinationLatitude = Math.asin(
    Math.sin(latitudeRadians) * Math.cos(angularDistance)
      + Math.cos(latitudeRadians) * Math.sin(angularDistance) * Math.cos(bearingRadians),
  );
  const destinationLongitude = longitudeRadians + Math.atan2(
    Math.sin(bearingRadians) * Math.sin(angularDistance) * Math.cos(latitudeRadians),
    Math.cos(angularDistance) - Math.sin(latitudeRadians) * Math.sin(destinationLatitude),
  );
  return [
    CesiumLib.Math.toDegrees(destinationLongitude),
    CesiumLib.Math.toDegrees(destinationLatitude),
  ];
}

function getAbsoluteMarkerHeight(position) {
  if (!Array.isArray(position) || position.length < 3) return null;
  const height = Number(position[2]);
  return Number.isFinite(height) && height !== 0 ? height : null;
}

function isFiniteCartesian3(cartesian) {
  if (!cartesian) return false;
  const { x, y, z } = cartesian;
  return Number.isFinite(x)
    && Number.isFinite(y)
    && Number.isFinite(z)
    && (x !== 0 || y !== 0 || z !== 0);
}

function getObjectCoordinates(object = {}) {
  if (Array.isArray(object.position)) return [object.position];
  const coordinates = object.geometry?.coordinates;
  if (!Array.isArray(coordinates)) return [];
  return flattenCoordinates(coordinates).filter((coordinate) => Array.isArray(coordinate) && coordinate.length >= 2);
}

function flattenCoordinates(coordinates) {
  if (!Array.isArray(coordinates)) return [];
  if (typeof coordinates[0] === "number") return [coordinates];
  return coordinates.flatMap(flattenCoordinates);
}

function readNumber(...values) {
  for (const value of values) {
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return 0;
}

function normalizeHeading(heading) {
  const twoPi = Math.PI * 2;
  return ((heading % twoPi) + twoPi) % twoPi;
}

function normalizePitch(pitch) {
  const minPitch = CesiumLib.Math.toRadians(-90);
  const maxPitch = CesiumLib.Math.toRadians(-15);
  return Math.max(minPitch, Math.min(maxPitch, pitch));
}

function degreesToRadians(degrees) {
  const number = Number(degrees);
  if (!Number.isFinite(number)) return undefined;
  return CesiumLib.Math.toRadians(number);
}

function angleToRadians(angle) {
  const number = Number(angle);
  if (!Number.isFinite(number)) return undefined;
  return Math.abs(number) > Math.PI ? CesiumLib.Math.toRadians(number) : number;
}

function normalizeFlyDuration(duration) {
  const number = Number(duration);
  if (!Number.isFinite(number) || number <= 0) return 0;
  return number > 10 ? number / 1000 : number;
}

function tiltToPitch(tilt) {
  const number = Number(tilt);
  if (!Number.isFinite(number)) return undefined;
  return CesiumLib.Math.toRadians(Math.max(0, Math.min(75, number)) - 90);
}




