const DEFAULTS = {
  detailDistance: 8000,
  compactDistance: 35000,
  hiddenDistance: 55000,
};

export function resolveDeviceLabel(context = {}, config = {}) {
  const thresholds = { ...DEFAULTS, ...(config || {}) };
  const object = context.object || {};
  const properties = object.properties || {};
  const distance = Number(context.cameraDistance);
  const name = properties.name || object.style?.label?.text || object.id || "--";
  const altitude = Number.isFinite(Number(object.position?.[2])) ? Number(object.position[2]) : Number(properties.altitude);
  const altitudeText = Number.isFinite(altitude) ? `${Math.round(altitude)}m` : "--";
  const selected = properties.selected === true;

  if (!selected && Number.isFinite(distance) && distance > thresholds.hiddenDistance) return { show: false, text: "", level: "hidden" };
  if (selected || !Number.isFinite(distance) || distance <= thresholds.detailDistance) {
    const speed = Number.isFinite(Number(properties.speed)) ? `${Math.round(Number(properties.speed))}m/s` : "--";
    const heading = Number.isFinite(Number(properties.heading)) ? `${Math.round(normalizeDegrees(properties.heading))}°` : "--";
    const status = properties.status || properties.onlineStatus || "--";
    return { show: true, text: selected ? `${name} · ${altitudeText}\n${speed} · ${heading} · ${status}` : `${name} · ${altitudeText}`, level: selected ? "selected" : "detail" };
  }
  if (distance <= thresholds.compactDistance) return { show: true, text: `${name} · ${altitudeText}`, level: "compact" };
  return { show: true, text: name, level: "name" };
}

function normalizeDegrees(value) {
  return ((Number(value) % 360) + 360) % 360;
}
