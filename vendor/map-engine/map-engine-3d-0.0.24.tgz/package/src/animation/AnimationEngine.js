import { clone, isLngLat } from "../state/utils";

export default class AnimationEngine {
  constructor(mapEngine) {
    this.mapEngine = mapEngine;
    this.tasks = new Map();
    this.rafId = null;
    this.running = false;
  }

  moveTo(id, options = {}) {
    const object = this.getObject(id);
    if (!object || !isLngLat(object.position) || !isLngLat(options.position)) return null;
    return this.addTask({
      id: `move:${id}`,
      type: "move",
      objectId: String(id),
      startPosition: object.position,
      endPosition: [Number(options.position[0]), Number(options.position[1])],
      duration: normalizeDuration(options.duration),
      startedAt: getNow(),
      easing: options.easing || "linear",
    });
  }

  blink(id, options = {}) {
    const object = this.getObject(id);
    if (!object) return null;
    return this.addTask({
      id: `blink:${id}`,
      type: "blink",
      objectId: String(id),
      originalStyle: object.style || {},
      duration: normalizeDuration(options.duration, 1200),
      interval: Number(options.interval) > 0 ? Number(options.interval) : 300,
      startedAt: getNow(),
      color: options.color,
    });
  }

  pulseCoverage(id, options = {}) {
    const object = this.getObject(id);
    if (!object) return null;
    return this.addTask({
      id: `pulse:${id}`,
      type: "pulseCoverage",
      objectId: String(id),
      fromRadius: Number(options.fromRadius ?? object.style?.radius ?? object.properties?.radius ?? 500),
      toRadius: Number(options.toRadius ?? object.style?.radius ?? object.properties?.radius ?? 1500),
      duration: normalizeDuration(options.duration, 1600),
      startedAt: getNow(),
    });
  }

  stopAnimation(id) {
    const key = String(id);
    const removed = this.tasks.delete(key);
    if (!removed) {
      Array.from(this.tasks.keys())
        .filter((taskId) => taskId.endsWith(`:${key}`))
        .forEach((taskId) => this.tasks.delete(taskId));
    }
    this.mapEngine.emit("animation:stop", { id: key });
    return true;
  }

  clearAnimations() {
    this.tasks.clear();
    this.running = false;
    cancelFrame(this.rafId);
    this.rafId = null;
    this.mapEngine.emit("animation:clear", {});
    return true;
  }

  destroy() {
    this.clearAnimations();
  }

  addTask(task) {
    this.tasks.set(task.id, task);
    this.mapEngine.emit("animation:start", clone(task));
    this.startLoop();
    return clone(task);
  }

  startLoop() {
    if (this.running) return;
    this.running = true;
    this.rafId = requestFrame(() => this.tick());
  }

  tick() {
    if (!this.running) return;
    const now = getNow();
    const updates = [];
    const completed = [];

    this.tasks.forEach((task, id) => {
      const elapsed = now - task.startedAt;
      const progress = Math.max(0, Math.min(1, elapsed / task.duration));
      const eased = ease(progress, task.easing);
      const update = this.createUpdate(task, eased, elapsed);
      if (update) updates.push(update);
      if (progress >= 1) {
        completed.push(id);
      }
    });

    if (updates.length) this.mapEngine.applyPatch({ update: updates });
    completed.forEach((id) => {
      const task = this.tasks.get(id);
      this.tasks.delete(id);
      this.mapEngine.emit("animation:complete", clone(task));
    });

    if (this.tasks.size) {
      this.rafId = requestFrame(() => this.tick());
    } else {
      this.running = false;
      this.rafId = null;
    }
  }

  createUpdate(task, progress, elapsed) {
    if (task.type === "move") {
      return {
        id: task.objectId,
        position: [
          task.startPosition[0] + (task.endPosition[0] - task.startPosition[0]) * progress,
          task.startPosition[1] + (task.endPosition[1] - task.startPosition[1]) * progress,
        ],
      };
    }

    if (task.type === "blink") {
      const visible = Math.floor(elapsed / task.interval) % 2 === 0;
      return {
        id: task.objectId,
        style: {
          ...task.originalStyle,
          opacity: visible ? (task.originalStyle.opacity ?? 1) : 0.2,
          color: task.color || task.originalStyle.color,
        },
      };
    }

    if (task.type === "pulseCoverage") {
      const wave = Math.sin(progress * Math.PI);
      const radius = task.fromRadius + (task.toRadius - task.fromRadius) * wave;
      return {
        id: task.objectId,
        style: {
          radius,
          opacity: 0.35 + 0.35 * (1 - wave),
        },
        properties: { radius },
      };
    }

    return null;
  }

  getObject(id) {
    return this.mapEngine.store?.getObject?.(id) || this.mapEngine.getState?.().objects?.find((object) => object.id === String(id)) || null;
  }
}

function normalizeDuration(duration, fallback = 800) {
  const next = Number(duration);
  return Number.isFinite(next) && next > 0 ? next : fallback;
}

function ease(progress, easing) {
  if (easing === "easeInOut") return progress < 0.5 ? 2 * progress * progress : 1 - ((-2 * progress + 2) ** 2) / 2;
  return progress;
}

function getNow() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}

function requestFrame(callback) {
  if (typeof requestAnimationFrame === "function") return requestAnimationFrame(callback);
  return setTimeout(callback, 16);
}

function cancelFrame(id) {
  if (!id) return;
  if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(id);
  else clearTimeout(id);
}
