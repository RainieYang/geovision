import OpenLayersMap from "../engine2d/OpenLayersMap";
import CesiumMap from "../engine3d/CesiumMap";
import AnimationEngine from "../animation/AnimationEngine";
import ReplayEngine from "../replay/ReplayEngine";
import MapControls from "../control/MapControls";
import DrawManager from "../draw/DrawManager";
import { createFeatureCollection } from "../draw/geojson";
import EventBus from "../state/EventBus";
import StateStore from "../state/StateStore";
import { clone, normalizeLayer, normalizeState, normalizeView } from "../state/utils";
import { sampleTemporalObjects } from "../temporal/TemporalState";
import TrackLayerRuntime from "../track-layer/TrackLayerRuntime";

export default class MapEngine {
  constructor(options = {}) {
    this.options = options;
    this.type = options.type === "3d" ? "3d" : "2d";
    this.engine = null;
    this.controls = null;
    this.drawManager = null;
    this.drawStore = createFeatureCollection();
    this.selectedDrawingId = null;
    this.events = new EventBus();
    this.store = new StateStore({
      version: 1,
      objects: options.objects || [],
      layers: options.layers || [],
      temporal: options.temporal || [],
      tracks: options.tracks || [],
      groups: options.groups || [],
      view: normalizeView({
        center: options.center,
        zoom: options.zoom,
        pitch: options.pitch,
        heading: options.heading,
        cameraHeight: options.cameraHeight,
        ...(options.view || {}),
      }),
    });
    this.replayEngine = new ReplayEngine(this);
    this.trackLayer = new TrackLayerRuntime(this);
    this.animationEngine = new AnimationEngine(this);
  }

  init() {
    if (this.engine) return this;
    this.engine = this.createEngine(this.type);
    this.engine.init();
    this.bindEngineEvents();
    this.initDrawManager();
    this.renderDiff({
      objects: { added: this.store.listObjects(), updated: [], removed: [] },
      layers: { added: this.getState().layers, updated: [], removed: [] },
      viewChanged: true,
    });
    this.initControls();
    return this;
  }

  initControls() {
    if (this.options.controls === false) return;
    const controlOptions = this.options.controls || {};
    const replayTimelineEnabled = controlOptions.replayTimeline === true
      || controlOptions.replayTimeline?.enabled === true;
    if (controlOptions.mapToolbar === false && !replayTimelineEnabled) return;

    this.controls?.unmount();
    this.controls = new MapControls(this, controlOptions);
    this.controls.mount();
  }

  initDrawManager() {
    this.drawManager?.destroy?.();
    this.drawManager = new DrawManager(this, this.engine, this.options.draw || {});
    this.drawManager.importGeoJSON(this.drawStore);
  }

  createEngine(type) {
    const state = this.store.getState();
    const engineOptions = this.createEngineOptions(type, state.view);
    return type === "3d" ? new CesiumMap(engineOptions) : new OpenLayersMap(engineOptions);
  }

  createEngineOptions(type, view) {
    const prefix = type === "3d" ? "3d" : "2d";
    return {
      ...this.options,
      mapEngine: this,
      type,
      center: view.center,
      zoom: view.zoom,
      pitch: view.pitch,
      heading: view.heading,
      cameraHeight: view.cameraHeight,
      baseMapProvider: this.options[`baseMapProvider${prefix}`] || this.options.baseMapProvider || (type === "3d" ? "tianditu" : "tianditu"),
      baseMapType: this.options[`baseMapType${prefix}`] || this.options.baseMapType || (type === "3d" ? "img" : "vec"),
      baseMapUrl: this.options[`baseMapUrl${prefix}`] || this.options.baseMapUrl,
      minimumLevel: this.options[`minimumLevel${prefix}`] ?? this.options.minimumLevel,
      maximumLevel: this.options[`maximumLevel${prefix}`] ?? this.options.maximumLevel,
      bounds: this.options[`bounds${prefix}`] || this.options.bounds,
      terrainProvider: this.options.terrainProvider3d || this.options.terrainProvider,
      terrainUrl: this.options.terrainUrl3d || this.options.terrainUrl,
      overlayLayers: this.options[`overlayLayers${prefix}`] || this.options.overlayLayers || [],
    };
  }

  bindEngineEvents() {
    this.engine?.on?.("object:click", (payload) => {
      if (isDevicePresentation(payload?.object)) this.selectDevicePresentation(payload.object.id);
      this.emit("object:click", payload);
    });
    this.engine?.on?.("object:hover", (payload) => this.emit("object:hover", payload));
    this.engine?.on?.("click", (payload) => {
      if (payload?.type === "marker" && payload.id) {
        const object = this.store.getObject(payload.id);
        if (object) {
          this.emit("object:click", {
            id: payload.id,
            object,
            target: payload.target,
            position: payload.lnglat,
            screenPosition: payload.screenPosition,
            originalEvent: payload.originalEvent,
          });
          if (isDevicePresentation(object)) this.selectDevicePresentation(object.id);
        }
      }
      if (payload?.type === "map") this.clearDevicePresentationSelection();
    });
  }

  setBaseMapLanguage(language) {
    const baseMapLanguage = String(language || "zh").toLowerCase() === "en" ? "en" : "zh";
    this.options.baseMapLanguage = baseMapLanguage;
    return this.engine?.setBaseMapLanguage?.(baseMapLanguage) || Promise.resolve({ applied: false, baseMapLanguage });
  }

  setState(state = {}) {
    const next = normalizeState(state);
    const diff = this.store.setState(next);
    this.renderDiff(diff);
    this.emit("state:changed", { state: this.getState(), diff });
    return this;
  }

  getState() {
    const state = this.store.getState();
    const currentView = this.getView();
    if (currentView?.center) state.view = normalizeView(currentView);
    return state;
  }

  applyPatch(patch = {}) {
    const diff = this.store.applyPatch(patch);
    this.renderDiff(diff);
    const state = this.getState();
    this.emit("state:changed", { state, diff, patch: clone(patch) });
    if (diff.viewChanged) this.emit("view:change", state.view);
    if (diff.layers.added.length || diff.layers.updated.length || diff.layers.removed.length) {
      this.emit("layer:change", { layers: state.layers, diff: diff.layers });
    }
    return state;
  }

  renderDiff(diff) {
    if (!this.engine) return;

    diff.layers.removed.forEach((id) => this.engine.removeLayer?.(id));
    diff.layers.added.forEach((layer) => this.renderLayer(layer));
    diff.layers.updated.forEach((layer) => this.updateLayer(layer));

    diff.objects.removed.forEach((id) => this.engine.removeObject?.(id));
    diff.objects.added.forEach((object) => this.engine.renderObject?.(object));
    diff.objects.updated.forEach((object) => this.engine.updateObject?.(object));

    if (diff.viewChanged) {
      this.engine.setView?.(this.store.getState().view);
    }
  }

  renderLayer(layer) {
    if (!layer) return null;
    return this.engine?.addLayer?.(layer);
  }

  updateLayer(layer) {
    if (!layer?.id) return null;
    if (!this.engine?.hasLayer?.(layer.id)) return this.renderLayer(layer);
    if (typeof layer.visible === "boolean") this.engine.setLayerVisible?.(layer.id, layer.visible);
    if (typeof layer.opacity === "number") this.engine.setLayerOpacity?.(layer.id, layer.opacity);
    if (typeof layer.zIndex === "number") this.engine.setLayerZIndex?.(layer.id, layer.zIndex);
    return this.engine.getLayer?.(layer.id);
  }

  setView(view = {}) {
    return this.applyPatch({ view });
  }

  getView() {
    return this.engine?.getViewState?.() || this.store.getState().view;
  }

  flyTo(view = {}) {
    const nextView = normalizeView({ ...this.store.getState().view, ...view });
    this.store.view = nextView;
    const result = this.engine?.flyTo?.(view) || this.engine?.setView?.(nextView);
    this.emit("view:change", nextView);
    this.emit("state:changed", { state: this.getState(), diff: { viewChanged: true } });
    return result;
  }

  zoomIn() {
    const result = this.engine?.zoomIn?.();
    this.syncViewFromRenderer();
    return result;
  }

  zoomOut() {
    const result = this.engine?.zoomOut?.();
    this.syncViewFromRenderer();
    return result;
  }

  reset() {
    this.store.setState({
      version: 1,
      objects: [],
      layers: [],
      view: normalizeView(this.options.view || { center: this.options.center, zoom: this.options.zoom }),
    });
    this.engine?.clearObjects?.();
    this.engine?.clearLayers?.();
    this.engine?.setView?.(this.store.getState().view);
    this.trackLayer.clearTracks();
    this.animationEngine.clearAnimations();
    this.emit("state:changed", { state: this.getState() });
    return this;
  }

  resetView() {
    const result = this.engine?.resetView?.();
    this.syncViewFromRenderer();
    return result;
  }

  getStatus() {
    return this.engine?.getStatus?.() || {};
  }

  getCameraOrientation() {
    return this.engine?.getCameraOrientation?.() || null;
  }

  setCameraOrientation(options) {
    return this.engine?.setCameraOrientation?.(options) || null;
  }

  resetCameraOrientation() {
    return this.engine?.resetCameraOrientation?.() || null;
  }

  resize() {
    return this.engine?.resize?.();
  }

  destroy() {
    this.controls?.unmount();
    this.controls = null;
    this.drawManager?.destroy?.();
    this.drawManager = null;
    this.replayEngine.destroy();
    this.animationEngine.destroy();
    this.engine?.destroy?.();
    this.engine = null;
    this.events.clear();
  }

  switchView(type) {
    const nextType = type || (this.type === "3d" ? "2d" : "3d");
    if (nextType === this.type) return this;

    const state = this.getState();
    this.controls?.unmount();
    this.drawManager?.destroy?.();
    this.drawManager = null;
    this.engine?.destroy?.();
    this.controls = null;
    this.type = nextType === "3d" ? "3d" : "2d";
    // 切换渲染器时同步修正快照中的视图类型。若继续使用旧 type，新引擎
    // 会先广播一次旧模式，再由调用方写回新模式，造成 React 重复切换并
    // 让设备 marker 短暂按默认姿态重建。
    state.view = { ...(state.view || {}), type: this.type };
    this.engine = this.createEngine(this.type);
    this.engine.init();
    this.bindEngineEvents();
    this.initDrawManager();
    this.store.setState(state);
    this.renderDiff({
      objects: { added: this.store.listObjects(), updated: [], removed: [] },
      layers: { added: this.store.getState().layers, updated: [], removed: [] },
      viewChanged: true,
    });
    this.initControls();
    this.emit("view:change", this.store.getState().view);
    this.emit("state:changed", { state: this.getState() });
    return this;
  }

  exportSnapshot() {
    return {
      type: "MapEngineSnapshot",
      engineType: this.type,
      exportedAt: new Date().toISOString(),
      state: this.getState(),
    };
  }

  importSnapshot(snapshot = {}) {
    const state = snapshot.state || snapshot;
    if (snapshot.engineType && snapshot.engineType !== this.type) {
      this.type = snapshot.engineType === "3d" ? "3d" : "2d";
      if (this.engine) {
        this.engine.destroy?.();
        this.engine = null;
        this.init();
      }
    }
    return this.setState(state);
  }

  addLayer(layer = {}) {
    const next = normalizeLayer(layer);
    if (!next) return null;
    this.applyPatch({ addLayers: [next] });
    return this.engine?.getLayer?.(next.id) || next;
  }

  removeLayer(id) {
    this.applyPatch({ removeLayers: [id] });
    return true;
  }

  setLayerVisibility(id, visible) {
    return this.setLayerVisible(id, visible);
  }

  setLayerVisible(id, visible) {
    this.applyPatch({ updateLayers: [{ id, visible }] });
    return true;
  }

  setLayerOpacity(id, opacity) {
    this.applyPatch({ updateLayers: [{ id, opacity }] });
    return true;
  }

  listLayers() {
    return this.getState().layers;
  }

  enterReplay(options) {
    return this.replayEngine.enterReplay(options);
  }

  exitReplay(options) {
    return this.replayEngine.exitReplay(options);
  }

  loadReplay(data) {
    return this.replayEngine.loadReplay(data);
  }

  seek(time) {
    return this.replayEngine.seek(time);
  }

  play(options) {
    return this.replayEngine.play(options);
  }

  pause() {
    return this.replayEngine.pause();
  }

  stop() {
    return this.replayEngine.stop();
  }

  setSpeed(speed) {
    return this.replayEngine.setSpeed(speed);
  }

  setLoop(loop) {
    return this.replayEngine.setLoop(loop);
  }

  getReplayState() {
    return this.replayEngine.getState();
  }

  setTemporalState(temporal = []) {
    const currentIds = this.getState().temporal.map((object) => object.id);
    return this.applyPatch({
      removeTemporal: currentIds,
      addTemporal: temporal,
    });
  }

  applyTemporalAt(time) {
    const sampled = sampleTemporalObjects(this.getState().temporal, time);
    if (!sampled.length) return [];
    const existingIds = new Set(this.getState().objects.map((object) => object.id));
    this.applyPatch({
      add: sampled.filter((object) => !existingIds.has(object.id)),
      update: sampled.filter((object) => existingIds.has(object.id)),
    });
    this.emit("temporal:sample", { time, objects: sampled });
    return sampled;
  }

  addTrack(track) {
    return this.trackLayer.addTrack(track);
  }

  updateTrack(id, patch) {
    if (typeof id === "object") return this.trackLayer.updateTrack(id.id, id);
    return this.trackLayer.updateTrack(id, patch);
  }

  appendTrackPoint(id, point, options) {
    return this.trackLayer.appendTrackPoint(id, point, options);
  }

  removeTrack(id) {
    return this.trackLayer.removeTrack(id);
  }

  clearTracks() {
    return this.trackLayer.clearTracks();
  }

  drawPoint(options) {
    return this.drawManager?.drawPoint(options);
  }

  drawLine(options) {
    return this.drawManager?.drawLine(options);
  }

  drawPolygon(options) {
    return this.drawManager?.drawPolygon(options);
  }

  drawRectangle(options) {
    return this.drawManager?.drawRectangle(options);
  }

  drawCircle(options) {
    return this.drawManager?.drawCircle(options);
  }

  enableDrawSelect() {
    return this.drawManager?.enableSelect();
  }

  enableDrawEdit() {
    return this.drawManager?.enableGeometryEdit();
  }

  unselectDrawing() {
    return this.drawManager?.unselectDrawing();
  }

  getSelectedDrawing() {
    return this.drawManager?.getSelectedDrawing() || null;
  }

  removeDrawing(id) {
    return this.drawManager?.removeDrawing(id);
  }

  removeSelectedDrawing() {
    return this.drawManager?.removeSelectedDrawing();
  }

  updateDrawingProperties(id, properties) {
    return this.drawManager?.updateDrawingProperties(id, properties);
  }

  updateSelectedDrawingProperties(properties) {
    return this.drawManager?.updateSelectedDrawingProperties(properties);
  }

  listDrawings() {
    return this.drawManager?.listDrawings() || [];
  }

  createFenceFromDrawing(id, options) {
    return this.drawManager?.createFenceFromDrawing(id, options);
  }

  createFenceFromSelectedDrawing(options) {
    return this.drawManager?.createFenceFromSelectedDrawing(options);
  }

  listFences() {
    return this.drawManager?.listFences() || [];
  }

  clearDrawings() {
    this.drawManager?.clear();
    this.drawStore = createFeatureCollection();
    this.selectedDrawingId = null;
  }

  exportGeoJSON() {
    this.drawStore = this.drawManager?.exportGeoJSON() || this.drawStore;
    return this.drawStore;
  }

  importGeoJSON(geojson) {
    this.drawStore = geojson || createFeatureCollection();
    return this.drawManager?.importGeoJSON(this.drawStore);
  }

  getDrawManager() {
    return this.drawManager;
  }

  getTrack(id) {
    return this.trackLayer.getTrack(id);
  }

  listTracks() {
    return this.trackLayer.listTracks();
  }

  moveObject(id, options) {
    return this.animationEngine.moveTo(id, options);
  }

  blinkObject(id, options) {
    return this.animationEngine.blink(id, options);
  }

  pulseCoverage(id, options) {
    return this.animationEngine.pulseCoverage(id, options);
  }

  stopAnimation(id) {
    return this.animationEngine.stopAnimation(id);
  }

  clearAnimations() {
    return this.animationEngine.clearAnimations();
  }

  addHeatmapLayer(id, points = [], options = {}) {
    const objectId = String(id);
    const object = {
      id: objectId,
      type: "custom",
      geometry: { type: "MultiPoint", coordinates: points.map((point) => point.position || point.coordinates || point) },
      style: {
        renderer: "heatmap",
        radius: options.radius ?? 24,
        opacity: options.opacity ?? 0.65,
        gradient: options.gradient,
      },
      properties: {
        ...(options.properties || {}),
        runtimeType: "heatmap",
        points: clone(points),
      },
    };
    this.applyPatch({ add: [object] });
    return object;
  }

  addCoverage(id, coverage = {}) {
    const object = createCoverageObject(id, coverage);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateCoverage(id, coverage = {}) {
    const object = createCoverageObject(id, coverage);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeCoverage(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addSector(id, sector = {}) {
    const object = createSectorObject(id, sector);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateSector(id, sector = {}) {
    const object = createSectorObject(id, sector);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeSector(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addDirectionLine(id, line = {}) {
    const object = createDirectionLineObject(id, line);
    this.applyPatch({ add: [object] });
    return object;
  }

  updateDirectionLine(id, line = {}) {
    const object = createDirectionLineObject(id, line);
    this.applyPatch({ update: [object] });
    return object;
  }

  removeDirectionLine(id) {
    this.applyPatch({ remove: [id] });
    return true;
  }

  addLayerGroup(group = {}) {
    this.applyPatch({ addGroups: [group] });
    return this.store.getLayerGroup(group.id);
  }

  updateLayerGroup(id, patch = {}) {
    const group = typeof id === "object" ? id : { ...patch, id };
    this.applyPatch({ updateGroups: [group] });
    return this.store.getLayerGroup(group.id);
  }

  removeLayerGroup(id) {
    this.applyPatch({ removeGroups: [id] });
    return true;
  }

  setLayerGroupVisible(id, visible) {
    const group = this.store.getLayerGroup(id);
    if (!group) return false;
    this.applyPatch({
      updateGroups: [{ id, visible }],
      updateLayers: group.layerIds.map((layerId) => ({ id: layerId, visible })),
      update: group.objectIds.map((objectId) => ({ id: objectId, properties: { hiddenByGroup: !visible }, style: { visible } })),
    });
    return true;
  }

  listLayerGroups() {
    return this.store.listLayerGroups();
  }

  queryFeatureAtPixel(pixel, options = {}) {
    return this.engine?.queryFeatureAtPixel?.(pixel, options) || null;
  }

  queryObjectsByBounds(bounds, options = {}) {
    return this.engine?.queryObjectsByBounds?.(bounds, options) || queryObjectsByBounds(this.getState().objects, bounds);
  }

  queryObjectsByPoint(point, options = {}) {
    return this.engine?.queryObjectsByPoint?.(point, options) || queryObjectsByPoint(this.getState().objects, point, options);
  }

  selectDevicePresentation(id) {
    const target = this.store.getObject(String(id));
    if (!isDevicePresentation(target)) return null;
    const updates = this.store.listObjects()
      .filter(isDevicePresentation)
      .filter((object) => Boolean(object.properties?.selected) !== (object.id === target.id))
      .map((object) => ({ id: object.id, properties: { ...(object.properties || {}), selected: object.id === target.id } }));
    if (updates.length) this.applyPatch({ update: updates });
    this.engine?.devicePresentationAdapter?.setSelectedDevice?.(target.id);
    return target;
  }

  clearDevicePresentationSelection() {
    const updates = this.store.listObjects()
      .filter((object) => isDevicePresentation(object) && object.properties?.selected === true)
      .map((object) => ({ id: object.id, properties: { ...(object.properties || {}), selected: false } }));
    if (updates.length) this.applyPatch({ update: updates });
    this.engine?.devicePresentationAdapter?.setSelectedDevice?.(null);
    return Boolean(updates.length);
  }

  getSelectedDevicePresentationId() {
    return this.store.listObjects().find((object) => isDevicePresentation(object) && object.properties?.selected === true)?.id || null;
  }

  setDevicePresentationFollowed(id, followed = true) {
    const object = this.store.getObject(String(id));
    if (!isDevicePresentation(object)) return false;
    this.applyPatch({ update: [{ id: object.id, properties: { ...(object.properties || {}), followed: Boolean(followed) } }] });
    return true;
  }

  setSituationMode3d(mode) {
    return this.engine?.setSituationMode3d?.(mode) || null;
  }

  setOcclusion3d(options) {
    return this.engine?.setOcclusion3d?.(options) || null;
  }

  getOcclusion3d() {
    return this.engine?.getOcclusion3d?.() || null;
  }

  focusOnTarget(id, options = {}) {
    return this.engine?.focusOnTarget?.(id, options) || null;
  }

  getType() {
    return this.type;
  }

  on(eventName, callback) {
    return this.events.on(eventName, callback);
  }

  off(eventName, callback) {
    return this.events.off(eventName, callback);
  }

  emit(eventName, payload) {
    return this.events.emit(eventName, payload);
  }

  emitLocal(eventName, payload) {
    return this.emit(eventName, payload);
  }

  syncViewFromRenderer() {
    const view = this.getView();
    if (!view?.center) return;
    this.store.view = normalizeView(view);
    this.emit("view:change", this.store.view);
    this.emit("state:changed", { state: this.getState(), diff: { viewChanged: true } });
  }
}

function isDevicePresentation(object) {
  return object?.type === "marker" && Boolean(object.properties?.presentation3d || object.properties?.role === "uav");
}

function createCoverageObject(id, coverage = {}) {
  return {
    id: String(id),
    type: coverage.geometry ? "polygon" : "circle",
    position: coverage.position || coverage.center,
    geometry: coverage.geometry,
    style: {
      radius: coverage.radius,
      fillColor: coverage.fillColor || coverage.color || "#22d3ee",
      strokeColor: coverage.strokeColor || coverage.color || "#0891b2",
      opacity: coverage.opacity ?? 0.25,
      ...(coverage.style || {}),
    },
    properties: {
      ...(coverage.properties || {}),
      runtimeType: "coverage",
      radius: coverage.radius,
    },
  };
}

function createSectorObject(id, sector = {}) {
  const center = sector.center || sector.position;
  const coordinates = createSectorCoordinates(center, sector.radius, sector.startAngle, sector.endAngle, sector.steps);
  return {
    id: String(id),
    type: "polygon",
    geometry: { type: "Polygon", coordinates },
    style: {
      fillColor: sector.fillColor || sector.color || "#38bdf8",
      strokeColor: sector.strokeColor || sector.color || "#0284c7",
      opacity: sector.opacity ?? 0.28,
      ...(sector.style || {}),
    },
    properties: {
      ...(sector.properties || {}),
      runtimeType: "sector",
      center,
      radius: sector.radius,
      startAngle: sector.startAngle,
      endAngle: sector.endAngle,
    },
  };
}

function createDirectionLineObject(id, line = {}) {
  const start = line.start || line.from || line.position;
  const end = line.end || line.to || destinationPoint(start, line.bearing, line.length || line.distance || 1000);
  return {
    id: String(id),
    type: "line",
    geometry: { type: "LineString", coordinates: [start, end].filter(Boolean) },
    style: {
      strokeColor: line.strokeColor || line.color || "#f59e0b",
      strokeWidth: line.strokeWidth ?? 2,
      ...(line.style || {}),
    },
    properties: {
      ...(line.properties || {}),
      runtimeType: "direction-line",
      bearing: line.bearing,
    },
  };
}

function createSectorCoordinates(center, radius = 1000, startAngle = 0, endAngle = 90, steps = 32) {
  if (!Array.isArray(center)) return [];
  const total = Math.max(2, Number(steps) || 32);
  const coordinates = [center];
  for (let index = 0; index <= total; index += 1) {
    const angle = Number(startAngle) + ((Number(endAngle) - Number(startAngle)) * index) / total;
    coordinates.push(destinationPoint(center, angle, radius));
  }
  coordinates.push(center);
  return coordinates;
}

function destinationPoint(center, bearing = 0, distance = 1000) {
  if (!Array.isArray(center)) return null;
  const radius = 6378137;
  const angularDistance = Number(distance) / radius;
  const bearingRad = (Number(bearing) * Math.PI) / 180;
  const lat1 = (Number(center[1]) * Math.PI) / 180;
  const lon1 = (Number(center[0]) * Math.PI) / 180;
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angularDistance) +
      Math.cos(lat1) * Math.sin(angularDistance) * Math.cos(bearingRad)
  );
  const lon2 =
    lon1 +
    Math.atan2(
      Math.sin(bearingRad) * Math.sin(angularDistance) * Math.cos(lat1),
      Math.cos(angularDistance) - Math.sin(lat1) * Math.sin(lat2)
    );
  return [(lon2 * 180) / Math.PI, (lat2 * 180) / Math.PI];
}

function queryObjectsByBounds(objects = [], bounds = []) {
  if (!Array.isArray(bounds) || bounds.length < 4) return [];
  const [minLng, minLat, maxLng, maxLat] = bounds.map(Number);
  return objects.filter((object) =>
    getObjectCoordinates(object).some(([lng, lat]) => lng >= minLng && lng <= maxLng && lat >= minLat && lat <= maxLat)
  );
}

function queryObjectsByPoint(objects = [], point = [], options = {}) {
  if (!Array.isArray(point)) return [];
  const tolerance = Number(options.tolerance ?? 0.0005);
  const [lng, lat] = point.map(Number);
  return objects.filter((object) =>
    getObjectCoordinates(object).some(
      ([objectLng, objectLat]) => Math.abs(objectLng - lng) <= tolerance && Math.abs(objectLat - lat) <= tolerance
    )
  );
}

function getObjectCoordinates(object = {}) {
  if (Array.isArray(object.position)) return [object.position];
  const coordinates = object.geometry?.coordinates;
  if (!Array.isArray(coordinates)) return [];
  return flattenCoordinates(coordinates).filter((coordinate) => Array.isArray(coordinate) && coordinate.length >= 2);
}

function flattenCoordinates(coordinates) {
  if (!Array.isArray(coordinates)) return [];
  if (typeof coordinates[0] === "number") return [coordinates];
  return coordinates.flatMap(flattenCoordinates);
}
