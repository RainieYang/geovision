﻿import OpenLayersDrawAdapter from "./OpenLayersDrawAdapter";
import CesiumDrawAdapter from "./CesiumDrawAdapter";
import { createFeatureCollection, normalizeFeatureCollection } from "./geojson";

export default class DrawManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = options;
    this.selectedFeatureId = options.selectedFeatureId || mapEngine.selectedDrawingId || null;
    this.adapter = this.createAdapter(engine, options);
    this.adapter.setCreateHandler((feature) => this.handleCreate(feature));
    this.adapter.setSelectHandler?.((feature) => this.handleSelect(feature));
    this.adapter.setDeleteHandler?.((feature) => this.handleDelete(feature));
    this.adapter.setUpdateHandler?.((feature) => this.handleUpdate(feature));
    this.adapter.setCancelHandler?.(() => this.handleCancel());
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumDrawAdapter(engine, options)
      : new OpenLayersDrawAdapter(engine, options);
  }

  destroy() {
    this.adapter?.destroy();
    this.adapter = null;
  }

  drawPoint(options) {
    return this.adapter.drawPoint(options);
  }

  drawLine(options) {
    return this.adapter.drawLine(options);
  }

  drawPolygon(options) {
    return this.adapter.drawPolygon(options);
  }

  drawRectangle(options) {
    return this.adapter.drawRectangle(options);
  }

  drawCircle(options) {
    return this.adapter.drawCircle(options);
  }

  stop() {
    return this.adapter.stop();
  }

  enableSelect() {
    return this.adapter.enableSelect?.();
  }

  enableGeometryEdit() {
    return this.adapter.enableGeometryEdit?.();
  }

  selectDrawing(id) {
    const feature = this.adapter.selectDrawing(id);
    this.handleSelect(feature);
    return feature;
  }

  unselectDrawing() {
    this.adapter.unselectDrawing?.();
    this.selectedFeatureId = null;
    this.mapEngine.selectedDrawingId = null;
    this.mapEngine.emitLocal?.("draw:unselect", null);
  }

  getSelectedDrawing() {
    return this.adapter.getSelectedDrawing?.() || null;
  }

  removeDrawing(id) {
    const removed = this.adapter.removeDrawing?.(id);
    if (!removed) return null;

    this.hidePopupForDrawing(removed.properties?.id || id);

    if (this.selectedFeatureId === id) {
      this.selectedFeatureId = null;
      this.mapEngine.selectedDrawingId = null;
    }

    this.syncStore();
    this.mapEngine.emitLocal?.("draw:delete", removed);
    return removed;
  }

  removeSelectedDrawing() {
    if (!this.selectedFeatureId) return null;
    return this.removeDrawing(this.selectedFeatureId);
  }

  updateSelectedDrawingProperties(properties = {}) {
    if (!this.selectedFeatureId) return null;
    return this.updateDrawingProperties(this.selectedFeatureId, properties);
  }

  updateDrawingProperties(id, properties = {}) {
    const feature = this.adapter.updateDrawingProperties?.(id, properties);
    if (!feature) return null;

    this.syncStore();
    this.mapEngine.emitLocal?.("draw:update", feature);
    return feature;
  }

  listDrawings() {
    return this.adapter.listDrawings?.() || [];
  }

  createFenceFromDrawing(id, options = {}) {
    return this.updateDrawingProperties(id, {
      featureRole: "fence",
      fenceId: options.fenceId || id,
      fenceType: options.fenceType || "taskArea",
      name: options.name || "未命名围栏",
      enabled: options.enabled !== false,
      ...options.properties,
    });
  }

  createFenceFromSelectedDrawing(options = {}) {
    if (!this.selectedFeatureId) return null;
    return this.createFenceFromDrawing(this.selectedFeatureId, options);
  }

  listFences() {
    return this.listDrawings().filter((feature) => feature.properties?.featureRole === "fence");
  }

  clear() {
    this.engine?.hidePopup?.();
    this.adapter.clear();
    this.selectedFeatureId = null;
    this.mapEngine.selectedDrawingId = null;
    this.syncStore();
    this.mapEngine.emitLocal?.("draw:clear", createFeatureCollection());
  }

  exportGeoJSON() {
    return this.adapter?.exportGeoJSON() || createFeatureCollection();
  }

  importGeoJSON(geojson) {
    const result = this.adapter.importGeoJSON(normalizeFeatureCollection(geojson));
    if (this.selectedFeatureId) this.adapter.selectDrawing?.(this.selectedFeatureId);
    return result;
  }

  handleCreate(feature) {
    this.syncStore();
    this.mapEngine.emitLocal?.("draw:create", feature);
  }

  handleSelect(feature) {
    this.selectedFeatureId = feature?.properties?.id || null;
    this.mapEngine.selectedDrawingId = this.selectedFeatureId;

    if (feature) {
      this.mapEngine.emitLocal?.("draw:select", feature);
    } else {
      this.mapEngine.emitLocal?.("draw:unselect", null);
    }
  }

  handleDelete(feature) {
    if (!feature) return;

    if (this.selectedFeatureId === feature.properties?.id) {
      this.selectedFeatureId = null;
      this.mapEngine.selectedDrawingId = null;
    }

    this.syncStore();
    this.hidePopupForDrawing(feature.properties?.id);
    this.mapEngine.emitLocal?.("draw:delete", feature);
  }

  handleUpdate(feature) {
    this.syncStore();
    this.mapEngine.emitLocal?.("draw:update", feature);
  }

  handleCancel() {
    this.mapEngine.emitLocal?.("draw:cancel", null);
  }

  syncStore() {
    this.mapEngine.drawStore = this.exportGeoJSON();
  }

  hidePopupForDrawing(id) {
    const popupEl = this.engine?.popupEl;
    const popupObjectId = popupEl?.dataset?.mapObjectId;
    if (!popupEl || !popupObjectId || popupObjectId === String(id)) {
      this.engine?.hidePopup?.();
    }
  }
}
