export function createFeature(geometry, properties = {}) {
  const id = properties.id || `draw-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  return {
    type: "Feature",
    geometry,
    properties: {
      ...properties,
      id,
    },
  };
}

export function createFeatureCollection(features = []) {
  return {
    type: "FeatureCollection",
    features: features.filter(Boolean),
  };
}

export function normalizeFeatureCollection(input) {
  if (!input) return createFeatureCollection();

  if (typeof input === "string") {
    try {
      return normalizeFeatureCollection(JSON.parse(input));
    } catch (error) {
      console.warn("DrawManager: invalid GeoJSON string", error);
      return createFeatureCollection();
    }
  }

  if (input.type === "FeatureCollection") {
    return createFeatureCollection(input.features || []);
  }

  if (input.type === "Feature") {
    return createFeatureCollection([input]);
  }

  if (input.type && input.coordinates) {
    return createFeatureCollection([createFeature(input)]);
  }

  return createFeatureCollection();
}

export function getGeometryCenter(geometry) {
  if (!geometry) return null;

  if (geometry.type === "Point") return geometry.coordinates;

  const coordinates =
    geometry.type === "LineString"
      ? geometry.coordinates
      : geometry.coordinates?.[0] || [];

  if (!coordinates.length) return null;

  const total = coordinates.reduce((acc, coord) => {
    acc[0] += coord[0];
    acc[1] += coord[1];
    return acc;
  }, [0, 0]);

  return [total[0] / coordinates.length, total[1] / coordinates.length];
}

export function translateCoordinate(coordinate, delta) {
  return [coordinate[0] + delta[0], coordinate[1] + delta[1]];
}

export function enrichMeasurements(feature) {
  if (!feature?.geometry) return feature;

  const properties = {
    ...(feature.properties || {}),
    id: feature.properties?.id || `draw-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
  };

  if (feature.geometry.type === "LineString") {
    const length = lineDistanceMeters(feature.geometry.coordinates);
    properties.length = length;
    properties.measureText = formatDistance(length);
  }

  if (feature.geometry.type === "Polygon") {
    const area = polygonAreaSquareMeters(feature.geometry.coordinates || []);
    properties.area = area;
    properties.measureText = formatArea(area);

    if (properties.shapeType === "Circle" && properties.radius) {
      properties.measureText = `半径 ${formatDistance(properties.radius)} / 面积 ${formatArea(area)}`;
    }
  }

  return {
    ...feature,
    properties,
  };
}

export function createCirclePolygon(center, radius, steps = 72) {
  const earthRadius = 6378137;
  const coordinates = [];
  const lat = center[1] * Math.PI / 180;
  const lng = center[0] * Math.PI / 180;
  const angularDistance = radius / earthRadius;

  for (let i = 0; i <= steps; i += 1) {
    const bearing = (i / steps) * Math.PI * 2;
    const pointLat = Math.asin(
      Math.sin(lat) * Math.cos(angularDistance) +
        Math.cos(lat) * Math.sin(angularDistance) * Math.cos(bearing)
    );
    const pointLng =
      lng +
      Math.atan2(
        Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(lat),
        Math.cos(angularDistance) - Math.sin(lat) * Math.sin(pointLat)
      );

    coordinates.push([pointLng * 180 / Math.PI, pointLat * 180 / Math.PI]);
  }

  return coordinates;
}

export function createRectanglePolygon(a, b) {
  const minLng = Math.min(a[0], b[0]);
  const maxLng = Math.max(a[0], b[0]);
  const minLat = Math.min(a[1], b[1]);
  const maxLat = Math.max(a[1], b[1]);

  return [
    [minLng, minLat],
    [maxLng, minLat],
    [maxLng, maxLat],
    [minLng, maxLat],
    [minLng, minLat],
  ];
}
import {
  distanceMeters,
  formatArea,
  formatDistance,
  lineDistanceMeters,
  polygonAreaSquareMeters,
} from "../utils/geometryMetrics";

export { distanceMeters, formatArea, formatDistance, lineDistanceMeters, polygonAreaSquareMeters };
