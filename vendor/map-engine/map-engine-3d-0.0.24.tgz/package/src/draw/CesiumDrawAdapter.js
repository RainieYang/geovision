import {
  createCirclePolygon,
  createFeature,
  createFeatureCollection,
  createRectanglePolygon,
  distanceMeters,
  enrichMeasurements,
  getGeometryCenter,
  normalizeFeatureCollection,
  translateCoordinate,
} from "./geojson";

export default class CesiumDrawAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.handler = null;
    this.mode = null;
    this.points = [];
    this.dragStart = null;
    this.dragEnd = null;
    this.tempEntities = [];
    this.entities = new Map();
    this.features = [];
    this.onCreate = null;
    this.onSelect = null;
    this.onDelete = null;
    this.onUpdate = null;
    this.onCancel = null;
    this.selectedFeatureId = null;
    this.keydownHandler = null;
    this.editDrag = null;
    this.cameraInputLocked = false;
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setSelectHandler(handler) {
    this.onSelect = handler;
  }

  setDeleteHandler(handler) {
    this.onDelete = handler;
  }

  setUpdateHandler(handler) {
    this.onUpdate = handler;
  }

  setCancelHandler(handler) {
    this.onCancel = handler;
  }

  destroy() {
    this.stop();
    this.clear();
  }

  stop() {
    if (this.handler) {
      this.handler.destroy();
      this.handler = null;
    }

    this.mode = null;
    this.points = [];
    this.dragStart = null;
    this.dragEnd = null;
    this.editDrag = null;
    this.clearTempEntities();

    if (this.viewer?.scene?.canvas) {
      this.viewer.scene.canvas.style.cursor = "";
      this.viewer.scene.canvas.oncontextmenu = null;
    }

    this.setCameraInputLocked(false);
    this.unbindKeyboardDelete();
  }

  drawPoint(options = {}) {
    return this.start("Point", options);
  }

  drawLine(options = {}) {
    return this.start("LineString", options);
  }

  drawPolygon(options = {}) {
    return this.start("Polygon", options);
  }

  drawRectangle(options = {}) {
    return this.start("Rectangle", options);
  }

  drawCircle(options = {}) {
    return this.start("Circle", options);
  }

  start(mode, options = {}) {
    this.stop();
    this.mode = mode;
    this.points = [];
    this.dragStart = null;
    this.dragEnd = null;
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "crosshair";
    this.viewer.scene.canvas.oncontextmenu = (event) => event.preventDefault();

    this.viewer.screenSpaceEventHandler.removeInputAction(
      this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK
    );

    if (mode === "Rectangle" || mode === "Circle") {
      this.bindDragShapeEvents(mode, options);
      return this;
    }

    this.handler.setInputAction((movement) => {
      const point = this.getLngLatFromScreen(movement.position);
      if (!point) return;

      if (mode === "Point") {
        this.points = [point];
        this.clearTempEntities();
        this.renderTempPoint(point);
        return;
      }

      this.points.push(point);
      this.renderTempPoint(point);
      this.renderTempShape(mode);

    }, this.CesiumLib.ScreenSpaceEventType.LEFT_CLICK);

    const finishDrawing = (movement) => {
      if (mode === "Point") {
        const point = this.getLngLatFromScreen(movement.position) || this.points[0];
        if (point) {
          this.finish(createFeature(
            { type: "Point", coordinates: point },
            this.createProperties(mode, options)
          ));
        }
        return;
      }

      if (mode === "LineString" && this.points.length >= 2) {
        this.finish(createFeature(
          { type: "LineString", coordinates: [...this.points] },
          this.createProperties(mode, options)
        ));
      }

      if (mode === "Polygon" && this.points.length >= 3) {
        const ring = [...this.points, this.points[0]];
        this.finish(createFeature(
          { type: "Polygon", coordinates: [ring] },
          this.createProperties(mode, options)
        ));
      }
    };

    this.handler.setInputAction(() => this.cancelCurrentDrawing(), this.CesiumLib.ScreenSpaceEventType.RIGHT_CLICK);
    this.handler.setInputAction(finishDrawing, this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);

    return this;
  }

  bindDragShapeEvents(mode, options = {}) {
    this.handler.setInputAction((movement) => {
      const point = this.getLngLatFromScreen(movement.position);
      if (!point) return;

      this.dragStart = point;
      this.dragEnd = point;
      this.setCameraInputLocked(true);
      this.renderTempPoint(point);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_DOWN);

    this.handler.setInputAction((movement) => {
      if (!this.dragStart) return;

      const point = this.getLngLatFromScreen(movement.endPosition);
      if (!point) return;

      this.dragEnd = point;
      this.renderTempDragShape(mode);
    }, this.CesiumLib.ScreenSpaceEventType.MOUSE_MOVE);

    this.handler.setInputAction((movement) => {
      if (!this.dragStart) return;

      const point = this.getLngLatFromScreen(movement.position) || this.dragEnd;
      const feature = point ? this.createDragFeature(mode, this.dragStart, point, options) : null;
      this.dragStart = null;
      this.dragEnd = null;
      this.clearTempEntities();
      this.setCameraInputLocked(false);

      if (feature) this.finish(feature);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_UP);

    this.handler.setInputAction(() => this.cancelCurrentDrawing(), this.CesiumLib.ScreenSpaceEventType.RIGHT_CLICK);
  }

  createDragFeature(mode, start, end, options = {}) {
    if (distanceMeters(start, end) < 1) return null;

    if (mode === "Rectangle") {
      return createFeature(
        { type: "Polygon", coordinates: [createRectanglePolygon(start, end)] },
        this.createProperties(mode, options)
      );
    }

    const radius = distanceMeters(start, end);
    return createFeature(
      { type: "Polygon", coordinates: [createCirclePolygon(start, radius)] },
      {
        ...this.createProperties(mode, options),
        center: start,
        radius,
      }
    );
  }

  finish(feature) {
    const nextFeature = enrichMeasurements(feature);
    this.features.push(nextFeature);
    this.clearTempEntities();
    this.renderFeature(nextFeature);
    this.onCreate?.(nextFeature);
    this.points = [];
    this.dragStart = null;
    this.dragEnd = null;
    this.setCameraInputLocked(false);
    this.viewer.scene.requestRender?.();
    return nextFeature;
  }

  createProperties(shapeType, options = {}) {
    return {
      id: options.id,
      shapeType,
      ...(options.properties || {}),
    };
  }

  clear() {
    this.stop();
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
    this.features = [];
    this.selectedFeatureId = null;
    this.viewer.scene.requestRender?.();
  }

  exportGeoJSON() {
    return createFeatureCollection(this.features.map((feature) => ({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...feature.properties },
    })));
  }

  importGeoJSON(geojson) {
    const collection = normalizeFeatureCollection(geojson);
    this.clear();
    this.features = collection.features.map((feature) => enrichMeasurements({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...(feature.properties || {}) },
    }));
    this.features.forEach((feature) => this.renderFeature(feature));
    return this.exportGeoJSON();
  }

  enableSelect() {
    this.stop();
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "pointer";
    this.bindKeyboardDelete();

    this.handler.setInputAction((movement) => {
      const picked = this.viewer.scene.pick(movement.position);
      const id = this.getPickedFeatureId(picked);

      if (id) {
        this.selectDrawing(id);
      } else {
        this.unselectDrawing();
      }
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_CLICK);

    return this;
  }

  enableGeometryEdit() {
    this.stop();
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "grab";
    this.viewer.scene.canvas.oncontextmenu = (event) => event.preventDefault();
    this.bindKeyboardDelete();

    this.handler.setInputAction((movement) => {
      const picked = this.viewer.scene.pick(movement.position);
      const target = this.getPickedEditTarget(picked);
      const point = this.getLngLatFromScreen(movement.position);

      if (!target || !point) {
        this.unselectDrawing({ silent: true });
        return;
      }

      const feature = this.selectDrawing(target.featureId, { silent: true });
      if (!feature) return;

      this.editDrag = {
        ...target,
        start: point,
        originalFeature: this.cloneFeature(feature),
      };
      this.setCameraInputLocked(true);
      this.viewer.scene.canvas.style.cursor = "grabbing";
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_DOWN);

    this.handler.setInputAction((movement) => {
      if (!this.editDrag) return;

      const point = this.getLngLatFromScreen(movement.endPosition);
      if (!point) return;

      this.updateFeatureByEditDrag(point);
    }, this.CesiumLib.ScreenSpaceEventType.MOUSE_MOVE);

    this.handler.setInputAction(() => {
      if (!this.editDrag) return;

      const feature = this.findFeature(this.editDrag.featureId);
      this.editDrag = null;
      this.setCameraInputLocked(false);
      this.viewer.scene.canvas.style.cursor = "grab";
      if (feature) this.onUpdate?.(feature);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_UP);

    this.handler.setInputAction(() => this.cancelGeometryEdit(), this.CesiumLib.ScreenSpaceEventType.RIGHT_CLICK);
    return this;
  }

  selectDrawing(id, options = {}) {
    const feature = this.findFeature(id);
    if (!feature) {
      this.unselectDrawing(options);
      return null;
    }

    this.selectedFeatureId = id;
    this.renderAll();
    if (!options.silent) this.onSelect?.(feature);
    return feature;
  }

  unselectDrawing(options = {}) {
    if (!this.selectedFeatureId) {
      if (!options.silent) this.onSelect?.(null);
      return;
    }

    this.selectedFeatureId = null;
    this.renderAll();
    if (!options.silent) this.onSelect?.(null);
  }

  getSelectedDrawing() {
    return this.selectedFeatureId ? this.findFeature(this.selectedFeatureId) : null;
  }

  removeDrawing(id) {
    const index = this.features.findIndex((feature) => feature.properties?.id === id);
    if (index < 0) return null;

    const [removed] = this.features.splice(index, 1);
    this.removeFeatureEntities(id);

    if (this.selectedFeatureId === id) this.selectedFeatureId = null;

    this.viewer.scene.requestRender?.();
    return removed;
  }

  updateDrawingProperties(id, properties = {}) {
    const feature = this.findFeature(id);
    if (!feature) return null;

    feature.properties = {
      ...(feature.properties || {}),
      ...properties,
      id,
    };
    const enriched = enrichMeasurements(feature);
    Object.assign(feature, enriched);
    this.renderAll();
    return feature;
  }

  listDrawings() {
    return this.features.map((feature) => ({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...(feature.properties || {}) },
    }));
  }

  findFeature(id) {
    return this.features.find((feature) => feature.properties?.id === id) || null;
  }

  renderAll() {
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
    this.features.forEach((feature) => this.renderFeature(feature));
    this.viewer.scene.requestRender?.();
  }

  renderFeature(feature) {
    const id = feature.properties?.id || `draw-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    feature.properties = { ...(feature.properties || {}), id };
    const isSelected = id === this.selectedFeatureId;
    const mainColor = isSelected ? this.CesiumLib.Color.ORANGE : this.CesiumLib.Color.LIME;

    let entity = null;

    if (feature.geometry.type === "Point") {
      const pointSize = isSelected ? 18 : 14;
      entity = this.viewer.entities.add({
        id,
        position: this.CesiumLib.Cartesian3.fromDegrees(
          feature.geometry.coordinates[0],
          feature.geometry.coordinates[1],
          2,
        ),
        billboard: {
          image: createDrawingPointIcon(isSelected ? "#ff9f2f" : "#16d9e3"),
          width: pointSize,
          height: pointSize,
          verticalOrigin: this.CesiumLib.VerticalOrigin.CENTER,
          heightReference: this.CesiumLib.HeightReference.RELATIVE_TO_GROUND,
          disableDepthTestDistance: 0,
        },
        properties: { drawFeature: feature, drawFeatureId: id },
      });
    }

    if (feature.geometry.type === "LineString") {
      entity = this.viewer.entities.add({
        id,
        polyline: {
          positions: this.CesiumLib.Cartesian3.fromDegreesArray(feature.geometry.coordinates.flat()),
          width: isSelected ? 5 : 3,
          material: mainColor,
          clampToGround: true,
        },
        properties: { drawFeature: feature, drawFeatureId: id },
      });
    }

    if (feature.geometry.type === "Polygon") {
      const ring = feature.geometry.coordinates[0] || [];
      entity = this.viewer.entities.add({
        id,
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(ring.flat()),
          material: mainColor.withAlpha(isSelected ? 0.38 : 0.28),
          outline: true,
          outlineColor: mainColor,
          heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        },
        properties: { drawFeature: feature, drawFeatureId: id },
      });
    }

    if (entity) {
      this.entities.set(id, entity);
      this.renderMeasureLabel(feature, id);
      // 未选中时不绘制编辑锚点；Point 的主体本身即可完成整体拖动。
      // 这样可避免 3D 中主点、重合 vertex 和业务目标 marker 叠成大光斑。
      if (isSelected && feature.geometry.type !== "Point") {
        this.renderVertices(feature, id);
      }
    }

    return entity;
  }

  renderTempPoint(coordinate) {
    const entity = this.viewer.entities.add({
      position: this.CesiumLib.Cartesian3.fromDegrees(coordinate[0], coordinate[1]),
      point: {
        pixelSize: 7,
        color: this.CesiumLib.Color.YELLOW,
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 2,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });

    this.tempEntities.push(entity);
    this.viewer.scene.requestRender?.();
    return entity;
  }

  renderTempShape(mode) {
    this.tempEntities
      .filter((entity) => entity.__drawTempShape)
      .forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = this.tempEntities.filter((entity) => !entity.__drawTempShape);

    let entity = null;

    if (mode === "LineString" && this.points.length >= 2) {
      entity = this.viewer.entities.add({
        polyline: {
          positions: this.CesiumLib.Cartesian3.fromDegreesArray(this.points.flat()),
          width: 2,
          material: this.CesiumLib.Color.YELLOW,
          clampToGround: true,
        },
      });
    }

    if (mode === "Polygon" && this.points.length >= 3) {
      const ring = [...this.points, this.points[0]];
      entity = this.viewer.entities.add({
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(ring.flat()),
          material: this.CesiumLib.Color.YELLOW.withAlpha(0.22),
          outline: true,
          outlineColor: this.CesiumLib.Color.YELLOW,
        },
      });
    }

    if (entity) {
      entity.__drawTempShape = true;
      this.tempEntities.push(entity);
      this.viewer.scene.requestRender?.();
    }
  }

  renderTempDragShape(mode) {
    if (!this.dragStart || !this.dragEnd) return;

    this.tempEntities
      .filter((entity) => entity.__drawTempShape)
      .forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = this.tempEntities.filter((entity) => !entity.__drawTempShape);

    const ring =
      mode === "Rectangle"
        ? createRectanglePolygon(this.dragStart, this.dragEnd)
        : createCirclePolygon(this.dragStart, distanceMeters(this.dragStart, this.dragEnd));

    const entity = this.viewer.entities.add({
      polygon: {
        hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(ring.flat()),
        material: this.CesiumLib.Color.YELLOW.withAlpha(0.22),
        outline: true,
        outlineColor: this.CesiumLib.Color.YELLOW,
      },
    });

    entity.__drawTempShape = true;
    this.tempEntities.push(entity);
    this.viewer.scene.requestRender?.();
  }

  clearTempEntities() {
    this.tempEntities.forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = [];
  }

  cancelCurrentSketch() {
    this.points = [];
    this.dragStart = null;
    this.dragEnd = null;
    this.clearTempEntities();
    this.setCameraInputLocked(false);
    this.viewer.scene.requestRender?.();
  }

  cancelCurrentDrawing() {
    this.cancelCurrentSketch();
    this.stop();
    this.onCancel?.();
  }

  setCameraInputLocked(locked) {
    if (this.cameraInputLocked === locked) return;

    const controller = this.viewer?.scene?.screenSpaceCameraController;
    if (!controller) return;

    controller.enableInputs = !locked;
    this.cameraInputLocked = locked;
  }

  renderMeasureLabel(feature, id) {
    const measureText = feature.properties?.measureText;
    const center = getGeometryCenter(feature.geometry);
    if (!measureText || !center) return null;

    const label = this.viewer.entities.add({
      id: `${id}-measure-label`,
      position: this.CesiumLib.Cartesian3.fromDegrees(center[0], center[1]),
      properties: { drawFeature: feature, drawFeatureId: id },
      label: {
        text: measureText,
        font: "600 14px sans-serif",
        fillColor: this.CesiumLib.Color.WHITE,
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 4,
        style: this.CesiumLib.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new this.CesiumLib.Cartesian2(0, -14),
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });

    this.entities.set(`${id}-measure-label`, label);
    return label;
  }

  renderVertices(feature, id) {
    const coordinates = this.getEditHandles(feature);

    coordinates.forEach((handle, index) => {
      const vertex = this.viewer.entities.add({
        id: `${id}-vertex-${handle.index ?? index}`,
        position: this.CesiumLib.Cartesian3.fromDegrees(handle.coordinate[0], handle.coordinate[1]),
        properties: {
          drawFeature: feature,
          drawFeatureId: id,
          drawEditRole: "vertex",
          drawVertexIndex: handle.index ?? index,
          drawEditHandle: handle.handle || "vertex",
        },
        point: {
          pixelSize: handle.handle === "center" || handle.handle === "radius" ? 9 : 7,
          color: id === this.selectedFeatureId ? this.CesiumLib.Color.ORANGE : this.CesiumLib.Color.RED,
          outlineColor: this.CesiumLib.Color.WHITE,
          outlineWidth: 2,
          heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
        },
      });

      this.entities.set(`${id}-vertex-${index}`, vertex);
    });
  }

  getLngLatFromScreen(screenPosition) {
    if (!screenPosition) return null;

    const groundPoint = this.engine.pickGroundLngLat?.(screenPosition);
    if (groundPoint) return groundPoint;

    let cartesian = null;

    if (!cartesian) {
      const ray = this.viewer.camera.getPickRay(screenPosition);
      cartesian = ray ? this.viewer.scene.globe.pick(ray, this.viewer.scene) : null;
    }

    if (!cartesian && this.viewer.scene.pickPositionSupported) {
      try {
        cartesian = this.viewer.scene.pickPosition(screenPosition);
      } catch (error) {
        cartesian = null;
      }
    }

    if (!cartesian) {
      cartesian = this.viewer.camera.pickEllipsoid(
        screenPosition,
        this.viewer.scene.globe.ellipsoid
      );
    }

    if (!cartesian) return null;

    const cartographic = this.CesiumLib.Cartographic.fromCartesian(cartesian);
    return [
      this.CesiumLib.Math.toDegrees(cartographic.longitude),
      this.CesiumLib.Math.toDegrees(cartographic.latitude),
    ];
  }

  bindKeyboardDelete() {
    this.unbindKeyboardDelete();
    this.keydownHandler = (event) => {
      if (!this.selectedFeatureId) return;
      if (event.key !== "Delete" && event.key !== "Backspace") return;

      event.preventDefault();
      const removed = this.removeDrawing(this.selectedFeatureId);
      if (removed) this.onDelete?.(removed);
    };
    window.addEventListener("keydown", this.keydownHandler);
  }

  unbindKeyboardDelete() {
    if (!this.keydownHandler) return;
    window.removeEventListener("keydown", this.keydownHandler);
    this.keydownHandler = null;
  }

  removeFeatureEntities(id) {
    Array.from(this.entities.keys())
      .filter((entityId) => entityId === id || entityId.startsWith(`${id}-`))
      .forEach((entityId) => {
        const entity = this.entities.get(entityId);
        if (entity) this.viewer.entities.remove(entity);
        this.entities.delete(entityId);
      });
  }

  getEditHandles(feature) {
    if (feature.geometry.type === "Point") {
      return [{ coordinate: feature.geometry.coordinates, index: 0, handle: "vertex" }];
    }

    if (feature.geometry.type === "LineString") {
      return feature.geometry.coordinates.map((coordinate, index) => ({
        coordinate,
        index,
        handle: "vertex",
      }));
    }

    if (feature.properties?.shapeType === "Circle") {
      const ring = feature.geometry.coordinates?.[0] || [];
      const radiusCoordinate = ring[0] || feature.properties.center;
      return [
        { coordinate: feature.properties.center || getGeometryCenter(feature.geometry), index: 0, handle: "center" },
        { coordinate: radiusCoordinate, index: 1, handle: "radius" },
      ].filter((handle) => handle.coordinate);
    }

    return (feature.geometry.coordinates?.[0] || []).slice(0, -1).map((coordinate, index) => ({
      coordinate,
      index,
      handle: "vertex",
    }));
  }

  getPickedEditTarget(picked) {
    if (!this.CesiumLib.defined(picked) || !picked.id) return null;

    const entity = picked.id;
    const propertyBag = entity.properties;
    const time = this.viewer.clock.currentTime;
    const featureId = propertyBag?.drawFeatureId?.getValue?.(time);
    if (!featureId) return null;

    return {
      featureId,
      role: propertyBag?.drawEditRole?.getValue?.(time) || "feature",
      vertexIndex: propertyBag?.drawVertexIndex?.getValue?.(time),
      handle: propertyBag?.drawEditHandle?.getValue?.(time) || "feature",
    };
  }

  updateFeatureByEditDrag(point) {
    const { featureId, role, vertexIndex, handle, start, originalFeature } = this.editDrag;
    const feature = this.findFeature(featureId);
    if (!feature) return;

    const delta = [point[0] - start[0], point[1] - start[1]];
    const nextFeature =
      role === "vertex"
        ? this.updateVertexGeometry(originalFeature, vertexIndex, point, handle)
        : this.translateFeatureGeometry(originalFeature, delta);

    if (!nextFeature) return;

    feature.geometry = nextFeature.geometry;
    feature.properties = nextFeature.properties;
    const enriched = enrichMeasurements(feature);
    Object.assign(feature, enriched);
    this.renderAll();
    this.selectDrawing(featureId, { silent: true });
  }

  updateVertexGeometry(feature, vertexIndex, point, handle) {
    const next = this.cloneFeature(feature);

    if (next.geometry.type === "Point") {
      next.geometry.coordinates = point;
      return next;
    }

    if (next.properties?.shapeType === "Circle") {
      if (handle === "center") {
        const radius = next.properties.radius || distanceMeters(next.properties.center, next.geometry.coordinates?.[0]?.[0]);
        next.properties.center = point;
        next.geometry.coordinates = [createCirclePolygon(point, radius)];
        return next;
      }

      const center = next.properties.center || getGeometryCenter(next.geometry);
      const radius = distanceMeters(center, point);
      next.properties.center = center;
      next.properties.radius = radius;
      next.geometry.coordinates = [createCirclePolygon(center, radius)];
      return next;
    }

    if (next.geometry.type === "LineString") {
      next.geometry.coordinates[vertexIndex] = point;
      return next;
    }

    if (next.geometry.type === "Polygon") {
      const ring = next.geometry.coordinates?.[0] || [];
      if (!ring[vertexIndex]) return next;
      ring[vertexIndex] = point;
      if (vertexIndex === 0) ring[ring.length - 1] = point;
      next.geometry.coordinates = [ring];
      return next;
    }

    return next;
  }

  translateFeatureGeometry(feature, delta) {
    const next = this.cloneFeature(feature);

    if (next.geometry.type === "Point") {
      next.geometry.coordinates = translateCoordinate(next.geometry.coordinates, delta);
    }

    if (next.geometry.type === "LineString") {
      next.geometry.coordinates = next.geometry.coordinates.map((coordinate) => translateCoordinate(coordinate, delta));
    }

    if (next.geometry.type === "Polygon") {
      next.geometry.coordinates = next.geometry.coordinates.map((ring) =>
        ring.map((coordinate) => translateCoordinate(coordinate, delta))
      );

      if (next.properties?.shapeType === "Circle" && next.properties.center) {
        next.properties.center = translateCoordinate(next.properties.center, delta);
      }
    }

    return next;
  }

  cancelGeometryEdit() {
    if (!this.editDrag) return;

    const feature = this.findFeature(this.editDrag.featureId);
    if (feature) {
      feature.geometry = this.editDrag.originalFeature.geometry;
      feature.properties = this.editDrag.originalFeature.properties;
      this.renderAll();
      this.selectDrawing(feature.properties.id, { silent: true });
    }

    this.editDrag = null;
    this.setCameraInputLocked(false);
    if (this.viewer?.scene?.canvas) this.viewer.scene.canvas.style.cursor = "grab";
  }

  cloneFeature(feature) {
    return {
      type: "Feature",
      geometry: JSON.parse(JSON.stringify(feature.geometry)),
      properties: JSON.parse(JSON.stringify(feature.properties || {})),
    };
  }

  getPickedFeatureId(picked) {
    if (!this.CesiumLib.defined(picked) || !picked.id) return null;

    const entity = picked.id;
    const propertyBag = entity.properties;
    const directId = propertyBag?.drawFeatureId?.getValue?.(this.viewer.clock.currentTime);
    if (directId) return directId;

    const feature = propertyBag?.drawFeature?.getValue?.(this.viewer.clock.currentTime);
    return feature?.properties?.id || null;
  }
}

function createDrawingPointIcon(fillColor) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><circle cx="24" cy="24" r="15" fill="${fillColor}" stroke="#ffffff" stroke-width="5"/><circle cx="24" cy="24" r="4" fill="#ffffff"/></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
