﻿import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import Polygon from "ol/geom/Polygon";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import Draw from "ol/interaction/Draw";
import Interaction from "ol/interaction/Interaction";
import Modify from "ol/interaction/Modify";
import PointerInteraction from "ol/interaction/Pointer";
import Translate from "ol/interaction/Translate";
import GeoJSON from "ol/format/GeoJSON";
import { Style, Circle as CircleStyle, Fill, Stroke, Text } from "ol/style";
import { fromLonLat, toLonLat } from "ol/proj";
import {
  createCirclePolygon,
  createFeature,
  distanceMeters,
  enrichMeasurements,
  getGeometryCenter,
  normalizeFeatureCollection,
} from "./geojson";

export default class OpenLayersDrawAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new VectorLayer({
      source: this.source,
      zIndex: options.zIndex ?? 1200,
      style: (feature) => this.createStyle(feature),
    });
    this.draw = null;
    this.modifyInteraction = null;
    this.translateInteraction = null;
    this.tempFeature = null;
    this.contextMenuHandler = null;
    this.geojson = new GeoJSON();
    this.features = [];
    this.onCreate = null;
    this.onSelect = null;
    this.onDelete = null;
    this.onUpdate = null;
    this.onCancel = null;
    this.selectedFeatureId = null;
    this.selectInteraction = null;
    this.keydownHandler = null;

    this.map.addLayer(this.layer);
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setSelectHandler(handler) {
    this.onSelect = handler;
  }

  setDeleteHandler(handler) {
    this.onDelete = handler;
  }

  setUpdateHandler(handler) {
    this.onUpdate = handler;
  }

  setCancelHandler(handler) {
    this.onCancel = handler;
  }

  destroy() {
    this.stop();
    this.disableSelect();
    if (this.map && this.layer) this.map.removeLayer(this.layer);
    this.source.clear();
    this.features = [];
  }

  stop() {
    if (this.draw) {
      this.map.removeInteraction(this.draw);
      this.draw = null;
    }

    this.disableGeometryEdit();

    this.clearTempFeature();

    if (this.contextMenuHandler) {
      this.map.getViewport().removeEventListener("contextmenu", this.contextMenuHandler);
      this.contextMenuHandler = null;
    }
  }

  drawPoint(options = {}) {
    return this.startDraw("Point", options);
  }

  drawLine(options = {}) {
    return this.startDraw("LineString", options);
  }

  drawPolygon(options = {}) {
    return this.startDraw("Polygon", options);
  }

  drawRectangle(options = {}) {
    return this.startDragDraw("Rectangle", {
      ...options,
      shapeType: "Rectangle",
    });
  }

  drawCircle(options = {}) {
    return this.startDragDraw("Circle", {
      ...options,
      shapeType: "Circle",
    });
  }

  startDraw(type, options = {}) {
    this.stop();
    this.disableSelect();

    if (type === "Point") return this.startPointDraw(options);

    this.draw = new Draw({
      source: this.source,
      type,
      geometryFunction: options.geometryFunction,
    });

    this.draw.on("drawend", (event) => {
      const feature = this.normalizeDrawnFeature(event.feature, options);
      this.features.push(feature);
      this.onCreate?.(feature);

      window.setTimeout(() => this.renderAll(), 0);
    });

    this.map.addInteraction(this.draw);
    this.bindContextCancel();
    return this;
  }

  startPointDraw(options = {}) {
    this.draw = new Interaction({
      handleEvent: (event) => {
        if (event.type === "click") {
          this.renderTempClickPoint(event.coordinate);
          return false;
        }

        if (event.type !== "dblclick") return true;

        event.preventDefault?.();
        event.originalEvent?.preventDefault?.();
        const coordinates = toLonLat(event.coordinate);
        const feature = enrichMeasurements(createFeature(
          { type: "Point", coordinates },
          {
            id: options.id,
            shapeType: options.shapeType || "Point",
            ...(options.properties || {}),
          }
        ));

        this.clearTempFeature();
        this.features.push(feature);
        this.onCreate?.(feature);
        this.renderAll();
        return false;
      },
    });

    this.map.addInteraction(this.draw);
    this.bindContextCancel();
    return this;
  }

  renderTempClickPoint(coordinate) {
    this.clearTempFeature();
    this.tempFeature = new Feature({ geometry: new Point(coordinate) });
    this.tempFeature.setProperties({ isTempDraw: true });
    this.source.addFeature(this.tempFeature);
  }

  startDragDraw(mode, options = {}) {
    this.stop();
    this.disableSelect();

    let startCoordinate = null;
    let currentFeature = null;

    this.draw = new PointerInteraction({
      handleDownEvent: (event) => {
        startCoordinate = event.coordinate;
        currentFeature = this.createTempDragFeature(mode, startCoordinate, startCoordinate);
        this.tempFeature = currentFeature;
        this.source.addFeature(currentFeature);
        return true;
      },
      handleDragEvent: (event) => {
        if (!startCoordinate || !currentFeature) return;
        this.updateTempDragFeature(mode, currentFeature, startCoordinate, event.coordinate);
      },
      handleUpEvent: (event) => {
        if (!startCoordinate || !currentFeature) return false;

        const feature = this.createDragFeature(mode, startCoordinate, event.coordinate, options);
        this.clearTempFeature();
        startCoordinate = null;
        currentFeature = null;

        if (feature) {
          this.features.push(feature);
          this.onCreate?.(feature);
          this.renderAll();
        }

        return false;
      },
    });

    this.map.addInteraction(this.draw);
    this.bindContextCancel();
    return this;
  }

  normalizeDrawnFeature(olFeature, options = {}) {
    const geometry = olFeature.getGeometry();
    const shapeType = options.shapeType;
    const properties = {
      id: options.id,
      shapeType: shapeType || geometry.getType(),
      ...(options.properties || {}),
    };

    if (shapeType === "Circle") {
      const center = toLonLat(geometry.getCenter());
      const edge = toLonLat([geometry.getCenter()[0] + geometry.getRadius(), geometry.getCenter()[1]]);
      const radius = distanceMeters(center, edge);
      return enrichMeasurements(createFeature(
        {
          type: "Polygon",
          coordinates: [createCirclePolygon(center, radius)],
        },
        {
          ...properties,
          center,
          radius,
        }
      ));
    }

    if (shapeType === "Rectangle") {
      const coordinates = this.geojson.writeFeatureObject(olFeature, {
        featureProjection: "EPSG:3857",
        dataProjection: "EPSG:4326",
      }).geometry.coordinates;
      return enrichMeasurements(createFeature(
        {
          type: "Polygon",
          coordinates,
        },
        properties
      ));
    }

    const exported = this.geojson.writeFeatureObject(olFeature, {
      featureProjection: "EPSG:3857",
      dataProjection: "EPSG:4326",
    });

    return enrichMeasurements(createFeature(exported.geometry, properties));
  }

  createDragFeature(mode, startCoordinate, endCoordinate, options = {}) {
    const start = toLonLat(startCoordinate);
    const end = toLonLat(endCoordinate);
    const properties = {
      id: options.id,
      shapeType: mode,
      ...(options.properties || {}),
    };

    if (distanceMeters(start, end) < 1) return null;

    if (mode === "Rectangle") {
      return enrichMeasurements(createFeature(
        {
          type: "Polygon",
          coordinates: [this.createRectangleRing(start, end)],
        },
        properties
      ));
    }

    const radius = distanceMeters(start, end);
    return enrichMeasurements(createFeature(
      {
        type: "Polygon",
        coordinates: [createCirclePolygon(start, radius)],
      },
      {
        ...properties,
        center: start,
        radius,
      }
    ));
  }

  createTempDragFeature(mode, startCoordinate, endCoordinate) {
    const feature = new Feature({
      geometry: new Polygon([this.createProjectedDragRing(mode, startCoordinate, endCoordinate)]),
    });
    feature.setProperties({ isTempDraw: true });
    return feature;
  }

  updateTempDragFeature(mode, feature, startCoordinate, endCoordinate) {
    feature.setGeometry(new Polygon([this.createProjectedDragRing(mode, startCoordinate, endCoordinate)]));
  }

  createProjectedDragRing(mode, startCoordinate, endCoordinate) {
    const start = toLonLat(startCoordinate);
    const end = toLonLat(endCoordinate);
    const ring =
      mode === "Rectangle"
        ? this.createRectangleRing(start, end)
        : createCirclePolygon(start, distanceMeters(start, end));

    return ring.map((coordinate) => fromLonLat(coordinate));
  }

  createRectangleRing(a, b) {
    const minLng = Math.min(a[0], b[0]);
    const maxLng = Math.max(a[0], b[0]);
    const minLat = Math.min(a[1], b[1]);
    const maxLat = Math.max(a[1], b[1]);

    return [
      [minLng, minLat],
      [maxLng, minLat],
      [maxLng, maxLat],
      [minLng, maxLat],
      [minLng, minLat],
    ];
  }

  bindContextCancel() {
    this.contextMenuHandler = (event) => {
      event.preventDefault();
      this.draw?.abortDrawing?.();
      this.stop();
      this.onCancel?.();
    };
    this.map.getViewport().addEventListener("contextmenu", this.contextMenuHandler);
  }

  clearTempFeature() {
    if (this.tempFeature) {
      this.source.removeFeature(this.tempFeature);
      this.tempFeature = null;
    }
  }

  clear() {
    this.stop();
    this.disableSelect();
    this.source.clear();
    this.features = [];
    this.selectedFeatureId = null;
  }

  exportGeoJSON() {
    return {
      type: "FeatureCollection",
      features: this.features.map((feature) => ({
        type: "Feature",
        geometry: feature.geometry,
        properties: { ...feature.properties },
      })),
    };
  }

  importGeoJSON(geojson) {
    const collection = normalizeFeatureCollection(geojson);
    this.clear();
    this.features = collection.features.map((feature) => enrichMeasurements({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...(feature.properties || {}) },
    }));
    this.renderAll();
    if (this.selectedFeatureId && !this.findFeature(this.selectedFeatureId)) {
      this.selectedFeatureId = null;
    }
    return this.exportGeoJSON();
  }

  enableSelect() {
    this.stop();
    this.disableSelect();

    this.selectInteraction = new PointerInteraction({
      handleDownEvent: (event) => {
        const feature =
          this.getDrawFeatureAtPixel(event.pixel)?.get?.("drawFeature") ||
          this.getDrawFeatureAtCoordinate(event.coordinate);

        if (feature?.properties?.id) {
          this.selectDrawing(feature.properties.id);
        } else {
          this.unselectDrawing();
        }

        return false;
      },
    });

    this.keydownHandler = (event) => {
      if (!this.selectedFeatureId) return;
      if (event.key !== "Delete" && event.key !== "Backspace") return;

      event.preventDefault();
      const removed = this.removeDrawing(this.selectedFeatureId);
      if (removed) this.onDelete?.(removed);
    };

    this.map.addInteraction(this.selectInteraction);
    document.addEventListener("keydown", this.keydownHandler, true);
    return this;
  }

  disableSelect() {
    if (this.selectInteraction) {
      this.map.removeInteraction(this.selectInteraction);
      this.selectInteraction = null;
    }

    if (this.keydownHandler) {
      document.removeEventListener("keydown", this.keydownHandler, true);
      this.keydownHandler = null;
    }
  }

  selectDrawing(id) {
    const feature = this.findFeature(id);
    if (!feature) {
      this.unselectDrawing();
      return null;
    }

    this.selectedFeatureId = id;
    this.renderAll();
    this.onSelect?.(feature);
    return feature;
  }

  unselectDrawing() {
    if (!this.selectedFeatureId) {
      this.onSelect?.(null);
      return;
    }

    this.selectedFeatureId = null;
    this.renderAll();
    this.onSelect?.(null);
  }

  getSelectedDrawing() {
    return this.selectedFeatureId ? this.findFeature(this.selectedFeatureId) : null;
  }

  removeDrawing(id) {
    const index = this.features.findIndex((feature) => feature.properties?.id === id);
    if (index < 0) return null;

    const [removed] = this.features.splice(index, 1);
    if (this.selectedFeatureId === id) this.selectedFeatureId = null;
    this.renderAll();
    return removed;
  }

  updateDrawingProperties(id, properties = {}) {
    const feature = this.findFeature(id);
    if (!feature) return null;

    feature.properties = {
      ...(feature.properties || {}),
      ...properties,
      id,
    };
    const enriched = enrichMeasurements(feature);
    Object.assign(feature, enriched);
    this.renderAll();
    return feature;
  }

  listDrawings() {
    return this.features.map((feature) => ({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...(feature.properties || {}) },
    }));
  }

  enableGeometryEdit() {
    this.stop();
    this.disableSelect();
    this.disableGeometryEdit();

    this.modifyInteraction = new Modify({
      source: this.source,
    });

    this.translateInteraction = new Translate({
      layers: [this.layer],
    });

    const commit = () => this.commitSourceFeatures();
    this.modifyInteraction.on("modifyend", commit);
    this.translateInteraction.on("translateend", commit);

    this.map.addInteraction(this.modifyInteraction);
    this.map.addInteraction(this.translateInteraction);
    return this;
  }

  disableGeometryEdit() {
    if (this.modifyInteraction) {
      this.map.removeInteraction(this.modifyInteraction);
      this.modifyInteraction = null;
    }

    if (this.translateInteraction) {
      this.map.removeInteraction(this.translateInteraction);
      this.translateInteraction = null;
    }
  }

  commitSourceFeatures() {
    this.features = this.source
      .getFeatures()
      .map((olFeature) => this.normalizeEditedOlFeature(olFeature))
      .filter(Boolean);
    this.renderAll();
    this.onUpdate?.(this.exportGeoJSON());
  }

  normalizeEditedOlFeature(olFeature) {
    const drawFeature = olFeature.get("drawFeature");
    if (!drawFeature) return null;

    const exported = this.geojson.writeFeatureObject(olFeature, {
      featureProjection: "EPSG:3857",
      dataProjection: "EPSG:4326",
    });

    const properties = { ...(drawFeature.properties || {}) };

    if (properties.shapeType === "Circle" && exported.geometry.type === "Polygon") {
      const center = getGeometryCenter(exported.geometry);
      const ring = exported.geometry.coordinates?.[0] || [];
      const radius =
        center && ring.length
          ? ring.reduce((sum, coordinate) => sum + distanceMeters(center, coordinate), 0) / ring.length
          : properties.radius;

      return enrichMeasurements({
        type: "Feature",
        geometry: {
          type: "Polygon",
          coordinates: [createCirclePolygon(center, radius)],
        },
        properties: {
          ...properties,
          center,
          radius,
        },
      });
    }

    return enrichMeasurements({
      type: "Feature",
      geometry: exported.geometry,
      properties,
    });
  }

  findFeature(id) {
    return this.features.find((feature) => feature.properties?.id === id) || null;
  }

  renderAll() {
    this.source.clear();
    this.features.forEach((feature) => this.source.addFeature(this.createOlFeature(feature)));
  }

  getDrawFeatureAtPixel(pixel) {
    const candidates = this.map.getFeaturesAtPixel(pixel, {
      hitTolerance: 18,
    }) || [];

    return candidates.find((feature) => feature.get("drawFeature")) || null;
  }

  getDrawFeatureAtCoordinate(coordinate) {
    const resolution = this.map.getView()?.getResolution?.() || 1;
    const tolerance = resolution * 12;

    const hit = this.source.getFeatures().find((olFeature) => {
      const drawFeature = olFeature.get("drawFeature");
      if (!drawFeature) return false;

      const geometry = olFeature.getGeometry();
      if (!geometry) return false;

      if (geometry.getType() === "Point") {
        const closest = geometry.getClosestPoint(coordinate);
        return this.projectedDistance(closest, coordinate) <= tolerance;
      }

      if (geometry.getType() === "LineString") {
        const closest = geometry.getClosestPoint(coordinate);
        return this.projectedDistance(closest, coordinate) <= tolerance;
      }

      if (geometry.getType() === "Polygon") {
        if (geometry.intersectsCoordinate(coordinate)) return true;
        const closest = geometry.getClosestPoint(coordinate);
        return this.projectedDistance(closest, coordinate) <= tolerance;
      }

      return false;
    });

    return hit?.get("drawFeature") || null;
  }

  projectedDistance(a, b) {
    if (!a || !b) return Number.POSITIVE_INFINITY;
    return Math.hypot(a[0] - b[0], a[1] - b[1]);
  }

  createOlFeature(feature) {
    let olFeature = null;

    if (feature.geometry.type === "Point") {
      olFeature = new Feature({ geometry: new Point(fromLonLat(feature.geometry.coordinates)) });
    } else if (feature.geometry.type === "Polygon") {
      olFeature = new Feature({
        geometry: new Polygon(
          feature.geometry.coordinates.map((ring) => ring.map((coord) => fromLonLat(coord)))
        ),
      });
    } else {
      olFeature = this.geojson.readFeature(feature, {
        featureProjection: "EPSG:3857",
        dataProjection: "EPSG:4326",
      });
    }

    olFeature.setProperties({ drawFeature: feature, ...feature.properties });
    return olFeature;
  }

  createStyle(feature) {
    const drawFeature = feature?.get("drawFeature");
    const isSelected =
      drawFeature?.properties?.id &&
      drawFeature.properties.id === this.selectedFeatureId;
    const strokeColor = isSelected ? "#f97316" : "#22d3ee";
    const fillColor = isSelected ? "rgba(249, 115, 22, 0.28)" : "rgba(34, 211, 238, 0.18)";
    const styles = [new Style({
      image: new CircleStyle({
        radius: isSelected ? 8 : 6,
        fill: new Fill({ color: isSelected ? "rgba(249, 115, 22, 0.95)" : "rgba(34, 211, 238, 0.9)" }),
        stroke: new Stroke({ color: "#ffffff", width: 2 }),
      }),
      fill: new Fill({ color: fillColor }),
      stroke: new Stroke({ color: strokeColor, width: isSelected ? 3 : 2 }),
    })];

    const measureText = drawFeature?.properties?.measureText;
    const labelCenter = getGeometryCenter(drawFeature?.geometry);
    if (measureText && labelCenter) {
      styles.push(new Style({
        geometry: new Point(fromLonLat(labelCenter)),
        text: new Text({
          text: measureText,
          font: "600 13px Arial, Microsoft YaHei, sans-serif",
          fill: new Fill({ color: "#ffffff" }),
          stroke: new Stroke({ color: "rgba(15, 23, 42, 0.9)", width: 4 }),
          offsetY: -10,
        }),
      }));
    }

    return styles;
  }
}
