import FeatureToolbar from "./FeatureToolbar";
import ReplayTimelineControl from "./ReplayTimelineControl";

export default class MapControls {
  constructor(mapEngine, options = {}) {
    this.mapEngine = mapEngine;
    this.options = options;
    this.container = null;
    this.rootEl = null;
    this.statusItems = new Map();
    this.statusTimer = null;
    this.activeDrawAction = null;
    this.eventCleanups = [];
    this.featureToolbar = null;
    this.replayTimeline = null;
    this.compassDragState = null;
    this.lastNorthButtonClickAt = 0;
    this.toolbarCollapsed = options.toolbarCollapsed !== false;
    this.navigationCollapsed = options.navigationCollapsed !== false;
    this.zoomSliderEl = null;
    this.isZoomSliding = false;
  }

  mount() {
    this.container = this.resolveContainer();
    if (!this.container || this.rootEl) return;

    this.container.style.position = "relative";
    this.container.querySelectorAll(":scope > .map-engine-controls").forEach((element) => element.remove());

    this.rootEl = document.createElement("div");
    this.rootEl.className = "map-engine-controls";
    this.rootEl.innerHTML = this.render();

    this.container.appendChild(this.rootEl);
    if (this.options.mapToolbar === false) {
      this.mountReplayTimeline();
      return;
    }
    this.updateModeClass();
    this.applyToolbarCollapsedState();
    this.applyNavigationCollapsedState();
    this.bindEvents();
    this.bindZoomSliderEvents();
    this.bindDrawEvents();
    this.cacheStatusItems();
    this.startStatusLoop();
    this.updateStatus();
    this.mountFeatureToolbar();
    this.mountReplayTimeline();
  }

  unmount() {
    this.featureToolbar?.unmount();
    this.featureToolbar = null;
    this.replayTimeline?.unmount();
    this.replayTimeline = null;

    if (this.statusTimer) {
      window.clearInterval(this.statusTimer);
      this.statusTimer = null;
    }

    if (this.rootEl) {
      this.rootEl.remove();
      this.rootEl = null;
    }

    this.eventCleanups.forEach((cleanup) => cleanup());
    this.eventCleanups = [];

    this.statusItems.clear();
    this.compassDragState = null;
    this.zoomSliderEl = null;
    this.isZoomSliding = false;
    this.container = null;
  }

  mountFeatureToolbar() {
    if (this.options.mapToolbar === false || this.options.featureToolbar === false) return;
    this.featureToolbar = new FeatureToolbar(this.mapEngine, this.options.featureToolbar || {});
    this.featureToolbar.mount();
  }

  mountReplayTimeline() {
    const options = this.options.replayTimeline;
    if (options !== true && options?.enabled !== true) return;
    this.replayTimeline = new ReplayTimelineControl(this.mapEngine, options);
    this.replayTimeline.mount();
  }

  render() {
    if (this.options.mapToolbar === false) return "";
    const nextType = this.mapEngine.getType() === "3d" ? "2D" : "3D";
    const vectorStyleControls = this.isVectorBasemapEnabled();
    const activeVectorStyle = this.normalizeVectorStyle(this.mapEngine.options?.localVectorStyle);

    return `
      <div class="map-engine-left-stack">
        <div class="map-engine-navigation" aria-label="Map navigation controls" aria-expanded="${!this.navigationCollapsed}">
          <button type="button" class="map-engine-navigation-close" data-action="collapse-navigation" title="Hide compass and zoom controls" aria-label="Hide compass and zoom controls">
            <span></span>
            <span></span>
          </button>
          ${this.renderCompass()}
          ${this.renderZoomSlider()}
          <button type="button" class="map-engine-navigation-north" data-action="north" title="Click to reset camera orientation; double-click to show navigation controls" aria-label="Reset camera orientation; double-click to show navigation controls">
            <span class="map-engine-navigation-north-arrow"></span>
            <strong>N</strong>
          </button>
        </div>
      </div>
      <div class="map-engine-toolbar-dock">
        <button type="button" class="map-engine-toolbar-toggle" data-action="toggle-toolbar" title="Toggle toolbar" aria-label="Toggle toolbar" aria-expanded="${!this.toolbarCollapsed}">
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="map-engine-toolbar" aria-label="Map toolbar">
          <button type="button" class="map-engine-tool-btn" data-action="reset" title="Reset view" aria-label="Reset view">${this.renderIcon("home")}</button>
          <button type="button" class="map-engine-tool-btn map-engine-view-btn" data-action="switch-view" title="Switch view" aria-label="Switch view">${this.renderIcon("box")}<span class="map-engine-view-label">${nextType}</span></button>
          <div class="map-engine-basemap-style-group" aria-label="2D basemap style" ${vectorStyleControls ? "" : "hidden"}>
            <button type="button" class="map-engine-tool-btn map-engine-style-btn${activeVectorStyle === "default" ? " is-active" : ""}" data-action="basemap-style-default" title="默认底图样式" aria-label="默认底图样式" aria-pressed="${activeVectorStyle === "default"}">${this.renderIcon("layers")}<span class="map-engine-style-label">常</span></button>
            <button type="button" class="map-engine-tool-btn map-engine-style-btn${activeVectorStyle === "military-default" ? " is-active" : ""}" data-action="basemap-style-military" title="军工底图样式" aria-label="军工底图样式" aria-pressed="${activeVectorStyle === "military-default"}">${this.renderIcon("layers")}<span class="map-engine-style-label">军</span></button>
          </div>
          <button type="button" class="map-engine-tool-btn" data-action="draw-select" title="Select/edit" aria-label="Select/edit">${this.renderIcon("mouse-pointer")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-edit" title="Edit geometry" aria-label="Edit geometry">${this.renderIcon("pencil")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-point" title="Point" aria-label="Point">${this.renderIcon("map-pin")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-line" title="Line" aria-label="Line">${this.renderIcon("slash")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-polygon" title="Polygon" aria-label="Polygon">${this.renderIcon("pentagon")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-rectangle" title="Rectangle" aria-label="Rectangle">${this.renderIcon("square")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-circle" title="Circle" aria-label="Circle">${this.renderIcon("circle")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-delete-selected" title="Delete selected" aria-label="Delete selected">${this.renderIcon("eraser")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-clear" title="Clear drawings" aria-label="Clear drawings">${this.renderIcon("trash")}</button>
          <button type="button" class="map-engine-tool-btn" data-action="draw-export" title="Export GeoJSON" aria-label="Export GeoJSON">${this.renderIcon("download")}</button>
        </div>
      </div>
      ${this.renderDrawPropertyPanel()}
      <div class="map-engine-statusbar" aria-label="Map status">
        <span>Lng <strong data-status="lng">--</strong></span>
        <span>Lat <strong data-status="lat">--</strong></span>
        <span>Height <strong data-status="height">--</strong></span>
        <span>Camera <strong data-status="cameraHeight">--</strong></span>
        <span>Zoom <strong data-status="zoom">--</strong></span>
      </div>
    `;
  }

  isDrawPropertyPanelEnabled() {
    const options = this.options.drawPropertyPanel;
    return options === true || options?.enabled === true;
  }

  renderDrawPropertyPanel() {
    if (!this.isDrawPropertyPanelEnabled()) return "";
    return `
      <div class="map-engine-property-panel" data-draw-panel hidden>
        <div class="map-engine-property-title">Shape properties</div>
        <label>
          <span>Name</span>
          <input type="text" data-draw-prop="name" placeholder="Unnamed shape" />
        </label>
        <label>
          <span>Fence type</span>
          <select data-draw-prop="fenceType">
            <option value="taskArea">Task area</option>
            <option value="forbiddenArea">Forbidden area</option>
            <option value="warningArea">Warning area</option>
          </select>
        </label>
        <label class="map-engine-property-check">
          <input type="checkbox" data-draw-prop="enabled" checked />
          <span>Enabled</span>
        </label>
        <div class="map-engine-property-meta" data-draw-meta></div>
        <div class="map-engine-property-actions">
          <button type="button" data-action="draw-save-properties">Save</button>
          <button type="button" data-action="draw-mark-fence">Set fence</button>
        </div>
      </div>
    `;
  }

  renderIcon(name) {
    const icons = {
      home: '<path d="m3 10 9-7 9 7"></path><path d="M5 10v10h14V10"></path><path d="M9 20v-6h6v6"></path>',
      box: '<path d="m21 8-9-5-9 5 9 5 9-5Z"></path><path d="M3 8v8l9 5 9-5V8"></path><path d="M12 13v8"></path>',
      layers: '<path d="m12 2 9 5-9 5-9-5 9-5Z"></path><path d="m3 12 9 5 9-5"></path><path d="m3 17 9 5 9-5"></path>',
      "mouse-pointer": '<path d="m4 4 7.1 17 2.4-7.4L21 11.1 4 4Z"></path>',
      pencil: '<path d="M17 3a2.9 2.9 0 0 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3Z"></path>',
      "map-pin": '<path d="M20 10c0 5-5.5 10.2-7.4 11.8a1 1 0 0 1-1.2 0C9.5 20.2 4 15 4 10a8 8 0 0 1 16 0Z"></path><circle cx="12" cy="10" r="3"></circle>',
      slash: '<path d="M22 2 2 22"></path>',
      pentagon: '<polygon points="12 2 21 8.5 17.5 21 6.5 21 3 8.5 12 2"></polygon>',
      square: '<rect x="5" y="5" width="14" height="14" rx="1.5"></rect>',
      circle: '<circle cx="12" cy="12" r="8"></circle>',
      eraser: '<path d="m7 21-4.3-4.3a2.4 2.4 0 0 1 0-3.4L14 2l8 8-11 11H7Z"></path><path d="M22 21H7"></path><path d="m5 11 8 8"></path>',
      trash: '<path d="M3 6h18"></path><path d="M8 6V4h8v2"></path><path d="M19 6l-1 14H6L5 6"></path><path d="M10 11v5"></path><path d="M14 11v5"></path>',
      download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><path d="M7 10l5 5 5-5"></path><path d="M12 15V3"></path>',
    };

    return `<svg class="map-engine-tool-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${icons[name] || icons.circle}</svg>`;
  }

  renderZoomSlider() {
    const { min, max, step } = this.getZoomSliderRange();
    const value = this.formatZoomSliderValue(this.getCurrentZoom(), min, max);

    return `
      <div class="map-engine-zoom-slider" aria-label="Map zoom slider" style="--map-engine-zoom-progress: ${this.getZoomProgress(value, min, max)}%;">
        <button type="button" class="map-engine-zoom-mark is-plus" data-action="zoom-in" title="Zoom in" aria-label="Zoom in">+</button>
        <div class="map-engine-zoom-track-wrap">
          <div class="map-engine-zoom-ticks" aria-hidden="true">
            ${Array.from({ length: 15 }, () => "<span></span>").join("")}
          </div>
          <input
            type="range"
            min="${min}"
            max="${max}"
            step="${step}"
            value="${value}"
            aria-label="Map zoom"
            data-zoom-slider
          />
        </div>
        <button type="button" class="map-engine-zoom-mark is-minus" data-action="zoom-out" title="Zoom out" aria-label="Zoom out">−</button>
      </div>
    `;
  }

  renderCompass() {
    return `
      <div class="map-engine-compass" aria-label="3D camera control">
        <div class="map-engine-compass-ring" data-compass-drag title="Drag to adjust heading and tilt">
          <div class="map-engine-compass-rose" data-compass-rose>
            <span class="map-engine-compass-sector is-north"></span>
            <span class="map-engine-compass-divider is-a"></span>
            <span class="map-engine-compass-divider is-b"></span>
            <span class="map-engine-compass-divider is-c"></span>
            <span class="map-engine-compass-divider is-d"></span>
            <span class="map-engine-compass-tick is-top"></span>
            <span class="map-engine-compass-tick is-right"></span>
            <span class="map-engine-compass-tick is-bottom"></span>
            <span class="map-engine-compass-tick is-left"></span>
          </div>
          <button type="button" class="map-engine-compass-north" data-compass-action="north" title="North" aria-label="North">
            <span class="map-engine-compass-arrow"></span>
            <strong>N</strong>
          </button>
          <button type="button" class="map-engine-compass-center" data-compass-action="reset" title="Top down" aria-label="Top down">
            <span></span>
          </button>
        </div>
      </div>
    `;
  }

  bindEvents() {
    this.rootEl.querySelectorAll("[data-action]").forEach((button) => {
      button.addEventListener("click", () => {
        const action = button.dataset.action;

        if (action === "toggle-toolbar") {
          this.toggleToolbar();
          return;
        }

        if (action === "collapse-navigation") {
          this.navigationCollapsed = true;
          this.applyNavigationCollapsedState();
          return;
        }

        if (action === "north") {
          this.handleNorthButtonClick();
          return;
        }

        if (action === "zoom-in") this.stepZoom(1);
        if (action === "zoom-out") this.stepZoom(-1);
        if (action === "reset") this.mapEngine.resetView?.();
        if (action === "switch-view") this.mapEngine.switchView?.();
        if (action === "basemap-style-default") {
          this.applyBasemapStyle("default");
          return;
        }
        if (action === "basemap-style-military") {
          this.applyBasemapStyle("military-default");
          return;
        }
        if (action === "draw-select") this.mapEngine.enableDrawSelect?.();
        if (action === "draw-edit") this.mapEngine.enableDrawEdit?.();
        if (action === "draw-point") this.mapEngine.drawPoint?.();
        if (action === "draw-line") this.mapEngine.drawLine?.();
        if (action === "draw-polygon") this.mapEngine.drawPolygon?.();
        if (action === "draw-rectangle") this.mapEngine.drawRectangle?.();
        if (action === "draw-circle") this.mapEngine.drawCircle?.();
        if (action === "draw-delete-selected") this.mapEngine.removeSelectedDrawing?.();
        if (action === "draw-clear") this.mapEngine.clearDrawings?.();
        if (action === "draw-save-properties") this.saveSelectedProperties(false);
        if (action === "draw-mark-fence") this.saveSelectedProperties(true);
        if (action === "draw-export") {
          const geojson = this.mapEngine.exportGeoJSON?.() || { type: "FeatureCollection", features: [] };
          window.dispatchEvent(new CustomEvent("map-engine:draw-export", { detail: geojson }));
          console.log("Draw GeoJSON", geojson);
        }

        this.updateDrawButton(action);
        this.updateModeClass();
        this.updateViewButton();
        this.updateStatus();
      });
    });

    this.bindCompassEvents();
  }

  bindZoomSliderEvents() {
    this.zoomSliderEl = this.rootEl?.querySelector("[data-zoom-slider]");
    if (!this.zoomSliderEl) return;

    const stopMapGesture = (event) => event.stopPropagation();

    this.zoomSliderEl.addEventListener("pointerdown", (event) => {
      this.isZoomSliding = true;
      stopMapGesture(event);
    });
    this.zoomSliderEl.addEventListener("pointerup", () => {
      this.isZoomSliding = false;
      this.updateZoomSlider();
    });
    this.zoomSliderEl.addEventListener("pointercancel", () => {
      this.isZoomSliding = false;
      this.updateZoomSlider();
    });
    this.zoomSliderEl.addEventListener("input", (event) => {
      stopMapGesture(event);
      this.setZoomProgressStyle(Number(event.target.value));
      this.setMapZoom(Number(event.target.value));
    });
    this.zoomSliderEl.addEventListener("change", () => {
      this.isZoomSliding = false;
      this.updateZoomSlider();
    });
  }

  bindCompassEvents() {
    const compass = this.rootEl?.querySelector(".map-engine-compass");
    if (!compass) return;

    const northButton = compass.querySelector('[data-compass-action="north"]');
    const resetButton = compass.querySelector('[data-compass-action="reset"]');
    const dragTarget = compass.querySelector("[data-compass-drag]");

    northButton?.addEventListener("click", (event) => {
      event.stopPropagation();
      this.resetNorth();
    });

    resetButton?.addEventListener("click", (event) => {
      event.stopPropagation();
      this.mapEngine.resetCameraOrientation?.();
      this.updateCompass();
    });

    dragTarget?.addEventListener("pointerdown", (event) => {
      if (event.target?.closest?.("[data-compass-action]")) return;
      this.startCompassDrag(event);
    });
  }

  startCompassDrag(event) {
    const orientation = this.mapEngine.getCameraOrientation?.();
    if (!orientation) return;

    event.preventDefault();
    const is2d = this.mapEngine.getType?.() !== "3d";
    const dragTarget = event.currentTarget;
    const rect = dragTarget?.getBoundingClientRect?.();
    const centerX = rect ? rect.left + rect.width / 2 : event.clientX;
    const centerY = rect ? rect.top + rect.height / 2 : event.clientY;
    this.compassDragState = {
      mode: is2d ? "2d" : "3d",
      startX: event.clientX,
      startY: event.clientY,
      heading: orientation.heading || 0,
      pitch: orientation.pitch || -Math.PI / 2,
      centerX,
      centerY,
      startPointerAngle: Math.atan2(event.clientY - centerY, event.clientX - centerX),
    };

    const handleMove = (moveEvent) => this.handleCompassDrag(moveEvent);
    const handleUp = () => {
      this.compassDragState = null;
      window.removeEventListener("pointermove", handleMove);
      window.removeEventListener("pointerup", handleUp);
      window.removeEventListener("pointercancel", handleUp);
    };

    window.addEventListener("pointermove", handleMove);
    window.addEventListener("pointerup", handleUp);
    window.addEventListener("pointercancel", handleUp);
  }

  handleCompassDrag(event) {
    if (!this.compassDragState) return;

    event.preventDefault();

    if (this.compassDragState.mode === "2d") {
      const pointerAngle = Math.atan2(
        event.clientY - this.compassDragState.centerY,
        event.clientX - this.compassDragState.centerX
      );
      const heading = this.compassDragState.heading + pointerAngle - this.compassDragState.startPointerAngle;
      this.mapEngine.setCameraOrientation?.({ heading, duration: 0 });
      this.updateCompass();
      return;
    }

    const dx = event.clientX - this.compassDragState.startX;
    const dy = event.clientY - this.compassDragState.startY;
    const heading = this.compassDragState.heading - dx * 0.01;
    const pitch = this.clampCompassPitch(this.compassDragState.pitch + dy * 0.008);

    this.mapEngine.setCameraOrientation?.({ heading, pitch, duration: 0 });
    this.updateCompass();
  }

  cacheStatusItems() {
    this.rootEl.querySelectorAll("[data-status]").forEach((element) => {
      this.statusItems.set(element.dataset.status, element);
    });
  }

  startStatusLoop() {
    this.statusTimer = window.setInterval(() => this.updateStatus(), 250);
  }

  toggleToolbar() {
    this.toolbarCollapsed = !this.toolbarCollapsed;
    this.applyToolbarCollapsedState();
  }

  resetNorth() {
    const orientation = this.mapEngine.getCameraOrientation?.();
    this.mapEngine.setCameraOrientation?.({
      heading: 0,
      pitch: orientation?.pitch,
      duration: 0.25,
    });
    this.updateCompass();
  }

  handleNorthButtonClick() {
    const clickAt = performance.now();
    const isDoubleClick = clickAt - this.lastNorthButtonClickAt <= 360;
    this.lastNorthButtonClickAt = isDoubleClick ? 0 : clickAt;

    this.mapEngine.resetCameraOrientation?.();
    this.updateCompass();
    if (!isDoubleClick) return;

    this.navigationCollapsed = false;
    this.applyNavigationCollapsedState();
  }

  applyNavigationCollapsedState() {
    const navigation = this.rootEl?.querySelector(".map-engine-navigation");
    if (!navigation) return;

    navigation.classList.toggle("is-collapsed", this.navigationCollapsed);
    navigation.setAttribute("aria-expanded", String(!this.navigationCollapsed));
  }

  applyToolbarCollapsedState() {
    this.rootEl?.classList.toggle("is-toolbar-collapsed", this.toolbarCollapsed);
    this.updateToolbarToggle();
  }

  updateToolbarToggle() {
    const button = this.rootEl?.querySelector(".map-engine-toolbar-toggle");
    if (!button) return;

    button.setAttribute("aria-expanded", String(!this.toolbarCollapsed));
    button.classList.toggle("is-collapsed", this.toolbarCollapsed);
  }

  updateViewButton() {
    const button = this.rootEl?.querySelector('[data-action="switch-view"]');
    if (!button) return;

    this.updateModeClass();
    const label = button.querySelector(".map-engine-view-label");
    if (label) {
      label.textContent = this.mapEngine.getType() === "3d" ? "2D" : "3D";
    }
  }

  updateModeClass() {
    if (!this.rootEl) return;

    const type = this.mapEngine.getType?.() === "3d" ? "3d" : "2d";
    this.rootEl.classList.toggle("is-2d", type === "2d");
    this.rootEl.classList.toggle("is-3d", type === "3d");
  }

  isVectorBasemapEnabled() {
    const configured = this.mapEngine.options?.baseMapProvider2d;
    const active = this.mapEngine.engine?.options?.baseMapProvider;
    return configured === "mvt" || (this.mapEngine.getType?.() !== "3d" && active === "mvt");
  }

  normalizeVectorStyle(name) {
    return name === "military" || name === "military-detail" || name === "military-default"
      ? "military-default"
      : "default";
  }

  async applyBasemapStyle(name) {
    if (this.mapEngine.getType?.() === "3d") return false;

    const buttons = this.rootEl?.querySelectorAll(".map-engine-style-btn") || [];
    buttons.forEach((button) => { button.disabled = true; });
    try {
      const result = await this.mapEngine.setBaseMapStyle?.(name);
      if (result === false || result?.applied === false) return false;
      this.mapEngine.options.localVectorStyle = name;
      this.updateBasemapStyleButtons(name);
      this.mapEngine.emit?.("basemap:style-change", { name, result });
      return result;
    } catch (error) {
      console.error("MapEngine basemap style switch failed", { name, error });
      return false;
    } finally {
      buttons.forEach((button) => { button.disabled = false; });
    }
  }

  updateBasemapStyleButtons(name = this.mapEngine.options?.localVectorStyle) {
    const activeStyle = this.normalizeVectorStyle(name);
    this.rootEl?.querySelectorAll(".map-engine-style-btn").forEach((button) => {
      const buttonStyle = button.dataset.action === "basemap-style-military"
        ? "military-default"
        : "default";
      const active = buttonStyle === activeStyle;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", String(active));
    });
  }

  updateDrawButton(action) {
    const drawActions = [
      "draw-select",
      "draw-edit",
      "draw-point",
      "draw-line",
      "draw-polygon",
      "draw-rectangle",
      "draw-circle",
    ];
    this.activeDrawAction = drawActions.includes(action) ? action : null;

    this.rootEl?.querySelectorAll("[data-action]").forEach((button) => {
      button.classList.toggle("is-active", button.dataset.action === this.activeDrawAction);
    });
  }

  bindDrawEvents() {
    const handlers = [
      ["draw:cancel", () => this.updateDrawButton(null)],
    ];

    if (this.isDrawPropertyPanelEnabled()) handlers.push(
      ["draw:select", (feature) => this.showPropertyPanel(feature)],
      ["draw:unselect", () => this.hidePropertyPanel()],
      ["draw:delete", () => this.hidePropertyPanel()],
      ["draw:update", () => {
        const panel = this.rootEl?.querySelector("[data-draw-panel]");
        if (!panel || panel.hidden) return;
        const selected = this.mapEngine.getSelectedDrawing?.();
        if (selected) this.showPropertyPanel(selected);
      }],
      ["draw:clear", () => this.hidePropertyPanel()],
    );

    handlers.forEach(([eventName, handler]) => {
      this.mapEngine.on?.(eventName, handler);
      this.eventCleanups.push(() => this.mapEngine.off?.(eventName, handler));
    });
  }

  showPropertyPanel(feature) {
    const panel = this.rootEl?.querySelector("[data-draw-panel]");
    if (!panel || !feature) return;

    const properties = feature.properties || {};
    panel.hidden = false;
    panel.dataset.featureId = properties.id || "";

    const nameInput = panel.querySelector('[data-draw-prop="name"]');
    const fenceTypeSelect = panel.querySelector('[data-draw-prop="fenceType"]');
    const enabledInput = panel.querySelector('[data-draw-prop="enabled"]');
    const meta = panel.querySelector("[data-draw-meta]");

    if (nameInput) nameInput.value = properties.name || "";
    if (fenceTypeSelect) fenceTypeSelect.value = properties.fenceType || "taskArea";
    if (enabledInput) enabledInput.checked = properties.enabled !== false;
    if (meta) {
      meta.textContent = `${properties.shapeType || feature.geometry?.type || "Unknown"} ${properties.measureText || properties.id || ""}`;
    }
  }

  hidePropertyPanel() {
    const panel = this.rootEl?.querySelector("[data-draw-panel]");
    if (!panel) return;
    panel.hidden = true;
    panel.dataset.featureId = "";
  }

  saveSelectedProperties(markAsFence) {
    const panel = this.rootEl?.querySelector("[data-draw-panel]");
    const id = panel?.dataset.featureId;
    if (!id) return;

    const name = panel.querySelector('[data-draw-prop="name"]')?.value || "Unnamed shape";
    const fenceType = panel.querySelector('[data-draw-prop="fenceType"]')?.value || "taskArea";
    const enabled = panel.querySelector('[data-draw-prop="enabled"]')?.checked !== false;

    if (markAsFence) {
      this.mapEngine.createFenceFromDrawing?.(id, { name, fenceType, enabled });
    } else {
      this.mapEngine.updateDrawingProperties?.(id, { name, fenceType, enabled });
    }

    const selected = this.mapEngine.getSelectedDrawing?.();
    if (selected) this.showPropertyPanel(selected);
  }

  updateStatus() {
    const status = this.mapEngine.getStatus?.() || {};

    this.updateModeClass();
    this.setStatus("lng", this.formatCoord(status.lng));
    this.setStatus("lat", this.formatCoord(status.lat));
    this.setStatus("height", this.formatMeters(status.height));
    this.setStatus("cameraHeight", this.formatMeters(status.cameraHeight));
    this.setStatus("zoom", this.formatZoom(status.zoom));
    this.updateZoomSlider(status.zoom);
    this.updateCompass();
  }

  updateCompass() {
    const rose = this.rootEl?.querySelector("[data-compass-rose]");
    if (!rose) return;

    const orientation = this.mapEngine.getCameraOrientation?.();
    if (!orientation) return;

    rose.style.transform = `rotate(${-orientation.headingDegrees}deg)`;
  }

  updateZoomSlider(zoom = this.getCurrentZoom()) {
    if (!this.zoomSliderEl || this.isZoomSliding) return;

    const { min, max } = this.getZoomSliderRange();
    const value = this.formatZoomSliderValue(zoom, min, max);
    this.zoomSliderEl.value = value;
    this.setZoomProgressStyle(Number(value));
  }

  setZoomProgressStyle(zoom) {
    const shell = this.rootEl?.querySelector(".map-engine-zoom-slider");
    if (!shell) return;

    const { min, max } = this.getZoomSliderRange();
    shell.style.setProperty("--map-engine-zoom-progress", `${this.getZoomProgress(zoom, min, max)}%`);
  }

  setMapZoom(zoom) {
    if (!Number.isFinite(zoom)) return;

    const currentView = this.getCurrentView();
    const center = currentView.center || this.options.center || this.mapEngine.options?.center;
    if (!Array.isArray(center)) return;

    const nextView = {
      ...currentView,
      center,
      zoom,
    };

    if (this.mapEngine.getType?.() === "3d") {
      const orientation = this.mapEngine.getCameraOrientation?.();
      nextView.heading = currentView.heading ?? orientation?.heading ?? 0;
      nextView.pitch = currentView.pitch ?? orientation?.pitch ?? -Math.PI / 2;
      nextView.roll = currentView.roll ?? orientation?.roll ?? 0;
      const cameraHeight = this.mapEngine.engine?.getCameraHeightByZoom?.(zoom);
      if (Number.isFinite(Number(cameraHeight))) {
        nextView.cameraHeight = Number(cameraHeight);
      } else {
        delete nextView.cameraHeight;
      }
    }

    this.mapEngine.setView?.(nextView);
    this.updateStatus();
  }

  stepZoom(direction) {
    const { min, max } = this.getZoomSliderRange();
    const current = Number(this.getCurrentZoom());
    const next = Math.max(min, Math.min(max, (Number.isFinite(current) ? current : min) + direction));

    this.setZoomProgressStyle(next);
    if (this.zoomSliderEl) this.zoomSliderEl.value = this.formatZoomSliderValue(next, min, max);
    this.setMapZoom(next);
  }

  getCurrentView() {
    return (
      this.mapEngine.getView?.() ||
      this.mapEngine.getViewState?.() ||
      this.mapEngine.engine?.getViewState?.() ||
      {}
    );
  }

  getCurrentZoom() {
    const statusZoom = this.mapEngine.getStatus?.()?.zoom;
    if (Number.isFinite(Number(statusZoom))) return Number(statusZoom);

    const viewZoom = this.getCurrentView()?.zoom;
    if (Number.isFinite(Number(viewZoom))) return Number(viewZoom);

    return Number(this.options.zoom ?? this.mapEngine.options?.zoom ?? 10);
  }

  getZoomSliderRange() {
    const sliderOptions = this.options.zoomSlider || {};
    const min = Number(sliderOptions.min ?? this.options.minZoom ?? this.options.minimumLevel ?? 2);
    const max = Number(sliderOptions.max ?? this.options.maxZoom ?? this.options.maximumLevel ?? 20);
    const step = Number(sliderOptions.step ?? 0.1);

    return {
      min: Number.isFinite(min) ? min : 2,
      max: Number.isFinite(max) ? max : 20,
      step: Number.isFinite(step) && step > 0 ? step : 0.1,
    };
  }

  getZoomProgress(value, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric) || max <= min) return 50;
    return Math.max(0, Math.min(100, ((numeric - min) / (max - min)) * 100));
  }

  formatZoomSliderValue(value, min, max) {
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return String(min);
    return String(Math.max(min, Math.min(max, numeric)));
  }

  setStatus(key, value) {
    const element = this.statusItems.get(key);
    if (element) element.textContent = value;
  }

  resolveContainer() {
    const container = this.mapEngine.options.container;
    return typeof container === "string" ? document.getElementById(container) : container;
  }

  formatCoord(value) {
    return typeof value === "number" && Number.isFinite(value) ? value.toFixed(6) : "--";
  }

  formatMeters(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) return "--";
    if (value >= 1000) return `${(value / 1000).toFixed(2)} km`;
    return `${value.toFixed(1)} m`;
  }

  formatZoom(value) {
    return typeof value === "number" && Number.isFinite(value) ? value.toFixed(2) : "--";
  }

  clampCompassPitch(pitch) {
    const minPitch = -Math.PI / 2;
    const maxPitch = -Math.PI / 12;
    return Math.max(minPitch, Math.min(maxPitch, pitch));
  }
}
