const HONG_KONG_DEMO_CENTER = [114.143562, 22.355084];

export default class FeatureToolbar {
  constructor(mapEngine, options = {}) {
    this.mapEngine = mapEngine;
    this.options = options;
    this.container = null;
    this.rootEl = null;
    this.activePanel = null;
    this.demoMarkerIds = [];
    this.demoVehicleIds = [];
    this.trackSpeed = 40;
    this.radarTargetTick = 0;
    this.demoHeatmapPointIds = [];
    this.eventCleanups = [];
  }

  mount() {
    this.container = this.resolveContainer();
    if (!this.container || this.rootEl) return;

    this.rootEl = document.createElement("div");
    this.rootEl.className = "map-engine-feature-toolbar";
    this.rootEl.innerHTML = this.render();
    this.container.appendChild(this.rootEl);
    this.bindEvents();
    this.bindTrackEvents();
  }

  unmount() {
    this.eventCleanups.forEach((cleanup) => cleanup());
    this.eventCleanups = [];
    this.rootEl?.remove();
    this.rootEl = null;
    this.container = null;
    this.activePanel = null;
  }

  resolveContainer() {
    const container = this.mapEngine.options.container;
    return typeof container === "string"
      ? document.getElementById(container)
      : container;
  }

  render() {
    return `
      <div class="demo-toggle-bar" aria-label="地图能力工具栏">
        <button type="button" data-feature="vehicle">车辆定位</button>
        <button type="button" data-feature="track">轨迹回放</button>
        <button type="button" data-feature="fence">围栏验证</button>
        <button type="button" data-feature="plot">军标绘</button>
        <button type="button" data-feature="radar">雷达</button>
        <button type="button" data-feature="heatmap">热力图</button>
      </div>
      ${this.renderVehiclePanel()}
      ${this.renderTrackPanel()}
      ${this.renderFencePanel()}
      ${this.renderPlotPanel()}
      ${this.renderRadarPanel()}
      ${this.renderHeatmapPanel()}
    `;
  }

  renderClusterPanel() {
    return `
      <div class="cluster-demo-panel" data-panel="cluster" hidden>
        <div class="cluster-demo-title">点位聚合</div>
        <div class="cluster-demo-row">状态 <strong data-cluster-status>off</strong></div>
        <div class="cluster-demo-row">测试点 <strong data-cluster-count>0</strong></div>
        <div class="cluster-demo-actions">
          <button type="button" data-action="cluster-add">添加测试点</button>
          <button type="button" data-action="cluster-enable">开启聚合</button>
          <button type="button" data-action="cluster-disable">关闭聚合</button>
          <button type="button" data-action="cluster-clear">清除测试点</button>
        </div>
        <div class="cluster-demo-log" data-log="cluster"></div>
      </div>
    `;
  }

  renderVehiclePanel() {
    return `
      <div class="vehicle-demo-panel" data-panel="vehicle" hidden>
        <div class="vehicle-demo-title">车辆定位</div>
        <div class="vehicle-demo-row">车辆数量 <strong data-vehicle-count>0</strong></div>
        <div class="vehicle-demo-statuses">
          <span><i class="is-online"></i>在线 <strong data-vehicle-online>0</strong></span>
          <span><i class="is-offline"></i>断线 <strong data-vehicle-offline>0</strong></span>
          <span><i class="is-warning"></i>告警 <strong data-vehicle-warning>0</strong></span>
        </div>
        <div class="vehicle-demo-actions">
          <button type="button" data-action="vehicle-add">批量添加车辆</button>
          <button type="button" data-action="vehicle-export">导出车辆</button>
          <button type="button" data-action="vehicle-clear">清除车辆</button>
        </div>
        <div class="vehicle-demo-log" data-log="vehicle"></div>
      </div>
    `;
  }

  renderTrackPanel() {
    return `
      <div class="track-demo-panel" data-panel="track" hidden>
        <div class="track-demo-title">轨迹回放</div>
        <div class="track-demo-row">状态 <strong data-track-status>idle</strong></div>
        <div class="track-demo-row">速度 <strong data-track-speed>1x</strong></div>
        <div class="track-demo-row">行驶速度 <strong data-track-vehicle-speed>--</strong></div>
        <div class="track-demo-row">进度 <strong data-track-progress>0%</strong></div>
        <div class="track-demo-row">跟随 <strong data-track-follow>off</strong></div>
        <div class="track-demo-actions">
          <button type="button" data-action="track-load">加载长轨迹</button>
          <button type="button" data-action="track-play">播放</button>
          <button type="button" data-action="track-pause">暂停/继续</button>
          <button type="button" data-action="track-follow">跟随/取消</button>
          <button type="button" data-action="track-speed">速度切换</button>
          <button type="button" data-action="track-stop">停止</button>
          <button type="button" data-action="track-clear">清除轨迹</button>
        </div>
        <div class="track-demo-log" data-log="track"></div>
      </div>
    `;
  }

  renderFencePanel() {
    return `
      <div class="fence-demo-panel" data-panel="fence" hidden>
        <div class="fence-demo-title">围栏验证</div>
        <div class="fence-demo-row">围栏数量 <strong data-fence-count>0</strong></div>
        <div class="fence-demo-row">提示 <strong>绘制面后设为围栏</strong></div>
        <div class="fence-demo-actions">
          <button type="button" data-action="fence-draw">绘制围栏</button>
          <button type="button" data-action="fence-check">检查车辆</button>
          <button type="button" data-action="fence-export">导出围栏</button>
          <button type="button" data-action="fence-clear-draw">清除绘制</button>
        </div>
        <div class="fence-demo-log" data-log="fence"></div>
      </div>
    `;
  }

  renderPlotPanel() {
    return `
      <div class="plot-demo-panel" data-panel="plot" hidden>
        <div class="plot-demo-title">军标绘</div>
        <div class="plot-demo-row">标绘数量 <strong data-plot-count>0</strong></div>
        <div class="plot-demo-actions">
          <button type="button" data-action="plot-command">指挥所</button>
          <button type="button" data-action="plot-route">路线</button>
          <button type="button" data-action="plot-assembly">集结区</button>
          <button type="button" data-action="plot-defense">防御区</button>
          <button type="button" data-action="plot-arrow">进攻箭头</button>
          <button type="button" data-action="plot-select">选择</button>
          <button type="button" data-action="plot-export">导出</button>
          <button type="button" data-action="plot-clear">清除</button>
        </div>
        <div class="plot-demo-log" data-log="plot"></div>
      </div>
    `;
  }

  renderRadarPanel() {
    return `
      <div class="radar-demo-panel" data-panel="radar" hidden>
        <div class="radar-demo-title">雷达</div>
        <div class="radar-demo-row">雷达数量 <strong data-radar-count>0</strong></div>
        <div class="radar-demo-row">目标数量 <strong data-radar-targets>0</strong></div>
        <div class="radar-demo-actions">
          <button type="button" data-action="radar-add">添加雷达</button>
          <button type="button" data-action="radar-scan">开始/停止</button>
          <button type="button" data-action="radar-targets">添加目标</button>
          <button type="button" data-action="radar-move">更新目标</button>
          <button type="button" data-action="radar-track">跟踪目标</button>
          <button type="button" data-action="radar-export">导出</button>
          <button type="button" data-action="radar-clear">清除</button>
        </div>
        <div class="radar-demo-log" data-log="radar"></div>
      </div>
    `;
  }

  renderHeatmapPanel() {
    return `
      <div class="heatmap-demo-panel" data-panel="heatmap" hidden>
        <div class="heatmap-demo-title">热力图</div>
        <div class="heatmap-demo-row">点位数量 <strong data-heatmap-count>0</strong></div>
        <div class="heatmap-demo-row">显示状态 <strong data-heatmap-visible>on</strong></div>
        <div class="heatmap-demo-actions">
          <button type="button" data-action="heatmap-add">添加热力点</button>
          <button type="button" data-action="heatmap-show">显示</button>
          <button type="button" data-action="heatmap-hide">隐藏</button>
          <button type="button" data-action="heatmap-export">导出</button>
          <button type="button" data-action="heatmap-clear">清除</button>
        </div>
        <div class="heatmap-demo-log" data-log="heatmap"></div>
      </div>
    `;
  }

  bindEvents() {
    this.rootEl.querySelectorAll("[data-feature]").forEach((button) => {
      button.addEventListener("click", () =>
        this.togglePanel(button.dataset.feature),
      );
    });

    this.rootEl.querySelectorAll("[data-action]").forEach((button) => {
      button.addEventListener("click", () =>
        this.handleAction(button.dataset.action),
      );
    });
  }

  bindTrackEvents() {
    const events = [
      "track:load",
      "track:play",
      "track:pause",
      "track:resume",
      "track:tick",
      "track:stop",
      "track:clear",
      "track:complete",
    ];
    events.forEach((eventName) => {
      const handler = () => this.refresh();
      this.mapEngine.on(eventName, handler);
      this.eventCleanups.push(() => this.mapEngine.off(eventName, handler));
    });
  }

  togglePanel(type) {
    const nextType = this.activePanel === type ? null : type;
    this.activePanel = nextType;

    this.rootEl.querySelectorAll("[data-panel]").forEach((panel) => {
      panel.hidden = panel.dataset.panel !== nextType;
    });

    this.rootEl.querySelectorAll("[data-feature]").forEach((button) => {
      button.classList.toggle("is-active", button.dataset.feature === nextType);
    });

    this.refresh();
  }

  handleAction(action) {
    const actions = {
      "cluster-add": () => this.addClusterMarkers(),
      "cluster-enable": () => this.enableCluster(),
      "cluster-disable": () => this.disableCluster(),
      "cluster-clear": () => this.clearClusterMarkers(),
      "vehicle-add": () => this.addVehicleMarkers(),
      "vehicle-export": () => this.log("vehicle", this.listDemoVehicles()),
      "vehicle-clear": () => this.clearVehicleMarkers(),
      "track-load": () => this.loadTrack(),
      "track-play": () => this.mapEngine.playTrack(),
      "track-pause": () => this.toggleTrackPause(),
      "track-follow": () => this.toggleTrackFollow(),
      "track-speed": () => this.toggleTrackSpeed(),
      "track-stop": () => this.mapEngine.stopTrack(),
      "track-clear": () => this.mapEngine.clearTrack(),
      "fence-draw": () => {
        this.focusDemoArea();
        this.mapEngine.drawPolygon({ name: "围栏区域" });
      },
      "fence-check": () => this.checkFenceVehicle(),
      "fence-export": () => this.log("fence", this.mapEngine.exportFences()),
      "fence-clear-draw": () => this.mapEngine.clearDrawings(),
      "plot-command": () => this.mapEngine.drawCommandPost({ name: "指挥所" }),
      "plot-route": () => this.mapEngine.drawRoute({ name: "行动路线" }),
      "plot-assembly": () =>
        this.mapEngine.drawAssemblyArea({ name: "集结区" }),
      "plot-defense": () => this.mapEngine.drawDefenseArea({ name: "防御区" }),
      "plot-arrow": () => this.mapEngine.drawAttackArrow({ name: "进攻箭头" }),
      "plot-select": () => this.mapEngine.enablePlotSelect(),
      "plot-export": () => this.log("plot", this.mapEngine.exportPlots()),
      "plot-clear": () => this.mapEngine.clearPlots(),
      "radar-add": () => this.addRadar(),
      "radar-scan": () => this.toggleRadarScan(),
      "radar-targets": () => this.addRadarTargets(),
      "radar-move": () => this.moveRadarTargets(),
      "radar-track": () =>
        this.mapEngine.trackRadarTarget("radar-demo-1", "target-1"),
      "radar-export": () => this.log("radar", this.mapEngine.exportRadars()),
      "radar-clear": () => this.mapEngine.clearRadars(),
      "heatmap-add": () => this.addHeatmapPoints(),
      "heatmap-show": () => this.showHeatmap(),
      "heatmap-hide": () => this.hideHeatmap(),
      "heatmap-export": () =>
        this.log("heatmap", this.mapEngine.exportHeatmap()),
      "heatmap-clear": () => this.clearHeatmap(),
    };

    actions[action]?.();
    this.refresh();
  }

  addClusterMarkers() {
    this.clearClusterMarkers(false);
    const center = this.getDemoCenter();
    const markers = Array.from({ length: 42 }, (_, index) => {
      const angle = (Math.PI * 2 * index) / 42;
      const radius = 0.018 + (index % 3) * 0.018;
      const id = `cluster-demo-${index + 1}`;
      this.demoMarkerIds.push(id);
      return {
        id,
        name: `聚合点 ${index + 1}`,
        position: [
          center[0] + Math.cos(angle) * radius,
          center[1] + Math.sin(angle) * radius,
        ],
        color: index % 2 ? "BLUE" : "RED",
        label: { text: `P${index + 1}`, fillColor: "#ffffff" },
      };
    });
    this.mapEngine.addMarkers(markers);
    this.log("cluster", `添加测试点 ${markers.length} 个`);
  }

  enableCluster() {
    this.mapEngine.enableCluster({ distance: 56, minClusterSize: 2 });
    this.log("cluster", "开启聚合");
  }

  disableCluster() {
    this.mapEngine.disableCluster();
    this.log("cluster", "关闭聚合");
  }

  clearClusterMarkers(writeLog = true) {
    if (this.demoMarkerIds.length)
      this.mapEngine.removeMarkers(this.demoMarkerIds);
    this.demoMarkerIds = [];
    if (writeLog) this.log("cluster", "清除测试点");
  }

  addVehicleMarkers() {
    this.clearVehicleMarkers(false);
    const center = this.getDemoCenter();
    const vehicles = createDemoVehicles(center);
    this.demoVehicleIds = vehicles.map((vehicle) => vehicle.id);
    this.mapEngine.addMarkers(vehicles);
    this.mapEngine.enableCluster({ distance: 56, minClusterSize: 2 });
    this.focusDemoArea();
    this.log("vehicle", `添加车辆 ${vehicles.length} 台，已开启聚合`);
  }

  clearVehicleMarkers(writeLog = true) {
    if (this.demoVehicleIds.length)
      this.mapEngine.removeMarkers(this.demoVehicleIds);
    this.demoVehicleIds = [];
    if (writeLog) this.log("vehicle", "清除车辆");
  }

  listDemoVehicles() {
    return this.demoVehicleIds
      .map((id) => this.mapEngine.getMarker?.(id))
      .filter(Boolean)
      .map((marker) => marker.data || marker);
  }

  loadTrack() {
    const center = this.getDemoCenter();
    const points = createSmoothDemoTrack(center);
    this.focusDemoArea();
    this.mapEngine.loadTrack(
      {
        id: "track-demo",
        name: "平稳长轨迹",
        points,
      },
      {
        speed: this.trackSpeed,
        follow: true,
        followOptions: {
          zoom: 12,
          minZoom: 11,
          height: 18000,
          pitch: -55,
          duration: 120,
        },
      },
    );
    this.log("track", `加载平稳长轨迹 ${points.length} 点`);
  }

  toggleTrackPause() {
    const state = this.mapEngine.getTrackState();
    if (state.status === "playing") this.mapEngine.pauseTrack();
    else this.mapEngine.resumeTrack();
  }

  toggleTrackSpeed() {
    this.trackSpeed = this.trackSpeed === 1 ? 2 : this.trackSpeed === 2 ? 4 : 1;
    this.mapEngine.setTrackSpeed(this.trackSpeed);
    this.log("track", `速度 ${this.trackSpeed}x`);
  }

  toggleTrackFollow() {
    const state = this.mapEngine.getTrackState?.() || {};
    const nextFollow = !state.follow;
    this.mapEngine.setTrackFollow?.(nextFollow, {
      zoom: 12,
      minZoom: 11,
      height: 18000,
      pitch: -55,
      duration: 120,
    });
    this.log("track", nextFollow ? "开启视角跟随" : "关闭视角跟随");
  }

  checkFenceVehicle() {
    const center = this.getDemoCenter();
    this.focusDemoArea();
    const result = this.mapEngine.checkFencePoint({
      id: "demo-car",
      name: "示例车辆",
      position: center,
    });
    this.log("fence", `当前围栏 ${result.insideFences?.length || 0} 个`);
  }

  addHeatmapPoints() {
    const center = this.getDemoCenter();
    const points = Array.from({ length: 80 }, (_, index) => {
      const angle = index * 0.62;
      const ring = index % 5;
      const radius = 0.012 + ring * 0.012;
      const id = `heatmap-demo-${index + 1}`;
      this.demoHeatmapPointIds.push(id);
      return {
        id,
        position: [
          center[0] + Math.cos(angle) * radius + (index % 7) * 0.0015,
          center[1] + Math.sin(angle) * radius + (index % 6) * 0.0012,
        ],
        weight: 0.25 + (ring + 1) * 0.15,
        data: { source: "demo" },
      };
    });
    this.mapEngine.setHeatmapData(points, {
      radius: 30,
      blur: 20,
      opacity: 0.74,
      gradient: ["rgba(0,0,255,0)", "#22c55e", "#facc15", "#ef4444"],
    });
    this.focusDemoArea();
    this.log("heatmap", `添加热力点 ${points.length} 个`);
  }

  showHeatmap() {
    this.mapEngine.showHeatmap();
    this.log("heatmap", "显示热力图");
  }

  hideHeatmap() {
    this.mapEngine.hideHeatmap();
    this.log("heatmap", "隐藏热力图");
  }

  clearHeatmap() {
    this.mapEngine.clearHeatmap();
    this.demoHeatmapPointIds = [];
    this.log("heatmap", "清除热力图");
  }

  addRadar() {
    const center = this.getDemoCenter();
    this.mapEngine.addRadar({
      id: "radar-demo-1",
      name: "雷达站 01",
      position: center,
      radius: 6800,
      scanWidth: 58,
      scanSpeed: 55,
    });
    this.focusDemoArea();
    this.log("radar", "添加雷达站");
  }

  toggleRadarScan() {
    const radar = this.mapEngine.getRadar("radar-demo-1");
    if (!radar) {
      this.addRadar();
      return;
    }
    if (radar.scanning) this.mapEngine.stopRadarScan(radar.id);
    else this.mapEngine.startRadarScan(radar.id);
  }

  addRadarTargets() {
    if (!this.mapEngine.getRadar("radar-demo-1")) this.addRadar();
    const center = this.getDemoCenter();
    this.mapEngine.setRadarTargets("radar-demo-1", [
      {
        id: "target-1",
        name: "目标 1",
        position: [center[0] + 0.02, center[1] + 0.015],
        status: "warning",
        trailEnabled: true,
      },
      {
        id: "target-2",
        name: "目标 2",
        position: [center[0] - 0.025, center[1] - 0.015],
        status: "active",
        trailEnabled: true,
      },
    ]);
    this.log("radar", "添加目标");
  }

  moveRadarTargets() {
    const radar = this.mapEngine.getRadar("radar-demo-1");
    if (!radar?.targets?.length) {
      this.addRadarTargets();
      return;
    }
    this.radarTargetTick += 1;
    this.mapEngine.setRadarTargets(
      radar.id,
      radar.targets.map((target, index) => ({
        ...target,
        position: [
          target.position[0] + 0.004 * Math.cos(this.radarTargetTick + index),
          target.position[1] + 0.003 * Math.sin(this.radarTargetTick + index),
        ],
      })),
    );
    this.log("radar", "更新目标位置");
  }

  refresh() {
    this.setText(
      "[data-cluster-status]",
      this.mapEngine.isClusterEnabled?.() ? "on" : "off",
    );
    this.setText("[data-cluster-count]", String(this.demoMarkerIds.length));
    this.setText("[data-vehicle-count]", String(this.demoVehicleIds.length));
    const vehicleStats = this.getDemoVehicleStats();
    this.setText("[data-vehicle-online]", String(vehicleStats.online));
    this.setText("[data-vehicle-offline]", String(vehicleStats.offline));
    this.setText("[data-vehicle-warning]", String(vehicleStats.warning));
    const trackState = this.mapEngine.getTrackState?.() || {};
    this.setText("[data-track-status]", trackState.status || "idle");
    this.setText(
      "[data-track-speed]",
      `${trackState.speed || this.trackSpeed}x`,
    );
    this.setText(
      "[data-track-vehicle-speed]",
      formatTrackVehicleSpeed(trackState.currentPoint),
    );
    this.setText(
      "[data-track-progress]",
      `${Math.round((trackState.progress || 0) * 100)}%`,
    );
    this.setText("[data-track-follow]", trackState.follow ? "on" : "off");
    this.setText(
      "[data-fence-count]",
      String(this.mapEngine.listFences?.().length || 0),
    );
    this.setText(
      "[data-plot-count]",
      String(this.mapEngine.listPlots?.().length || 0),
    );
    const radars = this.mapEngine.listRadars?.() || [];
    this.setText("[data-radar-count]", String(radars.length));
    this.setText(
      "[data-radar-targets]",
      String(
        radars.reduce((sum, radar) => sum + (radar.targets?.length || 0), 0),
      ),
    );
    const heatmap = this.mapEngine.exportHeatmap?.() || {};
    this.setText("[data-heatmap-count]", String(heatmap.points?.length || 0));
    this.setText(
      "[data-heatmap-visible]",
      heatmap.visible === false ? "off" : "on",
    );
  }

  setText(selector, value) {
    const element = this.rootEl?.querySelector(selector);
    if (element) element.textContent = value;
  }

  log(type, message) {
    const target = this.rootEl?.querySelector(`[data-log="${type}"]`);
    if (!target) return;
    const text =
      typeof message === "string" ? message : JSON.stringify(message);
    const item = document.createElement("div");
    item.textContent = `${new Date().toLocaleTimeString()} ${text}`;
    target.prepend(item);
    while (target.children.length > 6) target.lastElementChild?.remove();
  }

  getDemoVehicleStats() {
    return this.listDemoVehicles().reduce(
      (stats, vehicle) => {
        if (vehicle.statusType === "online") stats.online += 1;
        else if (vehicle.statusType === "offline") stats.offline += 1;
        else if (vehicle.statusType === "warning") stats.warning += 1;
        return stats;
      },
      { online: 0, offline: 0, warning: 0 },
    );
  }

  getDemoCenter() {
    const center =
      this.mapEngine.options.demoCenter ||
      this.mapEngine.options.center3d ||
      HONG_KONG_DEMO_CENTER;

    return Array.isArray(center) && center.length >= 2
      ? [Number(center[0]), Number(center[1])]
      : [...HONG_KONG_DEMO_CENTER];
  }

  focusDemoArea() {
    if (this.mapEngine.getType?.() !== "2d") return;
    this.mapEngine.centerAt?.(this.getDemoCenter(), {
      zoom: 12,
      minZoom: 11,
      duration: 260,
    });
  }
}

function createDemoVehicles(center) {
  const statuses = [
    {
      type: "online",
      text: "在线",
      color: "#2563eb",
      icon: "/icons/vehicle-group.png",
    },
    {
      type: "online",
      text: "在线",
      color: "#2563eb",
      icon: "/icons/vehicle-group.png",
    },
    {
      type: "online",
      text: "在线",
      color: "#2563eb",
      icon: "/icons/vehicle-group.png",
    },
    {
      type: "offline",
      text: "断线",
      color: "#ef4444",
      icon: "/icons/vehicle-group1.png",
    },
    {
      type: "warning",
      text: "告警",
      color: "#f97316",
      icon: "/icons/vehicle-group2.png",
    },
  ];

  const teams = ["一组", "二组", "三组", "四组"];
  const offsets = [
    [-0.052, 0.032],
    [-0.034, 0.016],
    [-0.018, -0.018],
    [0.002, 0.038],
    [0.018, 0.012],
    [0.034, -0.026],
    [0.052, 0.024],
    [0.064, -0.008],
    [-0.064, -0.026],
    [-0.006, -0.046],
    [0.026, 0.052],
    [-0.042, 0.052],
  ];

  return offsets.map((offset, index) => {
    const status = statuses[index % statuses.length];
    const team = teams[index % teams.length];
    const plateNo = `川A-${String(index + 1).padStart(3, "0")}D`;
    const speed = 24 + ((index * 7) % 62);
    const vehicle = {
      plateNo,
      team,
      status: status.text,
      statusType: status.type,
      statusColor: status.color,
      statusIcon: status.icon,
      speed,
      driver: `驾驶员 ${index + 1}`,
      updatedAt: new Date(Date.now() - index * 90 * 1000).toLocaleTimeString(),
    };

    return {
      id: `vehicle-demo-${index + 1}`,
      name: plateNo,
      position: [center[0] + offset[0], center[1] + offset[1]],
      icon: status.icon,
      iconWidth: 80,
      iconHeight: 80,
      cluster: true,
      label: {
        show: false,
      },
      data: vehicle,
      popup: {
        html: createVehiclePopupHtml(vehicle),
        style: {
          width: "238px",
          padding: "0",
          border: "1px solid rgba(34, 211, 238, 0.62)",
          borderRadius: "6px",
          color: "#e5f9ff",
          background:
            "linear-gradient(135deg, rgba(8, 47, 73, 0.95), rgba(15, 23, 42, 0.92))",
          boxShadow: "0 14px 34px rgba(8, 145, 178, 0.32)",
          overflow: "hidden",
        },
      },
    };
  });
}

function createVehiclePopupHtml(vehicle) {
  return `
    <div class="vehicle-popup">
      <div class="vehicle-popup-head">
        <span class="vehicle-popup-dot" style="background:${vehicle.statusColor}"></span>
        <strong>${vehicle.plateNo}</strong>
        <em>${vehicle.status}</em>
      </div>
      <div class="vehicle-popup-grid">
        <span>车组</span><strong>${vehicle.team}</strong>
        <span>速度</span><strong>${vehicle.speed} km/h</strong>
        <span>驾驶员</span><strong>${vehicle.driver}</strong>
        <span>更新时间</span><strong>${vehicle.updatedAt}</strong>
      </div>
    </div>
  `;
}

function createSmoothDemoTrack(center) {
  const anchors = [
    [center[0] - 0.095, center[1] - 0.056],
    [center[0] - 0.078, center[1] - 0.026],
    [center[0] - 0.05, center[1] - 0.006],
    [center[0] - 0.026, center[1] + 0.025],
    [center[0] + 0.006, center[1] + 0.042],
    [center[0] + 0.04, center[1] + 0.026],
    [center[0] + 0.072, center[1] + 0.052],
    [center[0] + 0.108, center[1] + 0.018],
    [center[0] + 0.132, center[1] - 0.018],
  ];

  const totalPoints = 108;
  const distances = [0];
  for (let index = 1; index < anchors.length; index += 1) {
    distances[index] =
      distances[index - 1] +
      distanceBetween(anchors[index - 1], anchors[index]);
  }

  const totalDistance = distances[distances.length - 1];
  const startTime = new Date("2026-06-10T10:00:00");

  return Array.from({ length: totalPoints }, (_, index) => {
    const targetDistance = (totalDistance * index) / (totalPoints - 1);
    const segmentIndex = findTrackSegment(distances, targetDistance);
    const segmentStart = distances[segmentIndex];
    const segmentEnd = distances[segmentIndex + 1];
    const ratio =
      segmentEnd === segmentStart
        ? 0
        : (targetDistance - segmentStart) / (segmentEnd - segmentStart);
    const start = anchors[segmentIndex];
    const end = anchors[segmentIndex + 1];
    const timestamp = new Date(startTime.getTime() + index * 10000);

    return {
      lng: interpolate(start[0], end[0], ratio),
      lat: interpolate(start[1], end[1], ratio),
      time: timestamp.toTimeString().slice(0, 8),
      speed: 45,
      data: {
        speedText: "45 km/h",
      },
    };
  });
}

function findTrackSegment(distances, targetDistance) {
  for (let index = 0; index < distances.length - 1; index += 1) {
    if (targetDistance <= distances[index + 1]) return index;
  }
  return Math.max(0, distances.length - 2);
}

function distanceBetween(a, b) {
  const avgLat = (((a[1] + b[1]) / 2) * Math.PI) / 180;
  const lngScale = Math.cos(avgLat);
  const dx = (b[0] - a[0]) * lngScale;
  const dy = b[1] - a[1];
  return Math.sqrt(dx * dx + dy * dy);
}

function interpolate(start, end, ratio) {
  return start + (end - start) * ratio;
}

function formatTrackVehicleSpeed(point) {
  if (point?.data?.speedText) return point.data.speedText;
  const speed = Number(point?.speed);
  return Number.isFinite(speed) ? `${speed} km/h` : "--";
}
