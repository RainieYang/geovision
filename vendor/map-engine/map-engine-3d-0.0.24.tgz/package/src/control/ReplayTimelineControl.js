export default class ReplayTimelineControl {
  constructor(mapEngine, options = {}) {
    this.mapEngine = mapEngine;
    this.options = options === true ? {} : options;
    this.container = null;
    this.rootEl = null;
    this.cleanups = [];
  }

  mount() {
    if (this.rootEl) return;
    this.container = this.resolveContainer();
    if (!this.container) return;
    this.rootEl = document.createElement("div");
    this.rootEl.className = "map-engine-replay-timeline";
    this.rootEl.innerHTML = this.render();
    this.container.appendChild(this.rootEl);
    this.bindDomEvents();
    this.bindReplayEvents();
    this.sync(this.mapEngine.getReplayState?.());
  }

  unmount() {
    this.cleanups.forEach((cleanup) => cleanup());
    this.cleanups = [];
    this.rootEl?.remove();
    this.rootEl = null;
    this.container = null;
  }

  render() {
    const speeds = normalizeSpeeds(this.options.speeds);
    return `
      <div class="map-engine-replay-timeline__head">
        <span class="map-engine-replay-timeline__indicator"></span>
        <strong>历史回放</strong>
        <span data-replay-current>--</span>
      </div>
      <div class="map-engine-replay-timeline__body">
        <button type="button" data-replay-action="first" title="首帧" aria-label="首帧">|◀</button>
        <button type="button" data-replay-action="previous" title="上一采样点" aria-label="上一采样点">◀</button>
        <button type="button" class="is-primary" data-replay-action="toggle" title="播放" aria-label="播放" data-replay-toggle>▶</button>
        <button type="button" data-replay-action="next" title="下一采样点" aria-label="下一采样点">▶</button>
        <button type="button" data-replay-action="last" title="末帧" aria-label="末帧">▶|</button>
        <span class="map-engine-replay-timeline__time" data-replay-start>--</span>
        <input type="range" min="0" max="1000" step="1" value="0" data-replay-range aria-label="回放时间" />
        <span class="map-engine-replay-timeline__time" data-replay-end>--</span>
        <select data-replay-speed aria-label="回放速度">
          ${speeds.map((speed) => `<option value="${speed}">${speed}x</option>`).join("")}
        </select>
      </div>
    `;
  }

  bindDomEvents() {
    const stop = (event) => event.stopPropagation();
    ["pointerdown", "mousedown", "touchstart", "wheel"].forEach((eventName) => {
      this.rootEl.addEventListener(eventName, stop);
      this.cleanups.push(() => this.rootEl?.removeEventListener(eventName, stop));
    });

    this.rootEl.querySelectorAll("[data-replay-action]").forEach((button) => {
      const handler = () => {
        const state = this.mapEngine.getReplayState?.();
        if (!state || state.mode !== "replay") return;
        const action = button.dataset.replayAction;
        if (action === "toggle") {
          if (state.playing) this.mapEngine.pause?.();
          else this.mapEngine.play?.();
          return;
        }
        this.mapEngine.pause?.();
        if (action === "first") this.mapEngine.seek?.(state.startTime);
        if (action === "last") this.mapEngine.seek?.(state.endTime);
        if (action === "previous") this.mapEngine.replayEngine?.stepToSample?.(-1);
        if (action === "next") this.mapEngine.replayEngine?.stepToSample?.(1);
      };
      button.addEventListener("click", handler);
      this.cleanups.push(() => button.removeEventListener("click", handler));
    });

    const range = this.rootEl.querySelector("[data-replay-range]");
    const rangeHandler = () => {
      const state = this.mapEngine.getReplayState?.();
      if (!state || state.mode !== "replay") return;
      const ratio = Number(range.value) / 1000;
      this.mapEngine.seek?.(state.startTime + state.duration * ratio);
    };
    range?.addEventListener("input", rangeHandler);
    if (range) this.cleanups.push(() => range.removeEventListener("input", rangeHandler));

    const speed = this.rootEl.querySelector("[data-replay-speed]");
    const speedHandler = () => this.mapEngine.setSpeed?.(Number(speed.value));
    speed?.addEventListener("change", speedHandler);
    if (speed) this.cleanups.push(() => speed.removeEventListener("change", speedHandler));
  }

  bindReplayEvents() {
    [
      "replay:load",
      "replay:play",
      "replay:pause",
      "replay:seek",
      "replay:tick",
      "replay:complete",
      "replay:exit",
    ].forEach((eventName) => {
      const off = this.mapEngine.on?.(eventName, (state) => this.sync(state));
      if (typeof off === "function") this.cleanups.push(off);
    });
  }

  sync(state = {}) {
    if (!this.rootEl) return;
    const replayActive = state.mode === "replay" && state.entityCount + state.eventCount > 0;
    const autoHide = this.options.autoHide !== false;
    this.rootEl.hidden = autoHide && !replayActive;
    this.rootEl.classList.toggle("is-disabled", !replayActive);
    this.rootEl.querySelectorAll("button, input, select").forEach((element) => {
      element.disabled = !replayActive;
    });
    const range = this.rootEl.querySelector("[data-replay-range]");
    if (range) range.value = String(Math.round((Number(state.progress) || 0) * 1000));
    setText(this.rootEl, "[data-replay-current]", formatReplayTime(state.currentTime));
    setText(this.rootEl, "[data-replay-start]", formatReplayTime(state.startTime, true));
    setText(this.rootEl, "[data-replay-end]", formatReplayTime(state.endTime, true));
    const speed = this.rootEl.querySelector("[data-replay-speed]");
    if (speed && Number.isFinite(Number(state.speed))) {
      const value = String(state.speed);
      if (![...speed.options].some((option) => option.value === value)) {
        speed.appendChild(new Option(`${value}x`, value));
      }
      speed.value = value;
    }
    const toggle = this.rootEl.querySelector("[data-replay-toggle]");
    if (toggle) {
      toggle.textContent = state.playing ? "Ⅱ" : "▶";
      toggle.title = state.playing ? "暂停" : "播放";
      toggle.setAttribute("aria-label", toggle.title);
    }
  }

  resolveContainer() {
    const configured = this.mapEngine.options?.container;
    return typeof configured === "string" ? document.getElementById(configured) : configured;
  }
}

function normalizeSpeeds(speeds) {
  const values = (Array.isArray(speeds) ? speeds : [1, 2, 4, 8])
    .map(Number)
    .filter((speed) => Number.isFinite(speed) && speed > 0);
  return [...new Set(values.length ? values : [1, 2, 4, 8])];
}

function formatReplayTime(value, short = false) {
  const time = Number(value);
  if (!Number.isFinite(time)) return "--";
  const date = new Date(time);
  const pad = (part) => String(part).padStart(2, "0");
  const clock = `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  return short ? clock : `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${clock}`;
}

function setText(root, selector, value) {
  const element = root.querySelector(selector);
  if (element) element.textContent = value;
}
