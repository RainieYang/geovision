import { clone, isLngLat, normalizeObject, normalizeTemporalObject, normalizeTime } from "../state/utils";

export function normalizeTemporalState(temporal = []) {
  return (Array.isArray(temporal) ? temporal : []).map(normalizeTemporalObject).filter(Boolean);
}

export function sampleTemporalObject(object = {}, time) {
  const temporal = normalizeTemporalObject(object);
  const sampleTime = normalizeTime(time);
  if (!temporal || !Number.isFinite(sampleTime) || !temporal.keyframes.length) return null;

  const frames = temporal.keyframes;
  const previous = findPreviousFrame(frames, sampleTime);
  const next = findNextFrame(frames, sampleTime);
  const baseFrame = previous || next;
  if (!baseFrame) return null;

  const position = interpolatePosition(previous, next, sampleTime) || baseFrame.position || temporal.position;
  const sampled = {
    id: temporal.objectId || temporal.id,
    type: temporal.objectType || temporal.type || "marker",
    position,
    geometry: clone(baseFrame.geometry || temporal.geometry),
    properties: {
      ...(temporal.properties || {}),
      ...(baseFrame.properties || {}),
      temporalSourceId: temporal.id,
      sampleTime,
    },
    style: {
      ...(temporal.style || {}),
      ...(baseFrame.style || {}),
    },
  };

  return normalizeObject(sampled);
}

export function sampleTemporalObjects(temporal = [], time) {
  return normalizeTemporalState(temporal).map((object) => sampleTemporalObject(object, time)).filter(Boolean);
}

function findPreviousFrame(frames, time) {
  let result = null;
  for (const frame of frames) {
    if (frame.time > time) break;
    result = frame;
  }
  return result;
}

function findNextFrame(frames, time) {
  return frames.find((frame) => frame.time >= time) || null;
}

function interpolatePosition(previous, next, time) {
  if (!previous?.position && !next?.position) return null;
  if (!previous?.position) return next.position;
  if (!next?.position) return previous.position;
  if (!isLngLat(previous.position) || !isLngLat(next.position)) return previous.position;
  if (previous.time === next.time) return previous.position;

  const progress = Math.max(0, Math.min(1, (time - previous.time) / (next.time - previous.time)));
  return [
    previous.position[0] + (next.position[0] - previous.position[0]) * progress,
    previous.position[1] + (next.position[1] - previous.position[1]) * progress,
    ...(Number.isFinite(Number(previous.position[2])) && Number.isFinite(Number(next.position[2]))
      ? [Number(previous.position[2]) + (Number(next.position[2]) - Number(previous.position[2])) * progress]
      : Number.isFinite(Number(previous.position[2]))
        ? [Number(previous.position[2])]
        : Number.isFinite(Number(next.position[2]))
          ? [Number(next.position[2])]
          : []),
  ];
}
