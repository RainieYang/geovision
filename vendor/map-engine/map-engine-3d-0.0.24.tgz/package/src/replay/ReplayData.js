import StateStore from "../state/StateStore";
import { clone, isLngLat, normalizeState, normalizeTime } from "../state/utils";

const DEFAULT_GAP_MULTIPLIER = 3;
const DEFAULT_TRACK_STYLE = Object.freeze({
  strokeColor: "#22d3ee",
  strokeWidth: 2.5,
});

export function compileReplayData(source = {}, fallbackState = {}) {
  const data = source && typeof source === "object" ? source : {};
  const entities = normalizeReplayEntities(data.entities || []);
  const events = normalizeReplayEvents(data.events || []);
  const entitySampleTimes = entities.flatMap((entity) => entity.samples.map((sample) => sample.time));
  const candidates = [
    ...entitySampleTimes,
    ...events.map((event) => event.time),
  ];
  const startTime = resolveBoundaryTime(data.startTime, candidates, false);
  const endTime = resolveBoundaryTime(data.endTime, candidates, true);

  if (!candidates.length) {
    throw new Error("Replay V2 requires at least one valid entity sample or event");
  }
  if (!Number.isFinite(startTime) || !Number.isFinite(endTime) || endTime < startTime) {
    throw new Error("Replay V2 has an invalid time range");
  }

  const initialState = normalizeState(data.initialState || fallbackState);
  const checkpoints = buildEventCheckpoints(initialState, events);
  const sampleTimes = uniqueSortedNumbers([
    startTime,
    endTime,
    ...entitySampleTimes.filter((time) => time >= startTime && time <= endTime),
  ]);

  return {
    initialState,
    entities,
    entityIds: new Set(entities.map((entity) => entity.id)),
    events,
    checkpoints,
    sampleTimes,
    startTime,
    endTime,
    currentTime: clampTime(normalizeTime(data.currentTime), startTime, endTime),
    preserveLive: data.preserveLive !== false,
    autoplay: data.autoplay === true,
    speed: positiveNumber(data.speed, 1),
    loop: data.loop === true,
    tickEventIntervalMs: nonNegativeNumber(data.tickEventIntervalMs, 100),
    maxTickDeltaMs: positiveNumber(data.maxTickDeltaMs, 1000),
  };
}

export function normalizeReplayEntities(entities = []) {
  if (!Array.isArray(entities)) throw new Error("Replay V2 entities must be an array");
  const ids = new Set();
  return entities.map((entity, index) => {
    if (!entity?.id) throw new Error(`Replay entity at index ${index} is missing id`);
    const id = String(entity.id);
    if (ids.has(id)) throw new Error(`Replay entity id is duplicated: ${id}`);
    ids.add(id);

    const samples = normalizeSamples(entity.samples, id);
    if (!samples.length) throw new Error(`Replay entity has no valid samples: ${id}`);
    const lifecycle = normalizeLifecycle(entity.lifecycle, samples);
    const track = normalizeTrackOptions(entity.track);

    return {
      id,
      type: entity.type || (entity.geometry ? "custom" : "marker"),
      position: normalizePosition(entity.position, `entity ${id}`),
      geometry: normalizeReplayGeometry(entity.geometry, `entity ${id}`),
      style: { ...(entity.style || {}) },
      properties: { ...(entity.properties || {}) },
      samples,
      lifecycle,
      track,
    };
  });
}

export function normalizeReplayEvents(events = []) {
  if (!Array.isArray(events)) throw new Error("Replay V2 events must be an array");
  return events.map((event, index) => {
    const time = normalizeTime(event?.time);
    if (!Number.isFinite(time)) throw new Error(`Replay event at index ${index} has invalid time`);
    if (!event.patch || typeof event.patch !== "object") {
      throw new Error(`Replay event at index ${index} is missing patch`);
    }
    return { time, patch: clone(event.patch) };
  }).sort((left, right) => left.time - right.time);
}

export function sampleReplayEntity(entity, time) {
  if (!entity?.samples?.length || !Number.isFinite(time)) return null;
  const samples = entity.samples;
  const first = samples[0];
  const last = samples[samples.length - 1];

  if (time < first.time) {
    return entity.lifecycle.beforeFirst === "hold" ? createSampledObject(entity, first, first, first.time) : null;
  }
  if (time > last.time) {
    return entity.lifecycle.afterLast === "hold" ? createSampledObject(entity, last, last, time) : null;
  }

  const previousIndex = findPreviousIndex(samples, time);
  const previous = samples[Math.max(0, previousIndex)];
  const next = samples[Math.min(samples.length - 1, previousIndex + 1)];
  if (!previous || !next) return null;
  if (isGap(previous, next, entity.lifecycle.gapThresholdMs) && time > previous.time && time < next.time) return null;
  return createSampledObject(entity, previous, next, time);
}

export function createReplayTrackObjects(entity, time) {
  if (!entity?.track?.enabled || !entity.samples?.length || !Number.isFinite(time)) return [];
  const samples = entity.samples;
  const visible = samples.filter((sample) => sample.time <= time && sample.position);
  const current = sampleReplayEntity(entity, time);
  const previousIndex = findPreviousIndex(samples, time);
  const previous = samples[previousIndex];
  const next = samples[previousIndex + 1];
  if (
    current?.position &&
    previous &&
    next &&
    time > previous.time &&
    time < next.time &&
    !isGap(previous, next, entity.lifecycle.gapThresholdMs)
  ) {
    visible.push({ time, position: current.position });
  }

  const segments = splitTrackSegments(visible, entity.lifecycle.gapThresholdMs);
  const objects = [];
  segments.forEach((segment, index) => {
    if (segment.length < 2) return;
    objects.push({
      id: replayTrackId(entity.id, "segment", index),
      type: "line",
      geometry: { type: "LineString", coordinates: segment.map((sample) => sample.position) },
      style: { ...DEFAULT_TRACK_STYLE, ...(entity.track.style || {}) },
      properties: {
        role: "replay-track",
        replayEntityId: entity.id,
        popup: { enabled: false },
      },
    });
  });

  if (entity.track.gapMode === "dashed") {
    segments.slice(0, -1).forEach((segment, index) => {
      const nextSegment = segments[index + 1];
      const start = segment[segment.length - 1]?.position;
      const end = nextSegment?.[0]?.position;
      if (!start || !end) return;
      objects.push({
        id: replayTrackId(entity.id, "gap", index),
        type: "line",
        geometry: { type: "LineString", coordinates: [start, end] },
        style: {
          ...DEFAULT_TRACK_STYLE,
          ...(entity.track.style || {}),
          ...(entity.track.gapStyle || {}),
          dashed: true,
          lineDash: entity.track.gapStyle?.lineDash || [8, 6],
        },
        properties: {
          role: "replay-track-gap",
          replayEntityId: entity.id,
          popup: { enabled: false },
        },
      });
    });
  }
  return objects;
}

export function getReplayCheckpoint(compiled, time) {
  const checkpoints = compiled?.checkpoints || [];
  let low = 0;
  let high = checkpoints.length - 1;
  let result = checkpoints[0] || null;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    if (checkpoints[middle].time <= time) {
      result = checkpoints[middle];
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }
  return result;
}

export function createPatchBetweenStates(current = {}, next = {}) {
  const patch = {};
  appendCollectionDiff(patch, current.objects, next.objects, "add", "update", "remove");
  appendCollectionDiff(patch, current.layers, next.layers, "addLayers", "updateLayers", "removeLayers");
  appendCollectionDiff(patch, current.temporal, next.temporal, "addTemporal", "updateTemporal", "removeTemporal");
  appendCollectionDiff(patch, current.tracks, next.tracks, "addTracks", "updateTracks", "removeTracks");
  appendCollectionDiff(patch, current.groups, next.groups, "addGroups", "updateGroups", "removeGroups");
  if (JSON.stringify(current.view || {}) !== JSON.stringify(next.view || {})) patch.view = clone(next.view || {});
  return patch;
}

export function getAdjacentReplayTime(sampleTimes = [], currentTime, direction) {
  if (!sampleTimes.length) return currentTime;
  if (direction < 0) {
    for (let index = sampleTimes.length - 1; index >= 0; index -= 1) {
      if (sampleTimes[index] < currentTime) return sampleTimes[index];
    }
    return sampleTimes[0];
  }
  return sampleTimes.find((time) => time > currentTime) ?? sampleTimes[sampleTimes.length - 1];
}

function normalizeSamples(samples, entityId) {
  if (!Array.isArray(samples)) throw new Error(`Replay entity samples must be an array: ${entityId}`);
  return samples.map((sample, index) => {
    const time = normalizeTime(sample?.time);
    if (!Number.isFinite(time)) throw new Error(`Replay entity ${entityId} sample ${index} has invalid time`);
    const label = `entity ${entityId} sample ${index}`;
    const position = normalizePosition(sample?.position, label);
    const geometry = normalizeReplayGeometry(sample?.geometry, label);
    if (!position && !geometry) {
      throw new Error(`Replay entity ${entityId} sample ${index} requires position or geometry`);
    }
    return {
      time,
      position,
      geometry,
      properties: { ...(sample.properties || {}) },
      style: { ...(sample.style || {}) },
    };
  }).sort((left, right) => left.time - right.time);
}

function normalizeLifecycle(lifecycle = {}, samples) {
  const multiplier = positiveNumber(lifecycle.gapMultiplier, DEFAULT_GAP_MULTIPLIER);
  const configured = lifecycle.gapThresholdMs;
  let gapThresholdMs;
  if (configured === undefined || configured === "auto") {
    gapThresholdMs = inferGapThreshold(samples, multiplier);
  } else {
    const value = Number(configured);
    gapThresholdMs = Number.isFinite(value) && value > 0 ? value : Number.POSITIVE_INFINITY;
  }
  return {
    gapThresholdMs,
    gapMultiplier: multiplier,
    beforeFirst: lifecycle.beforeFirst === "hold" ? "hold" : "hidden",
    afterLast: lifecycle.afterLast === "hold" ? "hold" : "hidden",
  };
}

function normalizeTrackOptions(track) {
  if (track === true) return { enabled: true, style: {}, gapMode: "break", gapStyle: {} };
  if (!track || track === false) return { enabled: false, style: {}, gapMode: "break", gapStyle: {} };
  return {
    enabled: track.enabled !== false,
    style: { ...(track.style || {}) },
    gapMode: track.gapMode === "dashed" ? "dashed" : "break",
    gapStyle: { ...(track.gapStyle || {}) },
  };
}

function normalizePosition(position, label) {
  if (position == null) return undefined;
  if (!isLngLat(position) || !isValidLongitudeLatitude(position)) {
    throw new Error(`Replay ${label} has invalid position`);
  }
  const normalized = [Number(position[0]), Number(position[1])];
  if (Number.isFinite(Number(position[2]))) normalized.push(Number(position[2]));
  return normalized;
}

function normalizeReplayGeometry(geometry, label) {
  if (geometry == null) return undefined;
  if (!geometry || typeof geometry !== "object" || !geometry.type) {
    throw new Error(`Replay ${label} has invalid geometry`);
  }
  if (geometry.type === "GeometryCollection") {
    if (!Array.isArray(geometry.geometries)) throw new Error(`Replay ${label} has invalid geometry`);
    geometry.geometries.forEach((item) => normalizeReplayGeometry(item, label));
    return clone(geometry);
  }
  if (!hasValidCoordinates(geometry.coordinates)) {
    throw new Error(`Replay ${label} has invalid geometry coordinates`);
  }
  return clone(geometry);
}

function hasValidCoordinates(value) {
  if (!Array.isArray(value) || value.length === 0) return false;
  if (isLngLat(value)) return isValidLongitudeLatitude(value);
  return value.every(hasValidCoordinates);
}

function isValidLongitudeLatitude(position) {
  const longitude = Number(position[0]);
  const latitude = Number(position[1]);
  return longitude >= -180 && longitude <= 180 && latitude >= -90 && latitude <= 90;
}

function inferGapThreshold(samples, multiplier) {
  const intervals = [];
  for (let index = 1; index < samples.length; index += 1) {
    const interval = samples[index].time - samples[index - 1].time;
    if (interval > 0) intervals.push(interval);
  }
  if (!intervals.length) return Number.POSITIVE_INFINITY;
  intervals.sort((left, right) => left - right);
  const middle = Math.floor(intervals.length / 2);
  const median = intervals.length % 2
    ? intervals[middle]
    : (intervals[middle - 1] + intervals[middle]) / 2;
  return median * multiplier;
}

function createSampledObject(entity, previous, next, time) {
  const progress = previous.time === next.time
    ? 0
    : Math.max(0, Math.min(1, (time - previous.time) / (next.time - previous.time)));
  const position = interpolatePosition(previous.position || entity.position, next.position || previous.position || entity.position, progress);
  const properties = {
    ...(entity.properties || {}),
    ...(previous.properties || {}),
    replayEntityId: entity.id,
    sampleTime: time,
  };
  interpolateOrientation(properties, previous.properties, next.properties, progress);
  const object = {
    id: entity.id,
    type: entity.type,
    position,
    geometry: clone(previous.geometry || entity.geometry),
    properties,
    style: { ...(entity.style || {}), ...(previous.style || {}) },
  };
  if (!object.position) delete object.position;
  if (!object.geometry) delete object.geometry;
  return object;
}

function interpolatePosition(previous, next, progress) {
  if (!previous && !next) return undefined;
  if (!previous) return clone(next);
  if (!next) return clone(previous);
  const result = [
    previous[0] + (next[0] - previous[0]) * progress,
    previous[1] + (next[1] - previous[1]) * progress,
  ];
  const previousHeight = Number(previous[2]);
  const nextHeight = Number(next[2]);
  if (Number.isFinite(previousHeight) && Number.isFinite(nextHeight)) {
    result.push(previousHeight + (nextHeight - previousHeight) * progress);
  } else if (Number.isFinite(previousHeight)) {
    result.push(previousHeight);
  } else if (Number.isFinite(nextHeight)) {
    result.push(nextHeight);
  }
  return result;
}

function interpolateOrientation(target, previous = {}, next = {}, progress) {
  const previousHeading = Number(previous?.heading);
  const nextHeading = Number(next?.heading);
  if (Number.isFinite(previousHeading) && Number.isFinite(nextHeading)) {
    const delta = ((nextHeading - previousHeading + 540) % 360) - 180;
    target.heading = normalizeDegrees(previousHeading + delta * progress);
  }
  ["pitch", "roll"].forEach((key) => {
    const start = Number(previous?.[key]);
    const end = Number(next?.[key]);
    if (Number.isFinite(start) && Number.isFinite(end)) target[key] = start + (end - start) * progress;
  });
}

function buildEventCheckpoints(initialState, events) {
  const store = new StateStore(initialState);
  const visibility = new Map();
  const checkpoints = [{ time: Number.NEGATIVE_INFINITY, state: store.getState(), visibility: new Map() }];
  events.forEach((event) => {
    store.applyPatch(event.patch);
    (event.patch.remove || []).forEach((id) => visibility.set(String(id), false));
    [...(event.patch.add || []), ...(event.patch.update || [])].forEach((object) => {
      if (object?.id) visibility.set(String(object.id), true);
    });
    checkpoints.push({ time: event.time, state: store.getState(), visibility: new Map(visibility) });
  });
  return checkpoints;
}

function appendCollectionDiff(patch, currentItems = [], nextItems = [], addKey, updateKey, removeKey) {
  const current = new Map((currentItems || []).filter((item) => item?.id != null).map((item) => [String(item.id), item]));
  const next = new Map((nextItems || []).filter((item) => item?.id != null).map((item) => [String(item.id), item]));
  const add = [];
  const update = [];
  const remove = [];
  current.forEach((_item, id) => {
    if (!next.has(id)) remove.push(id);
  });
  next.forEach((item, id) => {
    if (!current.has(id)) add.push(item);
    else if (JSON.stringify(current.get(id)) !== JSON.stringify(item)) update.push(item);
  });
  if (add.length) patch[addKey] = clone(add);
  if (update.length) patch[updateKey] = clone(update);
  if (remove.length) patch[removeKey] = remove;
}

function splitTrackSegments(samples, gapThresholdMs) {
  const segments = [];
  samples.forEach((sample) => {
    const current = segments[segments.length - 1];
    const previous = current?.[current.length - 1];
    if (!current || (previous && isGap(previous, sample, gapThresholdMs))) segments.push([sample]);
    else current.push(sample);
  });
  return segments;
}

function findPreviousIndex(samples, time) {
  let low = 0;
  let high = samples.length - 1;
  let result = -1;
  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    if (samples[middle].time <= time) {
      result = middle;
      low = middle + 1;
    } else high = middle - 1;
  }
  return result;
}

function isGap(previous, next, threshold) {
  return Number.isFinite(threshold) && next.time - previous.time > threshold;
}

function replayTrackId(entityId, role, index) {
  return `__replay_track__:${entityId}:${role}:${index}`;
}

function resolveBoundaryTime(explicitValue, candidates, useEnd) {
  const explicit = normalizeTime(explicitValue);
  if (Number.isFinite(explicit)) return explicit;
  if (!candidates.length) return 0;
  return useEnd ? Math.max(...candidates) : Math.min(...candidates);
}

function clampTime(value, start, end) {
  const time = Number.isFinite(value) ? value : start;
  return Math.max(start, Math.min(end, time));
}

function positiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function nonNegativeNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : fallback;
}

function normalizeDegrees(value) {
  return ((value % 360) + 360) % 360;
}

function uniqueSortedNumbers(values) {
  return [...new Set(values.filter(Number.isFinite))].sort((left, right) => left - right);
}
