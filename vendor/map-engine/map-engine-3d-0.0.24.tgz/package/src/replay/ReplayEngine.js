import {
  compileReplayData,
  createPatchBetweenStates,
  createReplayTrackObjects,
  getAdjacentReplayTime,
  getReplayCheckpoint,
  sampleReplayEntity,
} from "./ReplayData";

export default class ReplayEngine {
  constructor(mapEngine) {
    this.mapEngine = mapEngine;
    this.mode = "live";
    this.compiled = null;
    this.liveSnapshot = null;
    this.currentTime = 0;
    this.startTime = 0;
    this.endTime = 0;
    this.speed = 1;
    this.loop = false;
    this.playing = false;
    this.activeEntityCount = 0;
    this.renderedReplayIds = new Set();
    this.rafId = null;
    this.lastTick = 0;
    this.lastTickEventAt = 0;
  }

  enterReplay(options = {}) {
    if (this.mode === "replay") return this.getState();
    this.liveSnapshot = options.preserveLive === false ? null : this.mapEngine.exportSnapshot();
    this.mode = "replay";
    this.playing = false;
    return this.getState();
  }

  exitReplay(options = {}) {
    this.pause();
    const restore = options.restoreLive !== false && this.liveSnapshot;
    this.mode = "live";
    if (restore) this.mapEngine.importSnapshot(this.liveSnapshot);
    else this.removeRenderedReplayObjects();
    this.liveSnapshot = null;
    this.renderedReplayIds.clear();
    this.mapEngine.emit("replay:exit", this.getState());
    return this.getState();
  }

  loadReplay(data = {}) {
    let compiled;
    try {
      compiled = compileReplayData(data, data.initialState || this.mapEngine.getState());
    } catch (error) {
      this.mapEngine.emit("replay:error", { error, message: error?.message || String(error) });
      throw error;
    }

    this.pause();
    this.enterReplay({ preserveLive: compiled.preserveLive });
    this.compiled = compiled;
    this.startTime = compiled.startTime;
    this.endTime = compiled.endTime;
    this.currentTime = compiled.currentTime;
    this.speed = compiled.speed;
    this.loop = compiled.loop;
    this.renderedReplayIds.clear();
    this.renderAt(this.currentTime);
    this.mapEngine.emit("replay:load", this.getState());
    if (compiled.autoplay) this.play();
    return this.getState();
  }

  seek(time) {
    if (!this.compiled) return this.getState();
    this.currentTime = clampTime(NumberTime(time), this.startTime, this.endTime);
    this.renderAt(this.currentTime);
    this.mapEngine.emit("replay:seek", this.getState());
    return this.getState();
  }

  stepToSample(direction = 1) {
    if (!this.compiled) return this.getState();
    const nextTime = getAdjacentReplayTime(this.compiled.sampleTimes, this.currentTime, Number(direction));
    return this.seek(nextTime);
  }

  play(options = {}) {
    if (!this.compiled) return this.getState();
    if (options.speed != null) this.setSpeed(options.speed);
    if (this.playing) return this.getState();
    if (this.currentTime >= this.endTime) {
      if (this.loop) this.seek(this.startTime);
      else return this.getState();
    }
    this.enterReplay({ preserveLive: this.compiled.preserveLive });
    this.playing = true;
    this.lastTick = getNow();
    this.lastTickEventAt = 0;
    this.mapEngine.emit("replay:play", this.getState());
    this.scheduleTick();
    return this.getState();
  }

  pause() {
    if (!this.playing) return this.getState();
    this.playing = false;
    cancelFrame(this.rafId);
    this.rafId = null;
    this.mapEngine.emit("replay:pause", this.getState());
    return this.getState();
  }

  stop() {
    this.pause();
    if (this.compiled) this.seek(this.startTime);
    return this.getState();
  }

  setSpeed(speed = 1) {
    const next = Number(speed);
    this.speed = Number.isFinite(next) && next > 0 ? next : 1;
    return this.getState();
  }

  setLoop(loop = false) {
    this.loop = loop === true;
    return this.getState();
  }

  getState() {
    const duration = Math.max(0, this.endTime - this.startTime);
    return {
      mode: this.mode,
      playing: this.playing,
      currentTime: this.currentTime,
      startTime: this.startTime,
      endTime: this.endTime,
      duration,
      progress: duration > 0 ? Math.max(0, Math.min(1, (this.currentTime - this.startTime) / duration)) : 0,
      speed: this.speed,
      loop: this.loop,
      entityCount: this.compiled?.entities?.length || 0,
      activeEntityCount: this.activeEntityCount,
      eventCount: this.compiled?.events?.length || 0,
    };
  }

  destroy() {
    this.pause();
    this.compiled = null;
    this.liveSnapshot = null;
    this.renderedReplayIds.clear();
  }

  renderAt(time) {
    if (!this.compiled) return;
    const checkpoint = getReplayCheckpoint(this.compiled, time);
    const checkpointObjects = new Map(
      (checkpoint?.state?.objects || []).map((object) => [String(object.id), object]),
    );
    const nextObjects = [];
    let activeCount = 0;

    this.compiled.entities.forEach((entity) => {
      const visibility = checkpoint?.visibility?.get(entity.id);
      const sampled = visibility === false ? null : sampleReplayEntity(entity, time);
      if (sampled) {
        nextObjects.push(mergeCheckpointObject(checkpointObjects.get(entity.id), sampled));
        activeCount += 1;
      }
      nextObjects.push(...createReplayTrackObjects(entity, time));
    });

    const nextIds = new Set(nextObjects.map((object) => String(object.id)));
    const baseObjects = (checkpoint?.state?.objects || []).filter((object) => {
      const id = String(object.id);
      return !this.compiled.entityIds.has(id) && !isReplayTrackId(id);
    });
    const nextState = {
      ...checkpoint.state,
      objects: [...baseObjects, ...nextObjects],
    };
    const patch = createPatchBetweenStates(this.mapEngine.getState(), nextState);
    if (Object.keys(patch).length) this.mapEngine.applyPatch(patch);
    this.renderedReplayIds = nextIds;
    this.activeEntityCount = activeCount;
  }

  removeRenderedReplayObjects() {
    const remove = [...this.renderedReplayIds];
    if (remove.length) this.mapEngine.applyPatch({ remove });
  }

  scheduleTick() {
    cancelFrame(this.rafId);
    this.rafId = requestFrame(() => this.tick());
  }

  tick() {
    if (!this.playing || !this.compiled) return;
    const now = getNow();
    const rawDelta = Math.max(0, now - this.lastTick);
    const delta = Math.min(rawDelta, this.compiled.maxTickDeltaMs);
    this.lastTick = now;
    const targetTime = this.currentTime + delta * this.speed;

    if (targetTime >= this.endTime) {
      this.currentTime = this.endTime;
      this.renderAt(this.currentTime);
      this.emitTick(now, true);
      if (this.loop) {
        this.currentTime = this.startTime;
        this.renderAt(this.currentTime);
        this.lastTick = getNow();
        this.scheduleTick();
        return;
      }
      this.pause();
      this.mapEngine.emit("replay:complete", this.getState());
      return;
    }

    this.currentTime = targetTime;
    this.renderAt(this.currentTime);
    this.emitTick(now, false);
    this.scheduleTick();
  }

  emitTick(now, force) {
    if (force || now - this.lastTickEventAt >= this.compiled.tickEventIntervalMs) {
      this.lastTickEventAt = now;
      this.mapEngine.emit("replay:tick", this.getState());
    }
  }
}

function mergeCheckpointObject(checkpointObject, sampledObject) {
  if (!checkpointObject) return sampledObject;
  return {
    ...checkpointObject,
    ...sampledObject,
    properties: { ...(checkpointObject.properties || {}), ...(sampledObject.properties || {}) },
    style: { ...(checkpointObject.style || {}), ...(sampledObject.style || {}) },
  };
}

function isReplayTrackId(id) {
  return String(id).startsWith("__replay_track__:");
}

function NumberTime(value) {
  if (value instanceof Date) return value.getTime();
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : Number(value);
  }
  return Number(value);
}

function clampTime(time, startTime, endTime) {
  const next = Number.isFinite(time) ? time : startTime;
  return Math.max(startTime, Math.min(endTime, next));
}

function getNow() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}

function requestFrame(callback) {
  if (typeof requestAnimationFrame === "function") return requestAnimationFrame(callback);
  return setTimeout(callback, 16);
}

function cancelFrame(id) {
  if (id == null) return;
  if (typeof cancelAnimationFrame === "function") cancelAnimationFrame(id);
  else clearTimeout(id);
}
