import { createFeatureCollection, normalizeFeatureCollection } from "../draw/geojson";

export const PLOT_ROLE = "plot";

export const PLOT_TYPES = {
  COMMAND_POST: "commandPost",
  ROUTE: "route",
  ASSEMBLY_AREA: "assemblyArea",
  DEFENSE_AREA: "defenseArea",
  ATTACK_ARROW: "attackArrow",
};

export const PLOT_LABELS = {
  [PLOT_TYPES.COMMAND_POST]: "指挥所",
  [PLOT_TYPES.ROUTE]: "路线",
  [PLOT_TYPES.ASSEMBLY_AREA]: "集结区",
  [PLOT_TYPES.DEFENSE_AREA]: "防御区",
  [PLOT_TYPES.ATTACK_ARROW]: "进攻箭头",
};

export function createPlotFeature(geometry, options = {}) {
  const plotType = options.plotType || PLOT_TYPES.ROUTE;
  const id = options.id || `plot-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  return normalizePlotFeature({
    type: "Feature",
    geometry,
    properties: {
      ...(options.properties || {}),
      id,
      name: options.name || options.properties?.name || PLOT_LABELS[plotType] || "未命名标绘",
      featureRole: PLOT_ROLE,
      plotType,
      style: {
        ...(defaultPlotStyle(plotType)),
        ...(options.style || options.properties?.style || {}),
      },
      description: options.description || options.properties?.description || "",
      ...(options.controlPoints ? { controlPoints: options.controlPoints } : {}),
    },
  });
}

export function normalizePlotCollection(input) {
  const collection = normalizeFeatureCollection(input);
  return createFeatureCollection(
    collection.features
      .filter((feature) => feature?.geometry)
      .map((feature) => normalizePlotFeature(feature))
      .filter((feature) => feature?.geometry)
  );
}

export function normalizePlotFeature(feature) {
  const properties = feature.properties || {};
  const geometry = sanitizeGeometry(feature.geometry);
  const plotType = properties.plotType || guessPlotType(geometry);
  const id = properties.id || `plot-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  return {
    type: "Feature",
    geometry,
    properties: {
      ...properties,
      id,
      name: properties.name || PLOT_LABELS[plotType] || "未命名标绘",
      featureRole: PLOT_ROLE,
      plotType,
      style: {
        ...defaultPlotStyle(plotType),
        ...(properties.style || {}),
      },
    },
  };
}

export function defaultPlotStyle(plotType) {
  if (plotType === PLOT_TYPES.COMMAND_POST) {
    return {
      stroke: "#facc15",
      fill: "#facc15",
      label: "#fff7ed",
    };
  }

  if (plotType === PLOT_TYPES.ROUTE) {
    return {
      stroke: "#38bdf8",
      fill: "rgba(56, 189, 248, 0.18)",
      label: "#e0f2fe",
    };
  }

  if (plotType === PLOT_TYPES.ASSEMBLY_AREA) {
    return {
      stroke: "#2dd4bf",
      fill: "rgba(45, 212, 191, 0.24)",
      label: "#ccfbf1",
    };
  }

  if (plotType === PLOT_TYPES.DEFENSE_AREA) {
    return {
      stroke: "#60a5fa",
      fill: "rgba(96, 165, 250, 0.22)",
      label: "#dbeafe",
    };
  }

  return {
    stroke: "#f97316",
    fill: "rgba(249, 115, 22, 0.3)",
    label: "#ffedd5",
  };
}

export function createAttackArrowGeometry(controlPoints = []) {
  const points = normalizeCoordinates(controlPoints);
  if (points.length < 2) return null;

  const tail = points[0];
  const head = points[points.length - 1];
  const previous = findPreviousDistinctPoint(points, head) || tail;
  const direction = normalizeVector([head[0] - previous[0], head[1] - previous[1]]);
  const normal = [-direction[1], direction[0]];
  const length = Math.max(distance(tail, head), 0.0001);
  const bodyWidth = Math.min(length * 0.12, 0.035);
  const headLength = Math.min(length * 0.26, 0.08);
  const headWidth = bodyWidth * 2.8;
  const neck = [head[0] - direction[0] * headLength, head[1] - direction[1] * headLength];

  const leftBody = [];
  const rightBody = [];
  points.slice(0, -1).forEach((point, index) => {
    const ratio = points.length > 2 ? index / Math.max(1, points.length - 2) : 0;
    const width = bodyWidth * (0.75 + ratio * 0.35);
    leftBody.push([point[0] + normal[0] * width, point[1] + normal[1] * width]);
    rightBody.unshift([point[0] - normal[0] * width, point[1] - normal[1] * width]);
  });

  const leftNeck = [neck[0] + normal[0] * bodyWidth, neck[1] + normal[1] * bodyWidth];
  const leftHead = [neck[0] + normal[0] * headWidth, neck[1] + normal[1] * headWidth];
  const rightHead = [neck[0] - normal[0] * headWidth, neck[1] - normal[1] * headWidth];
  const rightNeck = [neck[0] - normal[0] * bodyWidth, neck[1] - normal[1] * bodyWidth];
  const ring = normalizeCoordinates([...leftBody, leftNeck, leftHead, head, rightHead, rightNeck, ...rightBody]);

  if (ring.length < 4) return null;
  if (!coordinatesEqual(ring[0], ring[ring.length - 1])) ring.push([...ring[0]]);
  return {
    type: "Polygon",
    coordinates: [ring],
  };
}

export function cloneFeature(feature) {
  return {
    type: "Feature",
    geometry: clone(feature.geometry),
    properties: clone(feature.properties || {}),
  };
}

export function getPlotCenter(feature) {
  const geometry = feature?.geometry;
  if (!geometry) return null;
  if (geometry.type === "Point") return geometry.coordinates;
  const coordinates = geometry.type === "LineString" ? geometry.coordinates : geometry.coordinates?.[0] || [];
  const usable = normalizeCoordinates(coordinates).filter((coordinate, index, list) => {
    if (index !== list.length - 1) return true;
    return !coordinatesEqual(coordinate, list[0]);
  });
  if (!usable.length) return null;
  const total = usable.reduce((sum, coordinate) => {
    sum[0] += coordinate[0];
    sum[1] += coordinate[1];
    return sum;
  }, [0, 0]);
  return [total[0] / usable.length, total[1] / usable.length];
}

export function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function sanitizeGeometry(geometry) {
  if (!geometry) return null;

  if (geometry.type === "Point") {
    const coordinate = normalizeCoordinate(geometry.coordinates);
    return coordinate ? { type: "Point", coordinates: coordinate } : null;
  }

  if (geometry.type === "LineString") {
    const coordinates = normalizeCoordinates(geometry.coordinates);
    return coordinates.length >= 2 ? { type: "LineString", coordinates } : null;
  }

  if (geometry.type === "Polygon") {
    const ring = normalizeCoordinates(geometry.coordinates?.[0] || []);
    if (ring.length < 3) return null;
    if (!coordinatesEqual(ring[0], ring[ring.length - 1])) ring.push([...ring[0]]);
    return ring.length >= 4 ? { type: "Polygon", coordinates: [ring] } : null;
  }

  return clone(geometry);
}

export function normalizeCoordinates(coordinates = []) {
  const result = [];
  coordinates.forEach((coordinate) => {
    const normalized = normalizeCoordinate(coordinate);
    if (!normalized) return;
    if (result.length && coordinatesEqual(result[result.length - 1], normalized)) return;
    result.push(normalized);
  });
  return result;
}

export function normalizeCoordinate(coordinate) {
  if (!Array.isArray(coordinate) || coordinate.length < 2) return null;
  const lng = Number(coordinate[0]);
  const lat = Number(coordinate[1]);
  if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;
  return [lng, lat];
}

export function flattenDegrees(coordinates = []) {
  return normalizeCoordinates(coordinates).flat();
}

export function coordinatesEqual(a, b, epsilon = 1e-12) {
  if (!a || !b) return false;
  return Math.abs(a[0] - b[0]) <= epsilon && Math.abs(a[1] - b[1]) <= epsilon;
}

function guessPlotType(geometry) {
  if (geometry?.type === "Point") return PLOT_TYPES.COMMAND_POST;
  if (geometry?.type === "LineString") return PLOT_TYPES.ROUTE;
  return PLOT_TYPES.ASSEMBLY_AREA;
}

function normalizeVector(vector) {
  const length = Math.hypot(vector[0], vector[1]) || 1;
  return [vector[0] / length, vector[1] / length];
}

function distance(a, b) {
  return Math.hypot(a[0] - b[0], a[1] - b[1]);
}

function findPreviousDistinctPoint(points, head) {
  for (let index = points.length - 2; index >= 0; index -= 1) {
    if (!coordinatesEqual(points[index], head)) return points[index];
  }
  return null;
}
