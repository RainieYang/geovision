import {
  PLOT_TYPES,
  cloneFeature,
  createAttackArrowGeometry,
  createPlotFeature,
  flattenDegrees,
  getPlotCenter,
  normalizeCoordinate,
  normalizeCoordinates,
  normalizePlotCollection,
  sanitizeGeometry,
} from "./plotUtils";

export default class CesiumPlotAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.handler = null;
    this.mode = null;
    this.plotType = null;
    this.points = [];
    this.tempEntities = [];
    this.entities = new Map();
    this.features = [];
    this.selectedPlotId = null;
    this.keydownHandler = null;
    this.onCreate = null;
    this.onSelect = null;
    this.onDelete = null;
    this.onUpdate = null;
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setSelectHandler(handler) {
    this.onSelect = handler;
  }

  setDeleteHandler(handler) {
    this.onDelete = handler;
  }

  setUpdateHandler(handler) {
    this.onUpdate = handler;
  }

  destroy() {
    this.stop();
    this.clear();
  }

  stop() {
    if (this.handler) {
      this.handler.destroy();
      this.handler = null;
    }
    this.mode = null;
    this.plotType = null;
    this.points = [];
    this.clearTempEntities();
    this.unbindKeyboardDelete();
    if (this.viewer?.scene?.canvas) {
      this.viewer.scene.canvas.style.cursor = "";
      this.viewer.scene.canvas.oncontextmenu = null;
    }
  }

  drawCommandPost(options = {}) {
    return this.start("Point", PLOT_TYPES.COMMAND_POST, options);
  }

  drawRoute(options = {}) {
    return this.start("LineString", PLOT_TYPES.ROUTE, options);
  }

  drawAssemblyArea(options = {}) {
    return this.start("Polygon", PLOT_TYPES.ASSEMBLY_AREA, options);
  }

  drawDefenseArea(options = {}) {
    return this.start("Polygon", PLOT_TYPES.DEFENSE_AREA, options);
  }

  drawAttackArrow(options = {}) {
    return this.start("LineString", PLOT_TYPES.ATTACK_ARROW, options);
  }

  start(mode, plotType, options = {}) {
    this.stop();
    this.mode = mode;
    this.plotType = plotType;
    this.points = [];
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "crosshair";
    this.viewer.scene.canvas.oncontextmenu = (event) => event.preventDefault();
    this.viewer.screenSpaceEventHandler.removeInputAction(this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);

    this.handler.setInputAction((movement) => {
      const point = this.getLngLatFromScreen(movement.position);
      if (!point) return;

      if (mode === "Point") {
        this.finish(createPlotFeature({ type: "Point", coordinates: point }, { ...options, plotType }));
        return;
      }

      this.points.push(point);
      this.renderTempPoint(point);
      this.renderTempShape(mode, plotType);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_CLICK);

    this.handler.setInputAction(() => this.cancelSketch(), this.CesiumLib.ScreenSpaceEventType.RIGHT_CLICK);
    this.handler.setInputAction(() => this.finishSketch(options), this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
    return this;
  }

  finishSketch(options = {}) {
    const points = normalizeCoordinates(this.points);

    if (this.mode === "LineString" && points.length >= 2) {
      const geometry =
        this.plotType === PLOT_TYPES.ATTACK_ARROW
          ? createAttackArrowGeometry(points)
          : { type: "LineString", coordinates: [...points] };

      if (geometry) {
        this.finish(createPlotFeature(geometry, {
          ...options,
          plotType: this.plotType,
          controlPoints: this.plotType === PLOT_TYPES.ATTACK_ARROW ? [...points] : undefined,
        }));
      }
    }

    if (this.mode === "Polygon" && points.length >= 3) {
      this.finish(createPlotFeature(
        { type: "Polygon", coordinates: [[...points, points[0]]] },
        { ...options, plotType: this.plotType }
      ));
    }
  }

  finish(feature) {
    this.features.push(feature);
    this.clearTempEntities();
    this.renderFeature(feature);
    this.onCreate?.(feature);
    this.points = [];
    this.viewer.scene.requestRender?.();
    return feature;
  }

  enableSelect() {
    this.stop();
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "pointer";
    this.bindKeyboardDelete();

    this.handler.setInputAction((movement) => {
      const picked = this.viewer.scene.pick(movement.position);
      const id = this.getPickedPlotId(picked);
      if (id) this.selectPlot(id);
      else this.unselectPlot();
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_CLICK);
    return this;
  }

  selectPlot(id) {
    const feature = this.findFeature(id);
    if (!feature) {
      this.unselectPlot();
      return null;
    }
    this.selectedPlotId = id;
    this.renderAll();
    this.onSelect?.(feature);
    return feature;
  }

  unselectPlot() {
    this.selectedPlotId = null;
    this.renderAll();
    this.onSelect?.(null);
  }

  getSelectedPlot() {
    return this.selectedPlotId ? this.findFeature(this.selectedPlotId) : null;
  }

  removePlot(id) {
    const index = this.features.findIndex((feature) => feature.properties?.id === id);
    if (index < 0) return null;
    const [removed] = this.features.splice(index, 1);
    this.removeFeatureEntities(id);
    if (this.selectedPlotId === id) this.selectedPlotId = null;
    this.viewer.scene.requestRender?.();
    return removed;
  }

  updatePlotProperties(id, properties = {}) {
    const feature = this.findFeature(id);
    if (!feature) return null;
    feature.properties = {
      ...(feature.properties || {}),
      ...properties,
      id,
      featureRole: "plot",
      plotType: feature.properties?.plotType,
    };
    this.renderAll();
    return feature;
  }

  listPlots() {
    return this.features.map((feature) => cloneFeature(feature));
  }

  clear() {
    this.stop();
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
    this.features = [];
    this.selectedPlotId = null;
    this.viewer.scene.requestRender?.();
  }

  exportGeoJSON() {
    return {
      type: "FeatureCollection",
      features: this.listPlots(),
    };
  }

  importGeoJSON(geojson) {
    const collection = normalizePlotCollection(geojson);
    this.clear();
    this.features = collection.features;
    this.renderAll();
    return this.exportGeoJSON();
  }

  findFeature(id) {
    return this.features.find((feature) => feature.properties?.id === id) || null;
  }

  renderAll() {
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
    this.features.forEach((feature) => this.renderFeature(feature));
    this.viewer.scene.requestRender?.();
  }

  renderFeature(feature) {
    const geometry = sanitizeGeometry(feature.geometry);
    if (!geometry) return null;

    const id = feature.properties?.id;
    const plotType = feature.properties?.plotType;
    const style = feature.properties?.style || {};
    const isSelected = id === this.selectedPlotId;
    const stroke = this.toColor(isSelected ? "#f97316" : style.stroke || "#38bdf8");
    const fill = this.toColor(isSelected ? "rgba(249, 115, 22, 0.36)" : style.fill || "rgba(56, 189, 248, 0.24)");
    let entity = null;

    if (geometry.type === "Point") {
      entity = this.viewer.entities.add({
        id,
        position: this.CesiumLib.Cartesian3.fromDegrees(...geometry.coordinates),
        point: {
          pixelSize: isSelected ? 16 : 13,
          color: this.toColor(style.fill || "#facc15"),
          outlineColor: this.CesiumLib.Color.WHITE,
          outlineWidth: 3,
          heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
          disableDepthTestDistance: Number.POSITIVE_INFINITY,
        },
        properties: { plotFeature: feature, plotFeatureId: id },
      });
    }

    if (geometry.type === "LineString") {
      const degrees = flattenDegrees(geometry.coordinates);
      if (degrees.length < 4) return entity;
      entity = this.viewer.entities.add({
        id,
        polyline: {
          positions: this.CesiumLib.Cartesian3.fromDegreesArray(degrees),
          width: isSelected ? 5 : 4,
          material: stroke,
          clampToGround: true,
        },
        properties: { plotFeature: feature, plotFeatureId: id },
      });
    }

    if (geometry.type === "Polygon") {
      const ring = geometry.coordinates?.[0] || [];
      const degrees = flattenDegrees(ring);
      if (degrees.length < 8) return entity;
      entity = this.viewer.entities.add({
        id,
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(degrees),
          material: fill,
          outline: true,
          outlineColor: stroke,
          heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        },
        properties: { plotFeature: feature, plotFeatureId: id },
      });
    }

    if (entity) {
      this.entities.set(id, entity);
      this.renderLabel(feature, id, plotType);
    }
    return entity;
  }

  renderLabel(feature, id, plotType) {
    const center = getPlotCenter(feature);
    if (!center) return null;
    const style = feature.properties?.style || {};
    const label = this.viewer.entities.add({
      id: `${id}-label`,
      position: this.CesiumLib.Cartesian3.fromDegrees(center[0], center[1]),
      properties: { plotFeature: feature, plotFeatureId: id },
      label: {
        text: feature.properties?.name || "",
        font: "600 14px sans-serif",
        fillColor: this.toColor(style.label || "#ffffff"),
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 4,
        style: this.CesiumLib.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new this.CesiumLib.Cartesian2(0, plotType === PLOT_TYPES.COMMAND_POST ? -24 : -14),
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });
    this.entities.set(`${id}-label`, label);
    return label;
  }

  renderTempPoint(coordinate) {
    const point = normalizeCoordinate(coordinate);
    if (!point) return;

    const entity = this.viewer.entities.add({
      position: this.CesiumLib.Cartesian3.fromDegrees(point[0], point[1]),
      point: {
        pixelSize: 7,
        color: this.CesiumLib.Color.YELLOW,
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 2,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });
    this.tempEntities.push(entity);
  }

  renderTempShape(mode, plotType) {
    this.tempEntities
      .filter((entity) => entity.__plotTempShape)
      .forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = this.tempEntities.filter((entity) => !entity.__plotTempShape);

    let entity = null;
    const points = normalizeCoordinates(this.points);

    if (mode === "LineString" && points.length >= 2) {
      const geometry = plotType === PLOT_TYPES.ATTACK_ARROW
        ? createAttackArrowGeometry(points)
        : { type: "LineString", coordinates: points };
      if (geometry?.type === "Polygon") {
        const degrees = flattenDegrees(geometry.coordinates[0]);
        if (degrees.length < 8) return;
        entity = this.viewer.entities.add({
          polygon: {
            hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(degrees),
            material: this.CesiumLib.Color.YELLOW.withAlpha(0.26),
            outline: true,
            outlineColor: this.CesiumLib.Color.YELLOW,
          },
        });
      } else {
        const degrees = flattenDegrees(points);
        if (degrees.length < 4) return;
        entity = this.viewer.entities.add({
          polyline: {
            positions: this.CesiumLib.Cartesian3.fromDegreesArray(degrees),
            width: 2,
            material: this.CesiumLib.Color.YELLOW,
            clampToGround: true,
          },
        });
      }
    }

    if (mode === "Polygon" && points.length >= 3) {
      const ring = [...points, points[0]];
      const degrees = flattenDegrees(ring);
      if (degrees.length < 8) return;
      entity = this.viewer.entities.add({
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(degrees),
          material: this.CesiumLib.Color.YELLOW.withAlpha(0.22),
          outline: true,
          outlineColor: this.CesiumLib.Color.YELLOW,
        },
      });
    }

    if (entity) {
      entity.__plotTempShape = true;
      this.tempEntities.push(entity);
      this.viewer.scene.requestRender?.();
    }
  }

  cancelSketch() {
    this.points = [];
    this.clearTempEntities();
    this.viewer.scene.requestRender?.();
  }

  clearTempEntities() {
    this.tempEntities.forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = [];
  }

  removeFeatureEntities(id) {
    Array.from(this.entities.keys())
      .filter((entityId) => entityId === id || entityId.startsWith(`${id}-`))
      .forEach((entityId) => {
        const entity = this.entities.get(entityId);
        if (entity) this.viewer.entities.remove(entity);
        this.entities.delete(entityId);
      });
  }

  getLngLatFromScreen(screenPosition) {
    if (!screenPosition) return null;

    const groundPoint = this.engine.pickGroundLngLat?.(screenPosition);
    if (groundPoint) return groundPoint;

    let cartesian = null;
    const ray = this.viewer.camera.getPickRay(screenPosition);
    cartesian = ray ? this.viewer.scene.globe.pick(ray, this.viewer.scene) : null;
    if (!cartesian && this.viewer.scene.pickPositionSupported) {
      try {
        cartesian = this.viewer.scene.pickPosition(screenPosition);
      } catch (error) {
        cartesian = null;
      }
    }
    if (!cartesian) {
      cartesian = this.viewer.camera.pickEllipsoid(screenPosition, this.viewer.scene.globe.ellipsoid);
    }
    if (!cartesian) return null;
    const cartographic = this.CesiumLib.Cartographic.fromCartesian(cartesian);
    return [
      this.CesiumLib.Math.toDegrees(cartographic.longitude),
      this.CesiumLib.Math.toDegrees(cartographic.latitude),
    ];
  }

  getPickedPlotId(picked) {
    if (!this.CesiumLib.defined(picked) || !picked.id) return null;
    const propertyBag = picked.id.properties;
    return propertyBag?.plotFeatureId?.getValue?.(this.viewer.clock.currentTime) || null;
  }

  bindKeyboardDelete() {
    this.unbindKeyboardDelete();
    this.keydownHandler = (event) => {
      if (!this.selectedPlotId) return;
      if (event.key !== "Delete" && event.key !== "Backspace") return;
      event.preventDefault();
      const removed = this.removePlot(this.selectedPlotId);
      if (removed) this.onDelete?.(removed);
    };
    window.addEventListener("keydown", this.keydownHandler);
  }

  unbindKeyboardDelete() {
    if (!this.keydownHandler) return;
    window.removeEventListener("keydown", this.keydownHandler);
    this.keydownHandler = null;
  }

  toColor(value) {
    if (value?.startsWith?.("rgba")) return this.CesiumLib.Color.fromCssColorString(value);
    return this.CesiumLib.Color.fromCssColorString(value || "#38bdf8");
  }
}
