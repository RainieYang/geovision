import CesiumPlotAdapter from "./CesiumPlotAdapter";
import OpenLayersPlotAdapter from "./OpenLayersPlotAdapter";
import { createFeatureCollection } from "../draw/geojson";
import { normalizePlotCollection } from "./plotUtils";

export default class PlotManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = options;
    this.selectedPlotId = options.selectedPlotId || mapEngine.selectedPlotId || null;
    this.adapter = this.createAdapter(engine, options);
    this.adapter.setCreateHandler?.((feature) => this.handleCreate(feature));
    this.adapter.setSelectHandler?.((feature) => this.handleSelect(feature));
    this.adapter.setDeleteHandler?.((feature) => this.handleDelete(feature));
    this.adapter.setUpdateHandler?.((feature) => this.handleUpdate(feature));
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumPlotAdapter(engine, options)
      : new OpenLayersPlotAdapter(engine, options);
  }

  destroy() {
    this.adapter?.destroy();
    this.adapter = null;
  }

  drawCommandPost(options) {
    this.prepareDraw();
    return this.adapter?.drawCommandPost(options);
  }

  drawRoute(options) {
    this.prepareDraw();
    return this.adapter?.drawRoute(options);
  }

  drawAssemblyArea(options) {
    this.prepareDraw();
    return this.adapter?.drawAssemblyArea(options);
  }

  drawDefenseArea(options) {
    this.prepareDraw();
    return this.adapter?.drawDefenseArea(options);
  }

  drawAttackArrow(options) {
    this.prepareDraw();
    return this.adapter?.drawAttackArrow(options);
  }

  prepareDraw() {
    this.mapEngine.drawManager?.stop?.();
    this.mapEngine.measureManager?.stop?.();
  }

  enableSelect() {
    this.prepareDraw();
    return this.adapter?.enableSelect();
  }

  stop() {
    return this.adapter?.stop?.();
  }

  selectPlot(id) {
    const feature = this.adapter?.selectPlot(id);
    this.handleSelect(feature);
    return feature;
  }

  unselectPlot() {
    this.adapter?.unselectPlot();
    this.selectedPlotId = null;
    this.mapEngine.selectedPlotId = null;
    this.mapEngine.emitLocal?.("plot:unselect", null);
  }

  getSelectedPlot() {
    return this.adapter?.getSelectedPlot?.() || null;
  }

  removePlot(id) {
    const removed = this.adapter?.removePlot(id);
    if (!removed) return null;
    if (this.selectedPlotId === id) {
      this.selectedPlotId = null;
      this.mapEngine.selectedPlotId = null;
    }
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:delete", removed);
    return removed;
  }

  removeSelectedPlot() {
    if (!this.selectedPlotId) return null;
    return this.removePlot(this.selectedPlotId);
  }

  updatePlotProperties(id, properties = {}) {
    const feature = this.adapter?.updatePlotProperties?.(id, properties);
    if (!feature) return null;
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:update", feature);
    return feature;
  }

  updateSelectedPlotProperties(properties = {}) {
    if (!this.selectedPlotId) return null;
    return this.updatePlotProperties(this.selectedPlotId, properties);
  }

  listPlots() {
    return this.adapter?.listPlots?.() || [];
  }

  clear() {
    this.adapter?.clear();
    this.selectedPlotId = null;
    this.mapEngine.selectedPlotId = null;
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:clear", createFeatureCollection());
  }

  exportGeoJSON() {
    return this.adapter?.exportGeoJSON() || createFeatureCollection();
  }

  importGeoJSON(geojson) {
    const result = this.adapter?.importGeoJSON(normalizePlotCollection(geojson));
    if (this.selectedPlotId) this.adapter?.selectPlot?.(this.selectedPlotId);
    return result;
  }

  handleCreate(feature) {
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:create", feature);
  }

  handleSelect(feature) {
    this.selectedPlotId = feature?.properties?.id || null;
    this.mapEngine.selectedPlotId = this.selectedPlotId;
    this.mapEngine.emitLocal?.(feature ? "plot:select" : "plot:unselect", feature || null);
  }

  handleDelete(feature) {
    if (!feature) return;
    if (this.selectedPlotId === feature.properties?.id) {
      this.selectedPlotId = null;
      this.mapEngine.selectedPlotId = null;
    }
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:delete", feature);
  }

  handleUpdate(feature) {
    this.syncStore();
    this.mapEngine.emitLocal?.("plot:update", feature);
  }

  syncStore() {
    this.mapEngine.plotStore = this.exportGeoJSON();
  }
}
