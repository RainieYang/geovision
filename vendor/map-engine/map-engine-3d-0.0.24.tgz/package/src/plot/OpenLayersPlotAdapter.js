import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import Polygon from "ol/geom/Polygon";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import Draw from "ol/interaction/Draw";
import PointerInteraction from "ol/interaction/Pointer";
import GeoJSON from "ol/format/GeoJSON";
import { Circle as CircleStyle, Fill, RegularShape, Stroke, Style, Text } from "ol/style";
import { fromLonLat, toLonLat } from "ol/proj";
import {
  PLOT_TYPES,
  cloneFeature,
  createAttackArrowGeometry,
  createPlotFeature,
  getPlotCenter,
  normalizePlotCollection,
} from "./plotUtils";

export default class OpenLayersPlotAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new VectorLayer({
      source: this.source,
      zIndex: options.zIndex ?? 1300,
      style: (feature) => this.createStyle(feature),
    });
    this.geojson = new GeoJSON();
    this.features = [];
    this.draw = null;
    this.selectInteraction = null;
    this.keydownHandler = null;
    this.contextMenuHandler = null;
    this.selectedPlotId = null;
    this.onCreate = null;
    this.onSelect = null;
    this.onDelete = null;
    this.onUpdate = null;
    this.map.addLayer(this.layer);
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setSelectHandler(handler) {
    this.onSelect = handler;
  }

  setDeleteHandler(handler) {
    this.onDelete = handler;
  }

  setUpdateHandler(handler) {
    this.onUpdate = handler;
  }

  destroy() {
    this.stop();
    this.disableSelect();
    this.map?.removeLayer(this.layer);
    this.source.clear();
    this.features = [];
  }

  stop() {
    if (this.draw) {
      this.map.removeInteraction(this.draw);
      this.draw = null;
    }

    if (this.contextMenuHandler) {
      this.map.getViewport().removeEventListener("contextmenu", this.contextMenuHandler);
      this.contextMenuHandler = null;
    }
  }

  drawCommandPost(options = {}) {
    return this.startDraw("Point", PLOT_TYPES.COMMAND_POST, options);
  }

  drawRoute(options = {}) {
    return this.startDraw("LineString", PLOT_TYPES.ROUTE, options);
  }

  drawAssemblyArea(options = {}) {
    return this.startDraw("Polygon", PLOT_TYPES.ASSEMBLY_AREA, options);
  }

  drawDefenseArea(options = {}) {
    return this.startDraw("Polygon", PLOT_TYPES.DEFENSE_AREA, options);
  }

  drawAttackArrow(options = {}) {
    return this.startDraw("LineString", PLOT_TYPES.ATTACK_ARROW, options);
  }

  startDraw(type, plotType, options = {}) {
    this.stop();
    this.disableSelect();

    this.draw = new Draw({
      source: this.source,
      type,
    });

    this.draw.on("drawend", (event) => {
      const feature = this.createPlotFromOlFeature(event.feature, plotType, options);
      if (!feature) return;
      this.features.push(feature);
      this.onCreate?.(feature);
      window.setTimeout(() => this.renderAll(), 0);
    });

    this.map.addInteraction(this.draw);
    this.bindContextCancel();
    return this;
  }

  createPlotFromOlFeature(olFeature, plotType, options = {}) {
    const exported = this.geojson.writeFeatureObject(olFeature, {
      featureProjection: "EPSG:3857",
      dataProjection: "EPSG:4326",
    });
    let geometry = exported.geometry;
    const controlPoints = geometry.type === "LineString" ? geometry.coordinates : null;

    if (plotType === PLOT_TYPES.ATTACK_ARROW) {
      geometry = createAttackArrowGeometry(controlPoints);
      if (!geometry) return null;
    }

    return createPlotFeature(geometry, {
      ...options,
      plotType,
      controlPoints: plotType === PLOT_TYPES.ATTACK_ARROW ? controlPoints : undefined,
    });
  }

  bindContextCancel() {
    this.contextMenuHandler = (event) => {
      event.preventDefault();
      this.draw?.abortDrawing?.();
      this.renderAll();
    };
    this.map.getViewport().addEventListener("contextmenu", this.contextMenuHandler);
  }

  enableSelect() {
    this.stop();
    this.disableSelect();

    this.selectInteraction = new PointerInteraction({
      handleDownEvent: (event) => {
        const feature = this.getPlotFeatureAtPixel(event.pixel);
        if (feature?.properties?.id) this.selectPlot(feature.properties.id);
        else this.unselectPlot();
        return false;
      },
    });

    this.keydownHandler = (event) => {
      if (!this.selectedPlotId) return;
      if (event.key !== "Delete" && event.key !== "Backspace") return;
      event.preventDefault();
      const removed = this.removePlot(this.selectedPlotId);
      if (removed) this.onDelete?.(removed);
    };

    this.map.addInteraction(this.selectInteraction);
    document.addEventListener("keydown", this.keydownHandler, true);
    return this;
  }

  disableSelect() {
    if (this.selectInteraction) {
      this.map.removeInteraction(this.selectInteraction);
      this.selectInteraction = null;
    }

    if (this.keydownHandler) {
      document.removeEventListener("keydown", this.keydownHandler, true);
      this.keydownHandler = null;
    }
  }

  selectPlot(id) {
    const feature = this.findFeature(id);
    if (!feature) {
      this.unselectPlot();
      return null;
    }
    this.selectedPlotId = id;
    this.renderAll();
    this.onSelect?.(feature);
    return feature;
  }

  unselectPlot() {
    this.selectedPlotId = null;
    this.renderAll();
    this.onSelect?.(null);
  }

  getSelectedPlot() {
    return this.selectedPlotId ? this.findFeature(this.selectedPlotId) : null;
  }

  removePlot(id) {
    const index = this.features.findIndex((feature) => feature.properties?.id === id);
    if (index < 0) return null;
    const [removed] = this.features.splice(index, 1);
    if (this.selectedPlotId === id) this.selectedPlotId = null;
    this.renderAll();
    return removed;
  }

  updatePlotProperties(id, properties = {}) {
    const feature = this.findFeature(id);
    if (!feature) return null;
    feature.properties = {
      ...(feature.properties || {}),
      ...properties,
      id,
      featureRole: "plot",
      plotType: feature.properties?.plotType,
    };
    this.renderAll();
    return feature;
  }

  listPlots() {
    return this.features.map((feature) => cloneFeature(feature));
  }

  clear() {
    this.stop();
    this.disableSelect();
    this.source.clear();
    this.features = [];
    this.selectedPlotId = null;
  }

  exportGeoJSON() {
    return {
      type: "FeatureCollection",
      features: this.listPlots(),
    };
  }

  importGeoJSON(geojson) {
    const collection = normalizePlotCollection(geojson);
    this.clear();
    this.features = collection.features;
    this.renderAll();
    return this.exportGeoJSON();
  }

  findFeature(id) {
    return this.features.find((feature) => feature.properties?.id === id) || null;
  }

  renderAll() {
    this.source.clear();
    this.features.forEach((feature) => this.source.addFeature(this.createOlFeature(feature)));
  }

  createOlFeature(feature) {
    let olFeature = null;

    if (feature.geometry.type === "Point") {
      olFeature = new Feature({ geometry: new Point(fromLonLat(feature.geometry.coordinates)) });
    } else if (feature.geometry.type === "Polygon") {
      olFeature = new Feature({
        geometry: new Polygon(feature.geometry.coordinates.map((ring) => ring.map((coord) => fromLonLat(coord)))),
      });
    } else {
      olFeature = this.geojson.readFeature(feature, {
        featureProjection: "EPSG:3857",
        dataProjection: "EPSG:4326",
      });
    }

    olFeature.setProperties({ plotFeature: feature, ...feature.properties });
    return olFeature;
  }

  getPlotFeatureAtPixel(pixel) {
    const candidates = this.map.getFeaturesAtPixel(pixel, {
      hitTolerance: 18,
      layerFilter: (layer) => layer === this.layer,
    }) || [];
    return candidates.find((candidate) => candidate.get("plotFeature"))?.get("plotFeature") || null;
  }

  createStyle(feature) {
    const plotFeature = feature?.get("plotFeature");
    const plotType = plotFeature?.properties?.plotType;
    const style = plotFeature?.properties?.style || {};
    const isSelected = plotFeature?.properties?.id === this.selectedPlotId;
    const strokeColor = isSelected ? "#f97316" : style.stroke || "#38bdf8";
    const fillColor = isSelected ? "rgba(249, 115, 22, 0.34)" : style.fill || "rgba(56, 189, 248, 0.2)";
    const styles = [];

    if (plotType === PLOT_TYPES.COMMAND_POST) {
      styles.push(new Style({
        image: new RegularShape({
          points: 4,
          radius: isSelected ? 12 : 10,
          angle: Math.PI / 4,
          fill: new Fill({ color: style.fill || "#facc15" }),
          stroke: new Stroke({ color: "#ffffff", width: 2 }),
        }),
      }));
    } else {
      styles.push(new Style({
        image: new CircleStyle({
          radius: isSelected ? 7 : 5,
          fill: new Fill({ color: strokeColor }),
          stroke: new Stroke({ color: "#ffffff", width: 2 }),
        }),
        fill: new Fill({ color: fillColor }),
        stroke: new Stroke({
          color: strokeColor,
          width: isSelected ? 4 : 3,
          lineDash: plotType === PLOT_TYPES.ROUTE ? [10, 8] : undefined,
        }),
      }));
    }

    const center = getPlotCenter(plotFeature);
    if (center) {
      styles.push(new Style({
        geometry: new Point(fromLonLat(center)),
        text: new Text({
          text: plotFeature.properties?.name || "",
          font: "600 13px Arial, Microsoft YaHei, sans-serif",
          fill: new Fill({ color: style.label || "#ffffff" }),
          stroke: new Stroke({ color: "rgba(15, 23, 42, 0.92)", width: 4 }),
          offsetY: plotType === PLOT_TYPES.COMMAND_POST ? -22 : -12,
        }),
      }));
    }

    return styles;
  }
}
