const EARTH_RADIUS = 6378137;
export const RADAR_TARGET_STATUSES = ["active", "focus", "warning", "danger", "lost", "handled"];
export const DEFAULT_TARGET_TRAIL_LIMIT = 20;

export function normalizeRadar(input = {}) {
  if (!input?.id) {
    console.warn("RadarManager: radar.id is required");
    return null;
  }

  const position = normalizePosition(input.position || input.lnglat || input.coordinate);
  const radius = Number(input.radius);
  if (!position || !Number.isFinite(radius) || radius <= 0) {
    console.warn("RadarManager: radar.position and positive radar.radius are required");
    return null;
  }

  return {
    id: String(input.id),
    name: input.name || String(input.id),
    position,
    radius,
    scanAngle: normalizeAngle(input.scanAngle ?? 0),
    scanWidth: clamp(Number(input.scanWidth ?? 60), 1, 180),
    scanSpeed: Math.max(1, Number(input.scanSpeed ?? 45)),
    enabled: input.enabled !== false,
    scanning: Boolean(input.scanning),
    trackedTargetId: input.trackedTargetId || null,
    style: {
      stroke: "#22d3ee",
      fill: "rgba(34, 211, 238, 0.14)",
      scanFill: "rgba(34, 211, 238, 0.32)",
      target: "#f97316",
      ...(input.style || {}),
    },
    targets: normalizeTargets(input.targets || []),
    data: { ...(input.data || {}) },
  };
}

export function normalizeRadarPatch(existing, patch = {}) {
  const merged = {
    ...existing,
    ...patch,
    style: {
      ...(existing?.style || {}),
      ...(patch.style || {}),
    },
    data: {
      ...(existing?.data || {}),
      ...(patch.data || {}),
    },
    targets: patch.targets ?? existing?.targets ?? [],
  };
  return normalizeRadar(merged);
}

export function normalizeTarget(input = {}) {
  if (!input?.id) {
    console.warn("RadarManager: target.id is required");
    return null;
  }

  const position = normalizePosition(input.position || input.lnglat || input.coordinate);
  if (!position) {
    console.warn("RadarManager: target.position is required");
    return null;
  }

  return {
    id: String(input.id),
    name: input.name || String(input.id),
    position,
    heading: normalizeAngle(input.heading ?? 0),
    speed: Number(input.speed ?? 0),
    status: normalizeTargetStatus(input.status),
    trail: normalizeTrail(input.trail),
    trailEnabled: input.trailEnabled !== false,
    trailLimit: Math.max(1, Number(input.trailLimit ?? DEFAULT_TARGET_TRAIL_LIMIT)),
    markerId: input.markerId || null,
    data: { ...(input.data || {}) },
  };
}

export function normalizeTargets(targets = []) {
  if (!Array.isArray(targets)) return [];
  return targets.map((target) => normalizeTarget(target)).filter(Boolean);
}

export function normalizePosition(position) {
  if (!Array.isArray(position) || position.length < 2) return null;
  const lng = Number(position[0]);
  const lat = Number(position[1]);
  if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;
  return [lng, lat];
}

export function normalizeTrail(trail = []) {
  if (!Array.isArray(trail)) return [];
  return trail.map((position) => normalizePosition(position)).filter(Boolean);
}

export function normalizeTargetStatus(status) {
  return RADAR_TARGET_STATUSES.includes(status) ? status : "active";
}

export function samePosition(a, b) {
  return (
    Array.isArray(a) &&
    Array.isArray(b) &&
    a.length >= 2 &&
    b.length >= 2 &&
    Number(a[0]) === Number(b[0]) &&
    Number(a[1]) === Number(b[1])
  );
}

export function normalizeAngle(angle) {
  const value = Number(angle);
  if (!Number.isFinite(value)) return 0;
  return ((value % 360) + 360) % 360;
}

export function createCircleRing(center, radius, steps = 96) {
  const ring = [];
  for (let index = 0; index <= steps; index += 1) {
    ring.push(destinationPoint(center, radius, (index / steps) * 360));
  }
  return ring;
}

export function createSectorRing(center, radius, angle, width, steps = 36) {
  const start = normalizeAngle(angle - width / 2);
  const points = [center];

  for (let index = 0; index <= steps; index += 1) {
    points.push(destinationPoint(center, radius, start + (width * index) / steps));
  }

  points.push(center);
  return points;
}

export function createScanLine(center, radius, angle) {
  return [center, destinationPoint(center, radius, angle)];
}

export function cloneRadar(radar) {
  return {
    ...radar,
    position: [...radar.position],
    style: { ...(radar.style || {}) },
    data: { ...(radar.data || {}) },
    targets: (radar.targets || []).map((target) => ({
      ...target,
      position: [...target.position],
      trail: (target.trail || []).map((position) => [...position]),
      data: { ...(target.data || {}) },
    })),
  };
}

export function exportRadarCollection(radars = []) {
  return {
    type: "RadarCollection",
    radars: radars.map((radar) => cloneRadar(radar)),
  };
}

export function importRadarCollection(input) {
  const radars = Array.isArray(input) ? input : input?.radars;
  return (radars || []).map((radar) => normalizeRadar(radar)).filter(Boolean);
}

export function findRadarTarget(radar, targetId) {
  return radar?.targets?.find((target) => target.id === targetId) || null;
}

export function clamp(value, min, max) {
  if (!Number.isFinite(value)) return min;
  return Math.max(min, Math.min(max, value));
}

function destinationPoint(center, distance, bearingDegrees) {
  const bearing = (bearingDegrees * Math.PI) / 180;
  const lat1 = (center[1] * Math.PI) / 180;
  const lng1 = (center[0] * Math.PI) / 180;
  const angularDistance = distance / EARTH_RADIUS;

  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(angularDistance) +
      Math.cos(lat1) * Math.sin(angularDistance) * Math.cos(bearing)
  );
  const lng2 =
    lng1 +
    Math.atan2(
      Math.sin(bearing) * Math.sin(angularDistance) * Math.cos(lat1),
      Math.cos(angularDistance) - Math.sin(lat1) * Math.sin(lat2)
    );

  return [(lng2 * 180) / Math.PI, (lat2 * 180) / Math.PI];
}
