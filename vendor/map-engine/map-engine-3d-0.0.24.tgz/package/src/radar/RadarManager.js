import CesiumRadarAdapter from "./CesiumRadarAdapter";
import OpenLayersRadarAdapter from "./OpenLayersRadarAdapter";
import {
  cloneRadar,
  exportRadarCollection,
  findRadarTarget,
  importRadarCollection,
  normalizeAngle,
  normalizeRadar,
  normalizeRadarPatch,
  normalizeTarget,
  normalizeTargets,
  samePosition,
} from "./radarUtils";

export default class RadarManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = options;
    this.radars = new Map();
    this.adapter = this.createAdapter(engine, options);
    this.animationFrame = null;
    this.lastTickTime = null;
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumRadarAdapter(engine, options)
      : new OpenLayersRadarAdapter(engine, options);
  }

  destroy() {
    this.stopAnimationLoop();
    this.adapter?.destroy();
    this.adapter = null;
  }

  addRadar(radar) {
    const normalized = normalizeRadar(radar);
    if (!normalized) return null;
    this.radars.set(normalized.id, normalized);
    this.syncLinkedMarkers(normalized);
    this.render();
    this.emit("radar:create", cloneRadar(normalized));
    if (normalized.scanning) this.ensureAnimationLoop();
    return cloneRadar(normalized);
  }

  addRadars(radars = []) {
    if (!Array.isArray(radars)) return [];
    return radars.map((radar) => this.addRadar(radar)).filter(Boolean);
  }

  removeRadar(id) {
    const radar = this.radars.get(id);
    if (!radar) return null;
    this.radars.delete(id);
    this.render();
    this.emit("radar:delete", cloneRadar(radar));
    this.stopAnimationLoopIfIdle();
    return cloneRadar(radar);
  }

  clearRadars() {
    this.radars.clear();
    this.stopAnimationLoop();
    this.render();
    this.emit("radar:clear", this.exportRadars());
  }

  updateRadar(id, patch = {}) {
    const existing = this.radars.get(id);
    if (!existing) return null;
    const updated = normalizeRadarPatch(existing, { ...patch, id });
    if (!updated) return null;
    this.radars.set(id, updated);
    this.syncLinkedMarkers(updated);
    this.render();
    this.emit("radar:update", cloneRadar(updated));
    if (updated.scanning) this.ensureAnimationLoop();
    else this.stopAnimationLoopIfIdle();
    return cloneRadar(updated);
  }

  getRadar(id) {
    const radar = this.radars.get(id);
    return radar ? cloneRadar(radar) : null;
  }

  listRadars() {
    return Array.from(this.radars.values()).map((radar) => cloneRadar(radar));
  }

  startRadarScan(id) {
    const radar = this.radars.get(id);
    if (!radar) return null;
    radar.scanning = true;
    radar.enabled = true;
    this.render();
    this.emit("radar:scan-start", cloneRadar(radar));
    this.ensureAnimationLoop();
    return cloneRadar(radar);
  }

  stopRadarScan(id) {
    const radar = this.radars.get(id);
    if (!radar) return null;
    radar.scanning = false;
    this.render();
    this.emit("radar:scan-stop", cloneRadar(radar));
    this.stopAnimationLoopIfIdle();
    return cloneRadar(radar);
  }

  setRadarScanAngle(id, angle) {
    return this.updateRadar(id, { scanAngle: normalizeAngle(angle) });
  }

  setRadarTargets(radarId, targets = []) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    radar.targets = normalizeTargets(targets).map((target) =>
      this.mergeTargetTrail(findRadarTarget(radar, target.id), target)
    );
    if (radar.trackedTargetId && !findRadarTarget(radar, radar.trackedTargetId)) {
      radar.trackedTargetId = null;
    }
    this.syncLinkedMarkers(radar);
    this.render();
    this.emit("radar:target-update", cloneRadar(radar));
    return cloneRadar(radar);
  }

  addRadarTarget(radarId, target) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    const normalized = normalizeTarget(target);
    if (!normalized) return null;
    const index = radar.targets.findIndex((item) => item.id === normalized.id);
    const nextTarget = this.mergeTargetTrail(index >= 0 ? radar.targets[index] : null, normalized);
    if (index >= 0) radar.targets[index] = nextTarget;
    else radar.targets.push(nextTarget);
    this.syncLinkedTarget(nextTarget);
    this.render();
    this.emit("radar:target-update", { radar: cloneRadar(radar), target: this.cloneTarget(nextTarget) });
    return this.cloneTarget(nextTarget);
  }

  removeRadarTarget(radarId, targetId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    const index = radar.targets.findIndex((target) => target.id === targetId);
    if (index < 0) return null;
    const [removed] = radar.targets.splice(index, 1);
    if (radar.trackedTargetId === targetId) radar.trackedTargetId = null;
    this.render();
    this.emit("radar:target-update", cloneRadar(radar));
    return this.cloneTarget(removed);
  }

  clearRadarTargets(radarId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    radar.targets = [];
    radar.trackedTargetId = null;
    this.render();
    this.emit("radar:target-update", cloneRadar(radar));
    return cloneRadar(radar);
  }

  clearRadarTargetTrail(radarId, targetId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    const target = findRadarTarget(radar, targetId);
    if (!target) return null;
    target.trail = [];
    this.render();
    this.emit("radar:target-update", { radar: cloneRadar(radar), target: this.cloneTarget(target) });
    return this.cloneTarget(target);
  }

  clearRadarTrails(radarId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    radar.targets.forEach((target) => {
      target.trail = [];
    });
    this.render();
    this.emit("radar:target-update", cloneRadar(radar));
    return cloneRadar(radar);
  }

  trackRadarTarget(radarId, targetId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    const target = findRadarTarget(radar, targetId);
    if (!target) return null;
    radar.trackedTargetId = targetId;
    this.render();
    this.adapter?.focusTarget?.(radar, target);
    this.emit("radar:target-track", { radar: cloneRadar(radar), target: this.cloneTarget(target) });
    return this.cloneTarget(target);
  }

  untrackRadarTarget(radarId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    radar.trackedTargetId = null;
    this.render();
    this.emit("radar:target-track", { radar: cloneRadar(radar), target: null });
    return cloneRadar(radar);
  }

  linkRadarTargetToMarker(radarId, targetId, markerId) {
    const radar = this.radars.get(radarId);
    if (!radar) return null;
    const target = findRadarTarget(radar, targetId);
    if (!target) return null;
    target.markerId = markerId;
    this.syncLinkedTarget(target);
    this.render();
    this.emit("radar:target-link", { radar: cloneRadar(radar), target: this.cloneTarget(target), markerId });
    return this.cloneTarget(target);
  }

  exportRadars() {
    return exportRadarCollection(this.listRadars());
  }

  importRadars(data) {
    this.radars.clear();
    importRadarCollection(data).forEach((radar) => {
      this.radars.set(radar.id, radar);
      this.syncLinkedMarkers(radar);
    });
    this.render();
    if (this.hasScanningRadar()) this.ensureAnimationLoop();
    else this.stopAnimationLoop();
    return this.exportRadars();
  }

  render() {
    this.adapter?.render?.(Array.from(this.radars.values()));
    this.mapEngine.radarStore = this.exportRadars();
  }

  tick(time) {
    this.animationFrame = null;

    if (!this.lastTickTime) this.lastTickTime = time;
    const deltaSeconds = Math.max(0, (time - this.lastTickTime) / 1000);
    this.lastTickTime = time;

    this.radars.forEach((radar) => {
      if (!radar.scanning) return;
      radar.scanAngle = normalizeAngle(radar.scanAngle + radar.scanSpeed * deltaSeconds);
    });

    if (this.adapter?.supportsDynamicScan) {
      this.adapter.requestRender?.();
      this.mapEngine.radarStore = this.exportRadars();
    } else {
      this.render();
    }

    if (this.hasScanningRadar()) {
      this.animationFrame = window.requestAnimationFrame((nextTime) => this.tick(nextTime));
    } else {
      this.stopAnimationLoop();
    }
  }

  ensureAnimationLoop() {
    if (this.animationFrame || typeof window === "undefined") return;
    this.lastTickTime = null;
    this.animationFrame = window.requestAnimationFrame((time) => this.tick(time));
  }

  stopAnimationLoop() {
    if (this.animationFrame && typeof window !== "undefined") {
      window.cancelAnimationFrame(this.animationFrame);
    }
    this.animationFrame = null;
    this.lastTickTime = null;
  }

  stopAnimationLoopIfIdle() {
    if (!this.hasScanningRadar()) this.stopAnimationLoop();
  }

  hasScanningRadar() {
    return Array.from(this.radars.values()).some((radar) => radar.scanning);
  }

  syncLinkedMarkers(radar) {
    radar.targets.forEach((target) => this.syncLinkedTarget(target));
  }

  mergeTargetTrail(existing, nextTarget) {
    const trailLimit = Math.max(1, Number(nextTarget.trailLimit || existing?.trailLimit || 20));
    const baseTrail = nextTarget.trail?.length ? nextTarget.trail : existing?.trail || [];
    const trail = baseTrail.map((position) => [...position]);
    const trailEnabled = nextTarget.trailEnabled !== false;

    if (trailEnabled && existing?.position && !samePosition(existing.position, nextTarget.position)) {
      const lastTrailPoint = trail[trail.length - 1];
      if (!samePosition(lastTrailPoint, existing.position)) {
        trail.push([...existing.position]);
      }
    }

    return {
      ...nextTarget,
      trailEnabled,
      trailLimit,
      trail: trail.slice(-trailLimit),
    };
  }

  cloneTarget(target) {
    return {
      ...target,
      position: [...target.position],
      trail: (target.trail || []).map((position) => [...position]),
      data: { ...(target.data || {}) },
    };
  }

  syncLinkedTarget(target) {
    if (!target.markerId) return;
    const marker = this.mapEngine.getMarker?.(target.markerId);
    if (!marker) return;
    this.mapEngine.addMarker({
      ...marker,
      id: target.markerId,
      name: marker.name || target.name,
      position: target.position,
      data: {
        ...(marker.data || {}),
        radarTargetId: target.id,
      },
    });
  }

  emit(eventName, payload) {
    this.mapEngine.emitLocal?.(eventName, payload);
  }
}
