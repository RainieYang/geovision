import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import Polygon from "ol/geom/Polygon";
import LineString from "ol/geom/LineString";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import { Circle as CircleStyle, Fill, Stroke, Style, Text } from "ol/style";
import { fromLonLat } from "ol/proj";
import { createCircleRing, createScanLine, createSectorRing } from "./radarUtils";

export default class OpenLayersRadarAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new VectorLayer({
      source: this.source,
      zIndex: options.zIndex ?? 1180,
      style: (feature) => this.createStyle(feature),
    });
    this.map.addLayer(this.layer);
  }

  destroy() {
    this.clear();
    this.map?.removeLayer(this.layer);
    this.map = null;
  }

  render(radars = []) {
    this.source.clear();
    radars.forEach((radar) => this.renderRadar(radar));
  }

  clear() {
    this.source?.clear();
  }

  focusTarget(radar, target) {
    if (!this.map || !target?.position) return;
    this.map.getView()?.animate({
      center: fromLonLat(target.position),
      zoom: Math.max(this.map.getView()?.getZoom?.() || 10, 12),
      duration: 260,
    });
  }

  renderRadar(radar) {
    const circle = new Feature({
      geometry: new Polygon([createCircleRing(radar.position, radar.radius).map((coord) => fromLonLat(coord))]),
      radar,
      kind: "circle",
    });
    this.source.addFeature(circle);

    if (radar.enabled) {
      const sector = new Feature({
        geometry: new Polygon([
          createSectorRing(radar.position, radar.radius, radar.scanAngle, radar.scanWidth).map((coord) =>
            fromLonLat(coord)
          ),
        ]),
        radar,
        kind: "sector",
      });
      this.source.addFeature(sector);

      const line = new Feature({
        geometry: new LineString(createScanLine(radar.position, radar.radius, radar.scanAngle).map((coord) => fromLonLat(coord))),
        radar,
        kind: "scanLine",
      });
      this.source.addFeature(line);
    }

    const station = new Feature({
      geometry: new Point(fromLonLat(radar.position)),
      radar,
      kind: "station",
    });
    this.source.addFeature(station);

    (radar.targets || []).forEach((target) => {
      const trailCoordinates = this.getTargetTrailCoordinates(target);
      if (trailCoordinates.length >= 2) {
        const trail = new Feature({
          geometry: new LineString(trailCoordinates.map((coord) => fromLonLat(coord))),
          radar,
          target,
          kind: "targetTrail",
        });
        this.source.addFeature(trail);
      }

      const feature = new Feature({
        geometry: new Point(fromLonLat(target.position)),
        radar,
        target,
        kind: "target",
      });
      this.source.addFeature(feature);
    });
  }

  createStyle(feature) {
    const radar = feature.get("radar");
    const target = feature.get("target");
    const kind = feature.get("kind");
    const style = radar?.style || {};
    const isTracked = target && radar?.trackedTargetId === target.id;

    if (kind === "circle") {
      return new Style({
        fill: new Fill({ color: style.fill || "rgba(34, 211, 238, 0.12)" }),
        stroke: new Stroke({ color: style.stroke || "#22d3ee", width: 2 }),
      });
    }

    if (kind === "sector") {
      return new Style({
        fill: new Fill({ color: style.scanFill || "rgba(34, 211, 238, 0.3)" }),
        stroke: new Stroke({ color: style.stroke || "#22d3ee", width: 1 }),
      });
    }

    if (kind === "scanLine") {
      return new Style({
        stroke: new Stroke({ color: style.stroke || "#22d3ee", width: 3 }),
      });
    }

    if (kind === "station") {
      return new Style({
        image: new CircleStyle({
          radius: 7,
          fill: new Fill({ color: style.stroke || "#22d3ee" }),
          stroke: new Stroke({ color: "#ffffff", width: 2 }),
        }),
        text: new Text({
          text: radar.name || radar.id,
          font: "600 13px Arial, Microsoft YaHei, sans-serif",
          fill: new Fill({ color: "#e0f2fe" }),
          stroke: new Stroke({ color: "rgba(15, 23, 42, 0.9)", width: 4 }),
          offsetY: -18,
        }),
      });
    }

    if (kind === "targetTrail") {
      const targetStyle = this.getTargetStyle(target, isTracked, style);
      return new Style({
        stroke: new Stroke({ color: targetStyle.trailColor, width: isTracked ? 4 : 3 }),
      });
    }

    const targetStyle = this.getTargetStyle(target, isTracked, style);

    return new Style({
      image: new CircleStyle({
        radius: targetStyle.radius,
        fill: new Fill({ color: targetStyle.color }),
        stroke: new Stroke({ color: targetStyle.outlineColor, width: targetStyle.outlineWidth }),
      }),
      text: new Text({
        text: targetStyle.label,
        font: "600 12px Arial, Microsoft YaHei, sans-serif",
        fill: new Fill({ color: targetStyle.labelColor }),
        stroke: new Stroke({ color: "rgba(15, 23, 42, 0.9)", width: 4 }),
        offsetY: -16,
      }),
    });
  }

  getTargetTrailCoordinates(target) {
    if (target?.trailEnabled === false) return [];
    return [...(target?.trail || []), target.position].filter(Boolean);
  }

  getTargetStyle(target, isTracked, radarStyle = {}) {
    if (isTracked) {
      return {
        color: "#facc15",
        trailColor: "rgba(250, 204, 21, 0.45)",
        radius: 8,
        outlineColor: "#ffffff",
        outlineWidth: 3,
        label: target.name || target.id,
        labelColor: "#fef9c3",
      };
    }

    const styles = {
      active: { color: radarStyle.target || "#f97316", trailColor: "rgba(249, 115, 22, 0.35)", radius: 5, label: "" },
      focus: { color: "#fde047", trailColor: "rgba(253, 224, 71, 0.42)", radius: 7, label: target.name || target.id },
      warning: { color: "#facc15", trailColor: "rgba(250, 204, 21, 0.42)", radius: 7, label: target.name || target.id },
      danger: { color: "#ef4444", trailColor: "rgba(239, 68, 68, 0.5)", radius: 8, label: target.name || target.id },
      lost: { color: "rgba(148, 163, 184, 0.65)", trailColor: "rgba(148, 163, 184, 0.28)", radius: 5, label: target.name || target.id },
      handled: { color: "#22c55e", trailColor: "rgba(34, 197, 94, 0.35)", radius: 6, label: target.name || target.id },
    };

    const targetStyle = styles[target?.status] || styles.active;
    return {
      ...targetStyle,
      outlineColor: "#ffffff",
      outlineWidth: target?.status === "danger" ? 3 : 2,
      labelColor: target?.status === "lost" ? "#cbd5e1" : "#ffedd5",
    };
  }
}
