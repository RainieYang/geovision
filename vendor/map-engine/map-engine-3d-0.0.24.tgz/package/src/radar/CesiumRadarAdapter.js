import { createCircleRing, createScanLine, createSectorRing } from "./radarUtils";

export default class CesiumRadarAdapter {
  constructor(engine) {
    this.engine = engine;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.entities = new Map();
    this.supportsDynamicScan = true;
    if (this.viewer?.clock) {
      this.viewer.clock.shouldAnimate = true;
    }
  }

  destroy() {
    this.clear();
    this.viewer = null;
  }

  clear() {
    if (!this.viewer) return;
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
    this.viewer.scene.requestRender?.();
  }

  render(radars = []) {
    const activeIds = new Set();
    radars.forEach((radar) => this.renderRadar(radar, activeIds));
    this.removeInactiveEntities(activeIds);
    this.viewer.scene.requestRender?.();
  }

  focusTarget(radar, target) {
    if (!this.viewer || !target?.position) return;
    this.viewer.camera.flyTo({
      destination: this.CesiumLib.Cartesian3.fromDegrees(target.position[0], target.position[1], Math.max(radar.radius * 3, 3500)),
      duration: 0.5,
    });
  }

  renderRadar(radar, activeIds) {
    const stroke = this.toColor(radar.style?.stroke || "#22d3ee");
    const fill = this.toColor(radar.style?.fill || "rgba(34, 211, 238, 0.12)");
    const scanFill = this.toColor(radar.style?.scanFill || "rgba(34, 211, 238, 0.3)");
    const height = radar.style?.height ?? 30;

    this.upsertEntity(`${radar.id}-circle`, {
      position: this.CesiumLib.Cartesian3.fromDegrees(radar.position[0], radar.position[1]),
      ellipse: {
        semiMajorAxis: radar.radius,
        semiMinorAxis: radar.radius,
        material: fill,
        outline: true,
        outlineColor: stroke,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        zIndex: 1,
      },
    }, activeIds);

    this.upsertEntity(`${radar.id}-ring-line`, {
      polyline: {
        positions: this.createRaisedPositions(createCircleRing(radar.position, radar.radius), height),
        width: 2,
        material: stroke,
        clampToGround: false,
      },
    }, activeIds);

    if (radar.enabled) {
      this.upsertEntity(`${radar.id}-sector`, {
        polygon: {
          hierarchy: new this.CesiumLib.CallbackProperty(
            () => new this.CesiumLib.PolygonHierarchy(
              this.createRaisedPositions(createSectorRing(radar.position, radar.radius, radar.scanAngle, radar.scanWidth), height)
            ),
            false
          ),
          material: scanFill,
          outline: true,
          outlineColor: stroke,
          perPositionHeight: true,
        },
      }, activeIds);

      this.upsertEntity(`${radar.id}-scan-line`, {
        polyline: {
          positions: new this.CesiumLib.CallbackProperty(
            () => this.createRaisedPositions(createScanLine(radar.position, radar.radius, radar.scanAngle), height + 2),
            false
          ),
          width: 4,
          material: stroke,
          clampToGround: false,
        },
      }, activeIds);
    }

    this.upsertEntity(`${radar.id}-station`, {
      position: this.CesiumLib.Cartesian3.fromDegrees(radar.position[0], radar.position[1]),
      point: {
        pixelSize: 13,
        color: stroke,
        outlineColor: this.CesiumLib.Color.WHITE,
        outlineWidth: 2,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: 0,
      },
      label: {
        text: radar.name || radar.id,
        font: "600 14px sans-serif",
        fillColor: this.CesiumLib.Color.WHITE,
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 4,
        style: this.CesiumLib.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new this.CesiumLib.Cartesian2(0, -22),
        disableDepthTestDistance: 0,
      },
    }, activeIds);

    (radar.targets || []).forEach((target) => this.renderTarget(radar, target, activeIds));
  }

  renderTarget(radar, target, activeIds) {
    const isTracked = radar.trackedTargetId === target.id;
    const targetStyle = this.getTargetStyle(radar, target, isTracked);
    const trailCoordinates = this.getTargetTrailCoordinates(target);

    if (trailCoordinates.length >= 2) {
      this.upsertEntity(`${radar.id}-target-${target.id}-trail`, {
        polyline: {
          positions: this.createRaisedPositions(trailCoordinates, radar.style?.height ?? 32),
          width: isTracked ? 4 : 3,
          material: targetStyle.trailColor,
          clampToGround: false,
        },
      }, activeIds);
    }

    this.upsertEntity(`${radar.id}-target-${target.id}`, {
      position: this.CesiumLib.Cartesian3.fromDegrees(target.position[0], target.position[1]),
      point: {
        pixelSize: targetStyle.pixelSize,
        color: targetStyle.color,
        outlineColor: this.CesiumLib.Color.WHITE,
        outlineWidth: targetStyle.outlineWidth,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: 0,
      },
      label: targetStyle.label
        ? {
            text: targetStyle.label,
            font: "600 13px sans-serif",
            fillColor: targetStyle.labelColor,
            outlineColor: this.CesiumLib.Color.BLACK,
            outlineWidth: 4,
            style: this.CesiumLib.LabelStyle.FILL_AND_OUTLINE,
            pixelOffset: new this.CesiumLib.Cartesian2(0, -18),
            disableDepthTestDistance: 0,
          }
        : undefined,
    }, activeIds);
  }

  addEntity(id, options, activeIds) {
    activeIds?.add(id);
    const entity = this.viewer.entities.add({
      id,
      ...options,
    });
    this.entities.set(id, entity);
    return entity;
  }

  upsertEntity(id, options, activeIds) {
    activeIds?.add(id);
    const entity = this.entities.get(id);
    if (!entity) return this.addEntity(id, options, activeIds);
    this.updateEntity(entity, options);
    return entity;
  }

  updateEntity(entity, options) {
    if (Object.prototype.hasOwnProperty.call(options, "position")) {
      entity.position = options.position;
    }
    if (Object.prototype.hasOwnProperty.call(options, "polygon")) {
      entity.polygon = this.assignGraphic(entity.polygon, options.polygon, "PolygonGraphics");
      entity.ellipse = undefined;
    }
    if (Object.prototype.hasOwnProperty.call(options, "ellipse")) {
      entity.ellipse = this.assignGraphic(entity.ellipse, options.ellipse, "EllipseGraphics");
      entity.polygon = undefined;
    }
    if (Object.prototype.hasOwnProperty.call(options, "polyline")) {
      entity.polyline = this.assignGraphic(entity.polyline, options.polyline, "PolylineGraphics");
    }
    if (Object.prototype.hasOwnProperty.call(options, "point")) {
      entity.point = this.assignGraphic(entity.point, options.point, "PointGraphics");
    }
    if (Object.prototype.hasOwnProperty.call(options, "label")) {
      entity.label = options.label
        ? this.assignGraphic(entity.label, options.label, "LabelGraphics")
        : undefined;
    }
  }

  assignGraphic(existing, next, graphicName) {
    const GraphicCtor = this.CesiumLib[graphicName];
    const graphic = existing || (GraphicCtor ? new GraphicCtor() : {});
    Object.keys(next || {}).forEach((key) => {
      graphic[key] = next[key];
    });
    return graphic;
  }

  removeInactiveEntities(activeIds) {
    this.entities.forEach((entity, id) => {
      if (activeIds.has(id)) return;
      this.viewer.entities.remove(entity);
      this.entities.delete(id);
    });
  }

  getTargetTrailCoordinates(target) {
    if (target?.trailEnabled === false) return [];
    return [...(target?.trail || []), target.position].filter(Boolean);
  }

  getTargetStyle(radar, target, isTracked) {
    if (isTracked) {
      return {
        color: this.CesiumLib.Color.YELLOW,
        trailColor: this.CesiumLib.Color.YELLOW.withAlpha(0.48),
        pixelSize: 14,
        outlineWidth: 3,
        label: target.name || target.id,
        labelColor: this.CesiumLib.Color.WHITE,
      };
    }

    const styles = {
      active: { color: radar.style?.target || "#f97316", alpha: 1, trailAlpha: 0.35, pixelSize: 9, label: "" },
      focus: { color: "#fde047", alpha: 1, trailAlpha: 0.45, pixelSize: 12, label: target.name || target.id },
      warning: { color: "#facc15", alpha: 1, trailAlpha: 0.45, pixelSize: 12, label: target.name || target.id },
      danger: { color: "#ef4444", alpha: 1, trailAlpha: 0.55, pixelSize: 14, label: target.name || target.id },
      lost: { color: "#94a3b8", alpha: 0.65, trailAlpha: 0.28, pixelSize: 9, label: target.name || target.id },
      handled: { color: "#22c55e", alpha: 1, trailAlpha: 0.38, pixelSize: 10, label: target.name || target.id },
    };
    const statusStyle = styles[target?.status] || styles.active;
    const baseColor = this.toColor(statusStyle.color);

    return {
      color: baseColor.withAlpha(statusStyle.alpha),
      trailColor: baseColor.withAlpha(statusStyle.trailAlpha),
      pixelSize: statusStyle.pixelSize,
      outlineWidth: target?.status === "danger" ? 3 : 2,
      label: statusStyle.label,
      labelColor: target?.status === "lost" ? this.CesiumLib.Color.LIGHTGRAY : this.CesiumLib.Color.WHITE,
    };
  }

  requestRender() {
    if (!this.viewer || this.viewer.isDestroyed?.()) return;
    this.viewer.scene.requestRender?.();
    try {
      this.viewer.render?.();
    } catch (error) {
      // Cesium can reject manual rendering while its own render loop is active.
    }
  }

  createRaisedPositions(coordinates, height = 30) {
    return this.CesiumLib.Cartesian3.fromDegreesArrayHeights(
      coordinates.flatMap((coordinate) => [coordinate[0], coordinate[1], height])
    );
  }

  toColor(value) {
    return this.CesiumLib.Color.fromCssColorString(value || "#22d3ee");
  }
}
