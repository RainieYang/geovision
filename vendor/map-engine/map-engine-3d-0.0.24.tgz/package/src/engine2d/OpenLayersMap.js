﻿import OLMap from "ol/Map";
import View from "ol/View";
import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import LineString from "ol/geom/LineString";
import Polygon from "ol/geom/Polygon";
import Circle from "ol/geom/Circle";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import { Style, Icon, Circle as CircleStyle, Fill, Stroke, Text } from "ol/style";
import { fromLonLat, toLonLat } from "ol/proj";
import { defaults as defaultInteractions } from "ol/interaction/defaults";
import MouseWheelZoom from "ol/interaction/MouseWheelZoom";
import LayerManager from "../layer/LayerManager";
import { createMapPopup } from "../utils/popup";

export default class OpenLayersMap {
  constructor(options = {}) {
    this.options = options;
    this.map = null;
    this.layerManager = null;
    this.watermarkEl = null;
    this.pointerLngLat = null;
    this.markerLayer = null;
    this.markerSource = null;
    this.markers = new globalThis.Map();
    this.objectLayer = null;
    this.objectSource = null;
    this.spatialObjects = new globalThis.Map();
    this.events = new globalThis.Map();
    this.popupEl = null;
    this.pendingZoomFrame = null;
    this.pendingZoomTarget = null;
  }

  init() {
    const {
      container,
      center = [104.0668, 30.5728],
      zoom = 10,
      watermark = "GeoVision",
    } = this.options;

    const configuredMinZoom = Number(this.options.minZoom2d ?? this.options.minZoom);
    const minZoom = Number.isFinite(configuredMinZoom) ? configuredMinZoom : undefined;
    const vectorBaseMap = this.options.baseMapProvider === "mvt";
    const mapOptions = {
      target: container,
      layers: [],
      view: new View({
        center: fromLonLat(center),
        zoom,
        minZoom,
        rotation: Number.isFinite(Number(this.options.rotation))
          ? Number(this.options.rotation)
          : Number.isFinite(Number(this.options.heading))
            ? -Number(this.options.heading)
            : 0,
        enableRotation: true,
        constrainRotation: false,
      }),
      controls: [],
    };

    if (vectorBaseMap) {
      mapOptions.maxTilesLoading = Math.max(2, Number(this.options.maxVectorTileLoads ?? 8));
      mapOptions.interactions = createVectorOptimizedInteractions(this.options);
    }

    this.map = new OLMap(mapOptions);
    if (vectorBaseMap) {
      this.map.set("vectorRequestOptimization", {
        maxTilesLoading: mapOptions.maxTilesLoading,
        wheelTimeout: Math.max(40, Number(this.options.vectorWheelTimeout ?? 120)),
        zoomDuration: Math.max(0, Number(this.options.vectorZoomDuration ?? 160)),
        constrainResolution: this.options.vectorConstrainResolution !== false,
      });
    }

    this.layerManager = new LayerManager({
      engineType: "2d",
      map: this.map,
    });

    this.initBaseLayer();
    this.initMarkerLayer();
    this.initObjectLayer();
    this.initPointerStatus();
    this.initClickEvent();
    this.addWatermark(watermark);
  }

  initBaseLayer() {
    const provider = this.options.baseMapProvider || "tianditu";

    if (provider === "none") return;

    this.setBaseLayer({
      provider,
      tiandituTk: this.options.tiandituTk,
      baseMapType: this.options.baseMapType || "vec",
      showAnnotation: this.options.showAnnotation !== false,
      projection: this.options.projection || "w",
      minimumLevel: this.options.minimumLevel,
      maximumLevel: this.options.maximumLevel,
      url: this.options.baseMapUrl,
      localVectorServiceUrl: this.options.localVectorServiceUrl,
      localVectorStyle: this.options.localVectorStyle || "default",
      baseMapLanguage: this.options.baseMapLanguage,
      localVectorDataMaxZoom: this.options.localVectorDataMaxZoom,
      localVectorZoomCoverage: this.options.localVectorZoomCoverage,
      renderBuffer: this.options.vectorRenderBuffer,
      declutter: this.options.vectorDeclutter,
      militaryBasemap: this.options.militaryBasemap,
    });
  }

  initMarkerLayer() {
    this.markerSource = new VectorSource();
    this.markerLayer = new VectorLayer({
      source: this.markerSource,
      zIndex: 1000,
    });
    this.map.addLayer(this.markerLayer);
  }

  initObjectLayer() {
    this.objectSource = new VectorSource();
    this.objectLayer = new VectorLayer({
      source: this.objectSource,
      zIndex: 900,
    });
    this.map.addLayer(this.objectLayer);
  }

  initPointerStatus() {
    this.map.on("pointermove", (event) => {
      this.pointerLngLat = toLonLat(event.coordinate);
    });
  }

  initClickEvent() {
    this.map.on("singleclick", (event) => {
      const feature = this.map.forEachFeatureAtPixel(
        event.pixel,
        (pickedFeature) => pickedFeature,
        {
          layerFilter: (layer) => layer === this.markerLayer,
          hitTolerance: 8,
        }
      );

      const lnglat = toLonLat(event.coordinate);
      this.pointerLngLat = lnglat;

      if (feature) {
        const marker = feature.get("rawMarker") || {};

        this.emit("click", {
          type: "marker",
          target: feature,
          id: feature.getId(),
          name: feature.get("name"),
          lnglat,
          screenPosition: event.pixel,
          originalEvent: event,
        });

        this.showMarkerPopup(feature, event.pixel, marker.popup);
        return;
      }

      const objectFeature = this.map.forEachFeatureAtPixel(
        event.pixel,
        (pickedFeature) => pickedFeature,
        {
          layerFilter: (layer) => layer === this.objectLayer,
          hitTolerance: 8,
        }
      );

      if (objectFeature) {
        const object = objectFeature.get("spatialObject");
        this.emit("object:click", {
          id: object?.id || objectFeature.getId(),
          object,
          target: objectFeature,
          position: lnglat,
          screenPosition: event.pixel,
          originalEvent: event,
        });
        this.showSpatialObjectPopup(object, event.pixel);
        return;
      }

      const drawFeature = this.getDrawFeatureAtPixel(event.pixel);
      if (drawFeature) {
        this.emit("click", {
          type: "draw",
          target: drawFeature,
          id: drawFeature.properties?.id,
          name: drawFeature.properties?.name,
          lnglat,
          screenPosition: event.pixel,
          originalEvent: event,
        });

        this.showDrawFeaturePopup(drawFeature, event.pixel);
        return;
      }

      this.hidePopup();
      this.emit("click", {
        type: "map",
        target: this,
        lnglat,
        screenPosition: event.pixel,
        originalEvent: event,
      });
    });

    this.map.on("pointermove", (event) => {
      const hasMarker = this.map.hasFeatureAtPixel(event.pixel, {
        layerFilter: (layer) => layer === this.markerLayer,
        hitTolerance: 8,
      });
      const objectFeature = this.map.forEachFeatureAtPixel(
        event.pixel,
        (pickedFeature) => pickedFeature,
        {
          layerFilter: (layer) => layer === this.objectLayer,
          hitTolerance: 8,
        }
      );
      const hasDrawFeature = Boolean(this.getDrawFeatureAtPixel(event.pixel));

      const target = this.map.getTargetElement();
      if (objectFeature) {
        const object = objectFeature.get("spatialObject");
        this.emit("object:hover", {
          id: object?.id || objectFeature.getId(),
          object,
          target: objectFeature,
          position: toLonLat(event.coordinate),
          screenPosition: event.pixel,
          originalEvent: event,
        });
      }

      if (target) target.style.cursor = hasMarker || objectFeature || hasDrawFeature ? "pointer" : "";
    });
  }

  getDrawFeatureAtPixel(pixel) {
    if (!this.map || !pixel) return null;

    const features = this.map.getFeaturesAtPixel(pixel, {
      hitTolerance: 10,
    }) || [];
    const drawLayerFeature = features.find((candidate) => candidate?.get?.("drawFeature"));

    return drawLayerFeature?.get("drawFeature") || null;
  }

  zoomIn() {
    this.queueZoom(1);
  }

  zoomOut() {
    this.queueZoom(-1);
  }

  queueZoom(delta) {
    const view = this.map?.getView();
    if (!view) return;
    const current = this.pendingZoomTarget ?? view.getZoom() ?? 0;
    this.pendingZoomTarget = current + Number(delta || 0);
    if (this.pendingZoomFrame !== null) return;

    this.pendingZoomFrame = requestAnimationFrame(() => {
      const target = this.pendingZoomTarget;
      this.pendingZoomFrame = null;
      this.pendingZoomTarget = null;
      view.cancelAnimations?.();
      view.animate({
        zoom: target,
        duration: Math.max(0, Number(this.options.vectorZoomDuration ?? 160)),
      });
    });
  }

  resetView() {
    const view = this.map?.getView();
    if (!view) return;

    const center = this.options.center || [104.0668, 30.5728];
    const zoom = this.options.zoom ?? 10;

    view.animate({ center: fromLonLat(center), zoom, rotation: 0, duration: 260 });
  }

  centerAt(position, options = {}) {
    const view = this.map?.getView();
    if (!view || !Array.isArray(position) || position.length < 2) return null;

    const lng = Number(position[0]);
    const lat = Number(position[1]);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;

    const currentZoom = view.getZoom();
    const minZoom = Number(options.minZoom ?? 13);
    const requestedZoom = Number(options.zoom);
    const zoom = Number.isFinite(requestedZoom)
      ? requestedZoom
      : Math.max(Number.isFinite(currentZoom) ? currentZoom : minZoom, minZoom);
    const duration = Math.max(0, Number(options.duration ?? 260));

    view.animate({
      center: fromLonLat([lng, lat]),
      zoom,
      duration,
    });

    return { position: [lng, lat], zoom };
  }

  setView(view = {}) {
    const olView = this.map?.getView();
    if (!olView) return null;
    const center = Array.isArray(view.center) ? view.center : this.options.center || [104.0668, 30.5728];
    const zoom = Number.isFinite(Number(view.zoom)) ? Number(view.zoom) : olView.getZoom();
    const rotation = Number.isFinite(Number(view.rotation))
      ? Number(view.rotation)
      : Number.isFinite(Number(view.heading))
        ? -Number(view.heading)
        : olView.getRotation();
    olView.setCenter(fromLonLat(center));
    olView.setZoom(zoom);
    olView.setRotation(rotation);
    return this.getViewState();
  }

  flyTo(view = {}) {
    const olView = this.map?.getView();
    if (!olView) return null;
    const center = Array.isArray(view.center) ? view.center : this.options.center || [104.0668, 30.5728];
    const zoom = Number.isFinite(Number(view.zoom)) ? Number(view.zoom) : olView.getZoom();
    const rotation = Number.isFinite(Number(view.rotation))
      ? Number(view.rotation)
      : Number.isFinite(Number(view.heading))
        ? -Number(view.heading)
        : olView.getRotation();
    olView.animate({ center: fromLonLat(center), zoom, rotation, duration: view.duration ?? 260 });
    return { center, zoom, rotation, heading: -rotation };
  }

  getCameraOrientation() {
    const view = this.map?.getView();
    if (!view) return null;

    const rotation = view.getRotation() || 0;
    const heading = -rotation;

    return {
      heading,
      pitch: -Math.PI / 2,
      roll: 0,
      tilt: 0,
      rotation,
      headingDegrees: radiansToDegrees(heading),
      pitchDegrees: -90,
      rollDegrees: 0,
    };
  }

  setCameraOrientation(options = {}) {
    const view = this.map?.getView();
    if (!view) return null;

    const current = this.getCameraOrientation() || {};
    const heading = normalizeRadians(
      readNumber(options.heading, degreesToRadians(options.headingDegrees), current.heading || 0)
    );
    const rotation = -heading;
    const duration = Math.max(0, Number(options.duration) || 0);

    if (duration > 0) {
      view.animate({ rotation, duration: duration * 1000 });
    } else {
      view.setRotation(rotation);
      this.map?.renderSync?.();
    }

    return this.getCameraOrientation();
  }

  resetCameraOrientation() {
    return this.setCameraOrientation({ heading: 0, duration: 0.25 });
  }

  resize() {
    this.map?.updateSize?.();
  }

  getStatus() {
    const view = this.map?.getView();
    if (!view) return {};

    const centerLngLat = toLonLat(view.getCenter());
    const lngLat = this.pointerLngLat || centerLngLat;

    return {
      lng: lngLat[0],
      lat: lngLat[1],
      height: 0,
      cameraHeight: 0,
      zoom: view.getZoom(),
    };
  }

  getViewState() {
    const view = this.map?.getView();
    if (!view) return null;
    const center = toLonLat(view.getCenter());

    return {
      type: "2d",
      center,
      zoom: view.getZoom(),
      rotation: view.getRotation() || 0,
      heading: -(view.getRotation() || 0),
      cameraHeight: 0,
    };
  }

  setBaseLayer(options = {}) {
    if (!this.layerManager) {
      console.warn("OpenLayersMap: map is not initialized");
      return null;
    }

    return this.layerManager.setBaseLayer(options);
  }

  setBaseMapStyle(name) {
    return this.layerManager?.setBaseMapStyle(name) || Promise.resolve(false);
  }

  setBaseMapLanguage(language) {
    return this.layerManager?.setBaseMapLanguage(language) || Promise.resolve({ applied: false, baseMapLanguage: language });
  }

  getBaseMapPerformanceStats(options) {
    return this.layerManager?.getBaseMapPerformanceStats(options) || null;
  }

  async waitForBaseMapReady({ timeout = 4000 } = {}) {
    const baseLayer = this.layerManager?.getBaseLayerIds()
      .map((id) => this.layerManager.getLayer(id))
      .find(Boolean);
    const styleReady = baseLayer?.get?.("styleReady");
    if (styleReady) await styleReady;
    if (!this.map) return false;

    return new Promise((resolve) => {
      let settled = false;
      const done = (rendered) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(rendered);
      };
      const timer = setTimeout(() => done(false), timeout);
      this.map.once("rendercomplete", () => done(true));
      this.map.render();
    });
  }

  addLayers(layers = []) {
    return this.layerManager?.addLayers(layers) || [];
  }

  addLayer(options = {}) {
    if (!this.layerManager) {
      console.warn("OpenLayersMap: map is not initialized");
      return null;
    }

    return this.layerManager.addLayer(options);
  }

  removeLayer(id) {
    return this.layerManager?.removeLayer(id);
  }

  getLayer(id) {
    return this.layerManager?.getLayer(id);
  }

  getNativeLayer(id) {
    return this.layerManager?.getNativeLayer(id);
  }

  getLayerInfo(id) {
    return this.layerManager?.getLayerInfo(id);
  }

  listLayers() {
    return this.layerManager?.listLayers() || [];
  }

  hasLayer(id) {
    return this.layerManager?.hasLayer(id);
  }

  showLayer(id) {
    return this.layerManager?.showLayer(id);
  }

  hideLayer(id) {
    return this.layerManager?.hideLayer(id);
  }

  setLayerVisible(id, visible) {
    return this.layerManager?.setLayerVisible(id, visible);
  }

  setLayerOpacity(id, opacity) {
    return this.layerManager?.setOpacity(id, opacity);
  }

  setLayerZIndex(id, zIndex) {
    return this.layerManager?.setZIndex(id, zIndex);
  }

  clearLayers() {
    return this.layerManager?.clearLayers();
  }

  clearOverlayLayers() {
    return this.layerManager?.clearOverlayLayers();
  }

  clearBaseLayers() {
    return this.layerManager?.clearBaseLayers();
  }

  getBaseLayerIds() {
    return this.layerManager?.getBaseLayerIds() || [];
  }

  getLayerManager() {
    return this.layerManager;
  }

  addMarkers(markers = []) {
    if (!Array.isArray(markers)) return [];
    return markers.map((marker) => this.addMarker(marker)).filter(Boolean);
  }

  addMarker(marker = {}) {
    if (!this.markerSource) return null;

    const {
      id,
      position,
      name = "未命名点位",
      icon,
      iconWidth = 36,
      iconHeight = 36,
      iconAnchor = [0.5, 1],
      rotationDegrees,
      rotationReference = "screen",
      label = {},
      color = "#ef4444",
      data = {},
      popup = null,
    } = marker;

    if (!id) {
      console.warn("addMarker failed: marker.id is required");
      return null;
    }

    if (!Array.isArray(position) || position.length < 2) {
      console.warn("addMarker failed: marker.position is required");
      return null;
    }

    if (this.markers.has(id)) {
      this.removeMarker(id);
    }

    const feature = new Feature({
      geometry: new Point(fromLonLat(position)),
      id,
      name,
      markerData: data,
      popup,
      rawMarker: marker,
    });

    feature.setId(id);
    feature.setStyle(this.createMarkerStyle({
      id,
      name,
      icon,
      iconWidth,
      iconHeight,
      iconAnchor,
      rotationDegrees,
      rotationReference,
      label,
      color,
    }));

    this.markerSource.addFeature(feature);
    this.markers.set(id, feature);

    return feature;
  }

  updateMarker(id, patch = {}) {
    const feature = this.markers.get(id);
    if (!feature || !this.markerSource) return null;

    const previous = feature.get("rawMarker") || {};
    const next = { ...previous, ...patch, id };
    const {
      position,
      name = previous.name || "未命名点位",
      icon = previous.icon,
      iconWidth = previous.iconWidth || 36,
      iconHeight = previous.iconHeight || 36,
      iconAnchor = previous.iconAnchor || [0.5, 1],
      rotationDegrees = previous.rotationDegrees,
      rotationReference = previous.rotationReference || "screen",
      label = previous.label || {},
      color = previous.color || "#ef4444",
      data = previous.data || {},
      popup = previous.popup ?? null,
    } = next;

    if (Array.isArray(position) && position.length >= 2) {
      feature.setGeometry(new Point(fromLonLat(position)));
    }

    feature.set("name", name);
    feature.set("markerData", data);
    feature.set("popup", popup);
    feature.set("rawMarker", next);
    feature.setStyle(this.createMarkerStyle({
      id,
      name,
      icon,
      iconWidth,
      iconHeight,
      iconAnchor,
      rotationDegrees,
      rotationReference,
      label,
      color,
    }));

    return feature;
  }

  createMarkerStyle(marker) {
    const { name, icon, iconWidth, iconHeight, iconAnchor = [0.5, 1], rotationDegrees, rotationReference = "screen", label = {}, color } = marker;
    const rotation = rotationDegrees === null || rotationDegrees === undefined ? NaN : Number(rotationDegrees);

    const image = icon
      ? new Icon({
          src: icon,
          width: iconWidth,
          height: iconHeight,
          anchor: iconAnchor,
          rotation: Number.isFinite(rotation) ? rotation * Math.PI / 180 : 0,
          rotateWithView: rotationReference === "geographic",
        })
      : new CircleStyle({
          radius: 7,
          fill: new Fill({ color }),
          stroke: new Stroke({ color: "#ffffff", width: 2 }),
        });

    return new Style({
      image,
      text:
        label.show === false
          ? undefined
          : new Text({
              text: label.text || name,
              font: label.font || "14px sans-serif",
              fill: new Fill({ color: label.fillColor || "#111827" }),
              stroke: new Stroke({ color: label.outlineColor || "#ffffff", width: label.outlineWidth ?? 3 }),
              offsetX: label.offsetX ?? 0,
              offsetY: label.offsetY ?? -42,
            }),
    });
  }

  removeMarkers(ids = []) {
    if (!Array.isArray(ids)) return [];
    return ids.map((id) => this.removeMarker(id));
  }

  removeMarker(id) {
    const feature = this.markers.get(id);
    if (!feature || !this.markerSource) return false;

    this.markerSource.removeFeature(feature);
    this.markers.delete(id);
    return true;
  }

  getMarker(id) {
    return this.markers.get(id) || null;
  }

  hasMarker(id) {
    return this.markers.has(id);
  }

  listMarkers() {
    return Array.from(this.markers.values());
  }

  clearMarkers() {
    this.markerSource?.clear();
    this.markers.clear();
  }

  renderObject(object) {
    return this.updateObject(object);
  }

  updateObject(object = {}) {
    if (!object?.id) return null;
    if (object.type === "marker" || object.type === "text") {
      return this.addMarker(this.objectToMarker(object));
    }

    this.removeObject(object.id);
    const feature = this.createObjectFeature(object);
    if (!feature) return null;
    this.objectSource?.addFeature(feature);
    this.spatialObjects.set(object.id, feature);
    return feature;
  }

  removeObject(id) {
    if (this.popupEl?.dataset?.mapObjectId === String(id)) this.hidePopup();
    if (this.markers.has(id)) return this.removeMarker(id);
    const feature = this.spatialObjects.get(id);
    if (!feature) return false;
    this.objectSource?.removeFeature(feature);
    this.spatialObjects.delete(id);
    return true;
  }

  clearObjects() {
    this.clearMarkers();
    this.objectSource?.clear();
    this.spatialObjects.clear();
  }

  queryFeatureAtPixel(pixel, options = {}) {
    if (!this.map || !Array.isArray(pixel)) return null;
    const feature = this.map.forEachFeatureAtPixel(pixel, (pickedFeature) => pickedFeature, {
      hitTolerance: options.hitTolerance ?? 8,
      layerFilter: (layer) => layer === this.markerLayer || layer === this.objectLayer,
    });
    return feature ? this.featureToQueryResult(feature, { screenPosition: pixel }) : null;
  }

  queryObjectsByBounds(bounds) {
    if (!Array.isArray(bounds) || bounds.length < 4) return [];
    const [minLng, minLat, maxLng, maxLat] = bounds.map(Number);
    return this.listQueryableFeatures().filter(({ object }) =>
      getObjectCoordinates(object).some(([lng, lat]) => lng >= minLng && lng <= maxLng && lat >= minLat && lat <= maxLat)
    );
  }

  queryObjectsByPoint(point, options = {}) {
    if (!Array.isArray(point)) return [];
    const [lng, lat] = point.map(Number);
    const tolerance = Number(options.tolerance ?? 0.0005);
    return this.listQueryableFeatures().filter(({ object }) =>
      getObjectCoordinates(object).some(
        ([objectLng, objectLat]) => Math.abs(objectLng - lng) <= tolerance && Math.abs(objectLat - lat) <= tolerance
      )
    );
  }

  listQueryableFeatures() {
    return [...Array.from(this.markers.values()), ...Array.from(this.spatialObjects.values())]
      .map((feature) => this.featureToQueryResult(feature))
      .filter(Boolean);
  }

  featureToQueryResult(feature, extra = {}) {
    const marker = feature.get("rawMarker");
    const object = feature.get("spatialObject") || (marker ? {
      id: marker.id,
      type: "marker",
      position: marker.position,
      properties: marker.data || {},
      style: { icon: marker.icon, color: marker.color, label: marker.label },
    } : null);
    if (!object?.id) return null;
    return {
      id: String(object.id),
      object,
      target: feature,
      position: object.position || getObjectCoordinates(object)[0],
      ...extra,
    };
  }

  objectToMarker(object) {
    return {
      id: object.id,
      name: object.properties?.name || object.style?.label?.text || object.id,
      position: object.position,
      icon: object.style?.icon,
      iconWidth: object.style?.iconWidth,
      iconHeight: object.style?.iconHeight,
      iconAnchor: object.style?.iconAnchor,
      rotationDegrees: object.style?.rotationDegrees,
      rotationReference: object.style?.rotationReference,
      color: object.style?.color,
      label: object.type === "text"
        ? { ...(object.style?.label || {}), text: object.properties?.text || object.style?.text || object.properties?.name || object.id }
        : object.style?.label,
      data: object.properties || {},
      popup: object.properties?.popup,
    };
  }

  createObjectFeature(object) {
    const geometry = this.createObjectGeometry(object);
    if (!geometry) return null;
    const feature = new Feature({ geometry, spatialObject: object });
    feature.setId(object.id);
    feature.setStyle(this.createObjectStyle(object));
    return feature;
  }

  createObjectGeometry(object) {
    const coordinates = object.geometry?.coordinates;
    if (object.type === "line" && Array.isArray(coordinates)) {
      return new LineString(coordinates.map((coordinate) => fromLonLat(coordinate)));
    }
    if (object.type === "polygon" && Array.isArray(coordinates)) {
      const rings = Array.isArray(coordinates[0]?.[0]) ? coordinates : [coordinates];
      return new Polygon(rings.map((ring) => ring.map((coordinate) => fromLonLat(coordinate))));
    }
    if (object.type === "circle" && Array.isArray(object.position)) {
      return new Circle(fromLonLat(object.position), Number(object.style?.radius || object.properties?.radius || 1000));
    }
    if (Array.isArray(object.position)) return new Point(fromLonLat(object.position));
    return null;
  }

  createObjectStyle(object) {
    const style = object.style || {};
    return new Style({
      image: new CircleStyle({
        radius: style.pixelSize || 7,
        fill: new Fill({ color: style.fillColor || style.color || "rgba(37, 99, 235, 0.25)" }),
        stroke: new Stroke({ color: style.strokeColor || style.color || "#2563eb", width: style.strokeWidth ?? 2 }),
      }),
      stroke: new Stroke({
        color: style.strokeColor || style.color || "#2563eb",
        width: style.strokeWidth ?? 2,
        lineDash: Array.isArray(style.lineDash) ? style.lineDash : undefined,
      }),
      fill: new Fill({ color: style.fillColor || "rgba(37, 99, 235, 0.2)" }),
      text: style.text || object.properties?.text
        ? new Text({
            text: style.text || object.properties?.text,
            font: style.font || "14px sans-serif",
            fill: new Fill({ color: style.textColor || "#111827" }),
            stroke: new Stroke({ color: style.textOutlineColor || "#ffffff", width: 3 }),
          })
        : undefined,
    });
  }

  on(eventName, callback) {
    if (!eventName || typeof callback !== "function") return;

    if (!this.events.has(eventName)) {
      this.events.set(eventName, []);
    }

    this.events.get(eventName).push(callback);
  }

  off(eventName, callback) {
    const callbacks = this.events.get(eventName);
    if (!callbacks) return;

    const index = callbacks.indexOf(callback);
    if (index > -1) callbacks.splice(index, 1);
  }

  emit(eventName, data) {
    const callbacks = this.events.get(eventName);
    if (!callbacks) return;

    callbacks.forEach((callback) => callback(data));
  }

  showMarkerPopup(feature, screenPosition, popup = null) {
    const container =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!container || !feature) return;

    this.hidePopup();

    const marker = feature.get("rawMarker") || {};
    const geometry = feature.getGeometry?.();
    const position = marker.position || (geometry?.getCoordinates ? toLonLat(geometry.getCoordinates()) : null);
    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: {
        id: feature.getId(),
        name: feature.get("name"),
        type: "marker",
        position,
        properties: marker.data || {},
      },
      options: this.options.popup || {},
      popup,
    });
  }

  showSpatialObjectPopup(object, screenPosition) {
    const container = typeof this.options.container === "string"
      ? document.getElementById(this.options.container)
      : this.options.container;
    if (!container || !object) return;
    this.hidePopup();
    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: object,
      options: this.options.popup || {},
      popup: object.properties?.popup || null,
    });
  }

  showDrawFeaturePopup(feature, screenPosition) {
    const container =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!container || !feature) return;

    this.hidePopup();

    this.popupEl = createMapPopup({
      container,
      screenPosition,
      subject: feature,
      options: this.options.popup || {},
      popup: feature.properties?.popup || null,
    });
  }

  hidePopup() {
    if (this.popupEl) {
      this.popupEl.remove();
      this.popupEl = null;
    }
  }

  addWatermark(text) {
    if (!text) return;

    const target =
      typeof this.options.container === "string"
        ? document.getElementById(this.options.container)
        : this.options.container;

    if (!target) return;

    target.style.position = "relative";

    const watermarkEl = document.createElement("div");
    watermarkEl.innerText = text;

    Object.assign(watermarkEl.style, {
      position: "absolute",
      right: "20px",
      bottom: "20px",
      zIndex: "999",
      padding: "6px 12px",
      fontSize: "13px",
      color: "rgba(0, 0, 0, 0.45)",
      background: "rgba(255, 255, 255, 0.65)",
      borderRadius: "4px",
      pointerEvents: "none",
      userSelect: "none",
    });

    target.appendChild(watermarkEl);
    this.watermarkEl = watermarkEl;
  }

  destroy() {
    if (this.pendingZoomFrame !== null) {
      cancelAnimationFrame(this.pendingZoomFrame);
      this.pendingZoomFrame = null;
      this.pendingZoomTarget = null;
    }
    this.hidePopup();
    this.events.clear();
    this.clearMarkers();
    this.objectLayer = null;
    this.objectSource = null;
    this.spatialObjects.clear();
    this.markerLayer = null;
    this.markerSource = null;

    if (this.layerManager) {
      this.layerManager.destroy();
      this.layerManager = null;
    }

    if (this.watermarkEl) {
      this.watermarkEl.remove();
      this.watermarkEl = null;
    }

    if (this.map) {
      this.map.setTarget(null);
      this.map = null;
    }
  }
}

function createVectorOptimizedInteractions(options = {}) {
  const interactions = defaultInteractions({
    mouseWheelZoom: false,
    onFocusOnly: true,
    zoomDuration: Math.max(0, Number(options.vectorZoomDuration ?? 160)),
  });
  interactions.push(new MouseWheelZoom({
    onFocusOnly: true,
    maxDelta: Math.max(0.25, Number(options.vectorWheelMaxDelta ?? 1)),
    duration: Math.max(0, Number(options.vectorZoomDuration ?? 160)),
    timeout: Math.max(40, Number(options.vectorWheelTimeout ?? 120)),
    useAnchor: options.vectorWheelUseAnchor !== false,
    constrainResolution: options.vectorConstrainResolution !== false,
  }));
  return interactions;
}

function getObjectCoordinates(object = {}) {
  if (Array.isArray(object.position)) return [object.position];
  const coordinates = object.geometry?.coordinates;
  if (!Array.isArray(coordinates)) return [];
  return flattenCoordinates(coordinates).filter((coordinate) => Array.isArray(coordinate) && coordinate.length >= 2);
}

function flattenCoordinates(coordinates) {
  if (!Array.isArray(coordinates)) return [];
  if (typeof coordinates[0] === "number") return [coordinates];
  return coordinates.flatMap(flattenCoordinates);
}

function readNumber(...values) {
  for (const value of values) {
    if (Number.isFinite(Number(value))) return Number(value);
  }
  return 0;
}

function degreesToRadians(degrees) {
  return Number.isFinite(Number(degrees)) ? (Number(degrees) * Math.PI) / 180 : undefined;
}

function radiansToDegrees(radians) {
  return (Number(radians) * 180) / Math.PI;
}

function normalizeRadians(radians) {
  const twoPi = Math.PI * 2;
  return ((Number(radians) % twoPi) + twoPi) % twoPi;
}
