function defineArrayMethod(name, value) {
  if (Array.prototype[name]) {
    return;
  }

  Object.defineProperty(Array.prototype, name, {
    value,
    configurable: true,
    writable: true,
  });
}

defineArrayMethod("toSorted", function toSorted(compareFn) {
  return Array.prototype.slice.call(this).sort(compareFn);
});

defineArrayMethod("toReversed", function toReversed() {
  return Array.prototype.slice.call(this).reverse();
});

defineArrayMethod("toSpliced", function toSpliced(start, deleteCount, ...items) {
  const copy = Array.prototype.slice.call(this);
  copy.splice(start, deleteCount, ...items);
  return copy;
});
