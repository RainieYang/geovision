const WGS84_SEMI_MAJOR_METERS = 6378137;
const WGS84_FLATTENING = 1 / 298.257223563;
const WGS84_SEMI_MINOR_METERS = WGS84_SEMI_MAJOR_METERS * (1 - WGS84_FLATTENING);
const WGS84_AUTHALIC_RADIUS_METERS = 6371007.1809;
const TO_RADIANS = Math.PI / 180;

export function distanceMeters(left, right) {
  if (!isCoordinate(left) || !isCoordinate(right)) return 0;
  const latitude1 = Number(left[1]) * TO_RADIANS;
  const latitude2 = Number(right[1]) * TO_RADIANS;
  const longitudeDelta = (Number(right[0]) - Number(left[0])) * TO_RADIANS;
  if (Math.abs(latitude1 - latitude2) < Number.EPSILON && Math.abs(longitudeDelta) < Number.EPSILON) return 0;

  const reducedLatitude1 = Math.atan((1 - WGS84_FLATTENING) * Math.tan(latitude1));
  const reducedLatitude2 = Math.atan((1 - WGS84_FLATTENING) * Math.tan(latitude2));
  const sinU1 = Math.sin(reducedLatitude1);
  const cosU1 = Math.cos(reducedLatitude1);
  const sinU2 = Math.sin(reducedLatitude2);
  const cosU2 = Math.cos(reducedLatitude2);
  let lambda = longitudeDelta;
  let sinSigma;
  let cosSigma;
  let sigma;
  let sinAlpha;
  let cosSqAlpha;
  let cos2SigmaM;
  let converged = false;

  for (let iteration = 0; iteration < 100; iteration += 1) {
    const sinLambda = Math.sin(lambda);
    const cosLambda = Math.cos(lambda);
    sinSigma = Math.sqrt(
      (cosU2 * sinLambda) ** 2
      + (cosU1 * sinU2 - sinU1 * cosU2 * cosLambda) ** 2,
    );
    if (sinSigma === 0) return 0;
    cosSigma = sinU1 * sinU2 + cosU1 * cosU2 * cosLambda;
    sigma = Math.atan2(sinSigma, cosSigma);
    sinAlpha = cosU1 * cosU2 * sinLambda / sinSigma;
    cosSqAlpha = 1 - sinAlpha ** 2;
    cos2SigmaM = cosSqAlpha === 0 ? 0 : cosSigma - 2 * sinU1 * sinU2 / cosSqAlpha;
    const coefficient = WGS84_FLATTENING / 16 * cosSqAlpha * (4 + WGS84_FLATTENING * (4 - 3 * cosSqAlpha));
    const previousLambda = lambda;
    lambda = longitudeDelta + (1 - coefficient) * WGS84_FLATTENING * sinAlpha * (
      sigma + coefficient * sinSigma * (cos2SigmaM + coefficient * cosSigma * (-1 + 2 * cos2SigmaM ** 2))
    );
    if (Math.abs(lambda - previousLambda) <= 1e-12) {
      converged = true;
      break;
    }
  }

  if (!converged) return sphericalDistanceMeters(left, right);
  const reducedSquare = cosSqAlpha
    * (WGS84_SEMI_MAJOR_METERS ** 2 - WGS84_SEMI_MINOR_METERS ** 2)
    / WGS84_SEMI_MINOR_METERS ** 2;
  const coefficientA = 1 + reducedSquare / 16384
    * (4096 + reducedSquare * (-768 + reducedSquare * (320 - 175 * reducedSquare)));
  const coefficientB = reducedSquare / 1024
    * (256 + reducedSquare * (-128 + reducedSquare * (74 - 47 * reducedSquare)));
  const deltaSigma = coefficientB * sinSigma * (
    cos2SigmaM + coefficientB / 4 * (
      cosSigma * (-1 + 2 * cos2SigmaM ** 2)
      - coefficientB / 6 * cos2SigmaM * (-3 + 4 * sinSigma ** 2) * (-3 + 4 * cos2SigmaM ** 2)
    )
  );
  return WGS84_SEMI_MINOR_METERS * coefficientA * (sigma - deltaSigma);
}

export function lineDistanceMeters(coordinates = []) {
  if (!Array.isArray(coordinates)) return 0;
  return coordinates.reduce((total, coordinate, index) => {
    if (index === 0) return total;
    return total + distanceMeters(coordinates[index - 1], coordinate);
  }, 0);
}

export function geometryLengthMeters(geometry = {}) {
  if (geometry.type === "LineString") return lineDistanceMeters(geometry.coordinates);
  if (geometry.type === "MultiLineString") {
    return (geometry.coordinates || []).reduce((total, line) => total + lineDistanceMeters(line), 0);
  }
  return 0;
}

export function polygonAreaSquareMeters(input = []) {
  const rings = Array.isArray(input?.[0]?.[0]) ? input : [input];
  if (!rings.length) return 0;
  const outer = sphericalRingArea(rings[0]);
  const holes = rings.slice(1).reduce((total, ring) => total + sphericalRingArea(ring), 0);
  return Math.max(0, outer - holes);
}

export function geometryAreaSquareMeters(geometry = {}) {
  if (geometry.type === "Polygon") return polygonAreaSquareMeters(geometry.coordinates);
  if (geometry.type === "MultiPolygon") {
    return (geometry.coordinates || []).reduce((total, polygon) => total + polygonAreaSquareMeters(polygon), 0);
  }
  return 0;
}

export function formatDistance(meters, units = "metric") {
  if (!Number.isFinite(meters)) return "";
  if (units === "imperial") {
    const feet = meters * 3.280839895;
    return feet >= 5280 ? `${(feet / 5280).toFixed(2)}英里` : `${feet.toFixed(2)}英尺`;
  }
  if (meters >= 1000) return `${(meters / 1000).toFixed(2)}公里`;
  return `${meters.toFixed(2)}米`;
}

export function formatArea(squareMeters, units = "metric") {
  if (!Number.isFinite(squareMeters)) return "";
  if (units === "imperial") {
    const squareFeet = squareMeters * 10.763910417;
    const squareMileFeet = 27878400;
    return squareFeet >= squareMileFeet
      ? `${(squareFeet / squareMileFeet).toFixed(4)}平方英里`
      : `${squareFeet.toFixed(2)}平方英尺`;
  }
  if (squareMeters >= 1000000) return `${(squareMeters / 1000000).toFixed(4)}平方公里`;
  return `${squareMeters.toFixed(2)}平方米`;
}

function sphericalRingArea(ring = []) {
  if (!Array.isArray(ring) || ring.length < 3) return 0;
  let sum = 0;
  for (let index = 0; index < ring.length; index += 1) {
    const current = ring[index];
    const next = ring[(index + 1) % ring.length];
    if (!isCoordinate(current) || !isCoordinate(next)) continue;
    let longitudeDelta = (Number(next[0]) - Number(current[0])) * TO_RADIANS;
    if (longitudeDelta > Math.PI) longitudeDelta -= Math.PI * 2;
    if (longitudeDelta < -Math.PI) longitudeDelta += Math.PI * 2;
    sum += longitudeDelta * (2 + Math.sin(Number(current[1]) * TO_RADIANS) + Math.sin(Number(next[1]) * TO_RADIANS));
  }
  return Math.abs(sum * WGS84_AUTHALIC_RADIUS_METERS * WGS84_AUTHALIC_RADIUS_METERS / 2);
}

function sphericalDistanceMeters(left, right) {
  const latitudeDelta = (Number(right[1]) - Number(left[1])) * TO_RADIANS;
  const longitudeDelta = (Number(right[0]) - Number(left[0])) * TO_RADIANS;
  const latitude1 = Number(left[1]) * TO_RADIANS;
  const latitude2 = Number(right[1]) * TO_RADIANS;
  const haversine = Math.sin(latitudeDelta / 2) ** 2
    + Math.cos(latitude1) * Math.cos(latitude2) * Math.sin(longitudeDelta / 2) ** 2;
  return 2 * WGS84_AUTHALIC_RADIUS_METERS * Math.asin(Math.min(1, Math.sqrt(haversine)));
}

function isCoordinate(value) {
  return Array.isArray(value) && Number.isFinite(Number(value[0])) && Number.isFinite(Number(value[1]));
}
