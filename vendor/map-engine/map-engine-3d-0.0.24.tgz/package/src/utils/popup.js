import {
  formatArea,
  formatDistance,
  geometryAreaSquareMeters,
  geometryLengthMeters,
} from "./geometryMetrics";

export function resolvePopupOffset(popup, fallback = [12, 12]) {
  const offset = Array.isArray(popup?.offset) ? popup.offset : fallback;
  const x = Number(offset[0]);
  const y = Number(offset[1]);
  return [Number.isFinite(x) ? x : fallback[0], Number.isFinite(y) ? y : fallback[1]];
}

export function resolvePopupDraggable(popup, options = {}) {
  if (typeof popup?.draggable === "boolean") return popup.draggable;
  if (typeof options.draggable === "boolean") return options.draggable;
  return true;
}

export function createMapPopup({ container, screenPosition, subject, options = {}, popup = null }) {
  if (!container || !subject || options.enabled === false || popup?.enabled === false) return null;
  const popupEl = document.createElement("div");
  popupEl.className = `map-engine-popup map-engine-popup--${options.theme || "military"}`;
  popupEl.dataset.mapObjectId = String(subject.id ?? subject.properties?.id ?? "");
  const [x, y] = normalizeScreenPosition(screenPosition);
  const [offsetX, offsetY] = resolvePopupOffset(popup);
  Object.assign(popupEl.style, {
    position: "absolute",
    left: `${x + offsetX}px`,
    top: `${y + offsetY}px`,
    zIndex: "1300",
    pointerEvents: "auto",
  }, popup?.style || {});

  if (typeof popup?.html === "string") {
    popupEl.classList.add("map-engine-popup--custom");
    popupEl.innerHTML = popup.html;
  } else {
    popupEl.innerHTML = createDefaultPopupHtml(subject, options, popup);
    popupEl.querySelector("[data-map-popup-close]")?.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      popupEl.remove();
    });
  }

  appendPopupActions(popupEl, subject, options, popup);

  container.appendChild(popupEl);
  clampPopupToContainer(popupEl, container);
  makePopupDraggable(popupEl, container, {
    ...(popup || {}),
    draggable: resolvePopupDraggable(popup, options),
  });
  return popupEl;
}

export function resolvePopupActions(subject, options = {}, popup = null) {
  const normalized = normalizePopupSubject(subject);
  const actions = [
    ...(Array.isArray(options?.actions) ? options.actions : []),
    ...(Array.isArray(popup?.actions) ? popup.actions : []),
  ];

  return actions.filter((action) => {
    if (!action || action.hidden === true || typeof action.onClick !== "function") return false;
    if (typeof action.visible !== "function") return true;
    return action.visible(normalized, subject) !== false;
  });
}

function appendPopupActions(popupEl, subject, options, popup) {
  const actions = resolvePopupActions(subject, options, popup);
  if (!actions.length) return;

  const normalized = normalizePopupSubject(subject);
  const actionBar = document.createElement("div");
  actionBar.className = "map-engine-popup__actions";

  actions.forEach((action, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `map-engine-popup__action${action.primary === false ? "" : " is-primary"}`;
    button.dataset.mapPopupAction = String(action.id || index);
    button.textContent = String(action.label || "操作");
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      action.onClick(normalized, { subject, popupEl });
      if (action.closeOnClick !== false) popupEl.remove();
    });
    actionBar.appendChild(button);
  });

  popupEl.appendChild(actionBar);
}

export function createDefaultPopupHtml(subject, options = {}, popup = null) {
  const normalized = normalizePopupSubject(subject);
  const title = escapeHtml(popup?.title || normalized.name || defaultTitle(normalized.type));
  const rows = [
    ["ID", normalized.id || "--"],
    ["类型", formatGeometryType(normalized.type)],
    ...createMetricRows(normalized, options),
  ];
  return `
    <div class="map-engine-popup__accent"></div>
    <div class="map-engine-popup__header" data-popup-drag-handle>
      <span class="map-engine-popup__glyph"></span>
      <strong>${title}</strong>
      <button type="button" class="map-engine-popup__close" data-map-popup-close aria-label="关闭">×</button>
    </div>
    <div class="map-engine-popup__grid">
      ${rows.map(([label, value]) => `
        <span class="map-engine-popup__label">${escapeHtml(label)}</span>
        <strong class="map-engine-popup__value">${escapeHtml(value)}</strong>
      `).join("")}
    </div>
  `;
}

export function normalizePopupSubject(subject = {}) {
  const properties = subject.properties || {};
  const geometry = subject.geometry || (subject.position
    ? { type: "Point", coordinates: subject.position }
    : null);
  const type = normalizeGeometryType(subject.type, geometry?.type, properties.shapeType);
  return {
    id: String(subject.id ?? properties.id ?? "--"),
    name: properties.name || subject.name || properties.title,
    type,
    geometry,
    position: subject.position || (geometry?.type === "Point" ? geometry.coordinates : null),
    radius: Number(properties.radius ?? subject.style?.radius),
  };
}

export function makePopupDraggable(popupEl, container, popup = null) {
  if (!popup?.draggable || !popupEl || !container) return;
  const handle = popupEl.querySelector(popup.dragHandle || "[data-popup-drag-handle]") || popupEl;
  handle.style.cursor = "move";
  handle.style.userSelect = "none";
  handle.style.touchAction = "none";

  handle.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || event.target?.closest?.("[data-map-popup-close]")) return;
    event.preventDefault();
    event.stopPropagation();
    const startX = event.clientX;
    const startY = event.clientY;
    const startLeft = popupEl.offsetLeft;
    const startTop = popupEl.offsetTop;
    handle.setPointerCapture?.(event.pointerId);

    const move = (moveEvent) => {
      moveEvent.preventDefault();
      moveEvent.stopPropagation();
      const maxLeft = Math.max(0, container.clientWidth - popupEl.offsetWidth);
      const maxTop = Math.max(0, container.clientHeight - popupEl.offsetHeight);
      popupEl.style.left = `${Math.min(maxLeft, Math.max(0, startLeft + moveEvent.clientX - startX))}px`;
      popupEl.style.top = `${Math.min(maxTop, Math.max(0, startTop + moveEvent.clientY - startY))}px`;
    };
    const stop = (stopEvent) => {
      stopEvent.stopPropagation();
      handle.removeEventListener("pointermove", move);
      handle.removeEventListener("pointerup", stop);
      handle.removeEventListener("pointercancel", stop);
    };
    handle.addEventListener("pointermove", move);
    handle.addEventListener("pointerup", stop);
    handle.addEventListener("pointercancel", stop);
  });
}

function createMetricRows(subject, options) {
  const units = options.units === "imperial" ? "imperial" : "metric";
  const precision = Number.isInteger(Number(options.coordinatePrecision))
    ? Math.max(0, Math.min(10, Number(options.coordinatePrecision)))
    : 6;
  if (subject.type === "Point" && subject.position) {
    const rows = [
      ["经度", Number(subject.position[0]).toFixed(precision)],
      ["纬度", Number(subject.position[1]).toFixed(precision)],
    ];
    if (Number.isFinite(Number(subject.position[2]))) rows.push(["高度", `${Number(subject.position[2]).toFixed(1)}米`]);
    return rows;
  }
  if (subject.type === "LineString" || subject.type === "MultiLineString") {
    return [["距离", formatDistance(geometryLengthMeters(subject.geometry), units)]];
  }
  if (subject.type === "Circle") {
    const rows = [];
    if (Number.isFinite(subject.radius)) rows.push(["半径", formatDistance(subject.radius, units)]);
    if (Number.isFinite(subject.radius)) rows.push(["面积", formatArea(Math.PI * subject.radius * subject.radius, units)]);
    return rows;
  }
  if (subject.type === "Polygon" || subject.type === "MultiPolygon" || subject.type === "Rectangle") {
    return [["面积", formatArea(geometryAreaSquareMeters(subject.geometry), units)]];
  }
  return [];
}

function normalizeGeometryType(objectType, geometryType, shapeType) {
  if (shapeType === "Circle" || objectType === "circle") return "Circle";
  if (shapeType === "Rectangle") return "Rectangle";
  const aliases = { marker: "Point", text: "Point", line: "LineString", polygon: "Polygon" };
  return aliases[objectType] || geometryType || objectType || "Unknown";
}

function formatGeometryType(type) {
  const labels = {
    Point: "点",
    LineString: "线",
    MultiLineString: "多线",
    Polygon: "面",
    MultiPolygon: "多面",
    Circle: "圆",
    Rectangle: "矩形",
  };
  return labels[type] || type || "--";
}

function defaultTitle(type) {
  return type === "Point" ? "未命名点位" : "未命名图形";
}

function normalizeScreenPosition(position) {
  if (Array.isArray(position)) return [Number(position[0]) || 0, Number(position[1]) || 0];
  return [Number(position?.x) || 0, Number(position?.y) || 0];
}

function clampPopupToContainer(popupEl, container) {
  const maxLeft = Math.max(0, container.clientWidth - popupEl.offsetWidth - 4);
  const maxTop = Math.max(0, container.clientHeight - popupEl.offsetHeight - 4);
  popupEl.style.left = `${Math.min(maxLeft, Math.max(4, popupEl.offsetLeft))}px`;
  popupEl.style.top = `${Math.min(maxTop, Math.max(4, popupEl.offsetTop))}px`;
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
  })[character]);
}
