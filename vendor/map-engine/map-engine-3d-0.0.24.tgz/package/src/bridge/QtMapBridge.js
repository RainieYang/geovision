const DEFAULT_EVENT_NAMES = [
  "state:changed",
  "object:click",
  "object:hover",
  "view:change",
  "layer:change",
  "replay:exit",
  "replay:load",
  "replay:seek",
  "replay:play",
  "replay:pause",
  "replay:tick",
  "replay:complete",
  "replay:error",
  "runtime-track:add",
  "runtime-track:update",
  "runtime-track:append",
  "runtime-track:remove",
  "runtime-track:clear",
  "animation:start",
  "animation:stop",
  "animation:complete",
  "animation:clear",
  "temporal:sample",
  "click",
  "draw:create",
  "draw:select",
  "draw:unselect",
  "draw:update",
  "draw:delete",
  "draw:clear",
  "fence:create",
  "fence:update",
  "fence:delete",
  "fence:enable",
  "fence:disable",
  "fence:enter",
  "fence:leave",
  "measure:create",
  "measure:clear",
  "track:load",
  "track:play",
  "track:pause",
  "track:resume",
  "track:stop",
  "track:tick",
  "track:complete",
  "track:clear",
  "cluster:click",
  "cluster:expand",
  "cluster:enable",
  "cluster:disable",
  "plot:create",
  "plot:select",
  "plot:unselect",
  "plot:update",
  "plot:delete",
  "plot:clear",
  "radar:create",
  "radar:update",
  "radar:delete",
  "radar:clear",
  "radar:scan-start",
  "radar:scan-stop",
  "radar:target-update",
  "radar:target-track",
  "radar:target-link",
  "heatmap:update",
  "heatmap:clear",
  "heatmap:show",
  "heatmap:hide",
];

const ACTIONS = {
  setState: (map, payload) => map.setState(payload),
  getState: (map) => map.getState(),
  applyPatch: (map, payload) => map.applyPatch(payload),
  exportSnapshot: (map) => map.exportSnapshot(),
  importSnapshot: (map, payload) => map.importSnapshot(payload),
  getType: (map) => map.getType(),
  getStatus: (map) => map.getStatus(),
  switchView: (map, payload) => map.switchView(payload?.type || payload),
  centerAt: (map, payload) => map.centerAt(payload?.position || payload, payload?.options),
  resetView: (map) => map.resetView(),
  zoomIn: (map) => map.zoomIn(),
  zoomOut: (map) => map.zoomOut(),
  getCameraOrientation: (map) => map.getCameraOrientation(),
  setCameraOrientation: (map, payload) => map.setCameraOrientation(payload),
  resetCameraOrientation: (map) => map.resetCameraOrientation(),

  setBaseLayer: (map, payload) => map.setBaseLayer(payload),
  addLayer: (map, payload) => map.addLayer(payload),
  addLayers: (map, payload) => map.addLayers(payload?.layers || payload),
  removeLayer: (map, payload) => map.removeLayer(payload?.id || payload),
  getLayerInfo: (map, payload) => map.getLayerInfo(payload?.id || payload),
  listLayers: (map) => map.listLayers(),
  hasLayer: (map, payload) => map.hasLayer(payload?.id || payload),
  showLayer: (map, payload) => map.showLayer(payload?.id || payload),
  hideLayer: (map, payload) => map.hideLayer(payload?.id || payload),
  setLayerVisible: (map, payload) => map.setLayerVisible(payload?.id, payload?.visible),
  setLayerOpacity: (map, payload) => map.setLayerOpacity(payload?.id, payload?.opacity),
  setLayerZIndex: (map, payload) => map.setLayerZIndex(payload?.id, payload?.zIndex),
  clearLayers: (map) => map.clearLayers(),
  clearBaseLayers: (map) => map.clearBaseLayers(),
  getBaseLayerIds: (map) => map.getBaseLayerIds(),

  enterReplay: (map, payload) => map.enterReplay(payload),
  exitReplay: (map, payload) => map.exitReplay(payload),
  loadReplay: (map, payload) => map.loadReplay(payload),
  seek: (map, payload) => map.seek(payload?.time ?? payload),
  play: (map, payload) => map.play(payload),
  pause: (map) => map.pause(),
  stop: (map) => map.stop(),
  setSpeed: (map, payload) => map.setSpeed(payload?.speed ?? payload),
  setLoop: (map, payload) => map.setLoop(payload?.loop ?? payload),
  getReplayState: (map) => map.getReplayState(),
  setTemporalState: (map, payload) => map.setTemporalState(payload?.temporal || payload),
  applyTemporalAt: (map, payload) => map.applyTemporalAt(payload?.time ?? payload),

  addTrackRuntime: (map, payload) => map.addTrack(payload),
  updateTrackRuntime: (map, payload) => map.updateTrack(payload?.id, payload?.patch || payload),
  appendTrackPoint: (map, payload) => map.appendTrackPoint(payload?.id, payload?.point, payload?.options),
  removeTrackRuntime: (map, payload) => map.removeTrack(payload?.id || payload),
  clearTracksRuntime: (map) => map.clearTracks(),
  listTracksRuntime: (map) => map.listTracks(),
  getTrackRuntime: (map, payload) => map.getTrack(payload?.id || payload),

  moveObject: (map, payload) => map.moveObject(payload?.id, payload?.options || payload),
  blinkObject: (map, payload) => map.blinkObject(payload?.id, payload?.options || payload),
  pulseCoverage: (map, payload) => map.pulseCoverage(payload?.id, payload?.options || payload),
  stopAnimation: (map, payload) => map.stopAnimation(payload?.id || payload),
  clearAnimations: (map) => map.clearAnimations(),

  addHeatmapLayer: (map, payload) => map.addHeatmapLayer(payload?.id, payload?.points, payload?.options),
  addCoverage: (map, payload) => map.addCoverage(payload?.id, payload),
  updateCoverage: (map, payload) => map.updateCoverage(payload?.id, payload),
  removeCoverage: (map, payload) => map.removeCoverage(payload?.id || payload),
  addSector: (map, payload) => map.addSector(payload?.id, payload),
  updateSector: (map, payload) => map.updateSector(payload?.id, payload),
  removeSector: (map, payload) => map.removeSector(payload?.id || payload),
  addDirectionLine: (map, payload) => map.addDirectionLine(payload?.id, payload),
  updateDirectionLine: (map, payload) => map.updateDirectionLine(payload?.id, payload),
  removeDirectionLine: (map, payload) => map.removeDirectionLine(payload?.id || payload),

  addLayerGroup: (map, payload) => map.addLayerGroup(payload),
  updateLayerGroup: (map, payload) => map.updateLayerGroup(payload?.id, payload?.patch || payload),
  removeLayerGroup: (map, payload) => map.removeLayerGroup(payload?.id || payload),
  setLayerGroupVisible: (map, payload) => map.setLayerGroupVisible(payload?.id, payload?.visible),
  listLayerGroups: (map) => map.listLayerGroups(),
  queryFeatureAtPixel: (map, payload) => map.queryFeatureAtPixel(payload?.pixel || payload, payload?.options),
  queryObjectsByBounds: (map, payload) => map.queryObjectsByBounds(payload?.bounds || payload, payload?.options),
  queryObjectsByPoint: (map, payload) => map.queryObjectsByPoint(payload?.point || payload, payload?.options),

  addMarker: (map, payload) => map.addMarker(payload),
  addMarkers: (map, payload) => map.addMarkers(payload?.markers || payload),
  updateMarker: (map, payload) => map.updateMarker(payload?.id, payload?.patch || payload?.marker || payload),
  removeMarker: (map, payload) => map.removeMarker(payload?.id || payload),
  removeMarkers: (map, payload) => map.removeMarkers(payload?.ids || payload),
  getMarker: (map, payload) => map.getMarker(payload?.id || payload),
  hasMarker: (map, payload) => map.hasMarker(payload?.id || payload),
  listMarkers: (map) => map.listMarkers(),
  clearMarkers: (map) => map.clearMarkers(),

  enableCluster: (map, payload) => map.enableCluster(payload),
  disableCluster: (map) => map.disableCluster(),
  isClusterEnabled: (map) => map.isClusterEnabled(),
  setClusterOptions: (map, payload) => map.setClusterOptions(payload),
  refreshCluster: (map) => map.refreshCluster(),
  getClusterState: (map) => map.getClusterState(),

  drawPoint: (map, payload) => map.drawPoint(payload),
  drawLine: (map, payload) => map.drawLine(payload),
  drawPolygon: (map, payload) => map.drawPolygon(payload),
  drawRectangle: (map, payload) => map.drawRectangle(payload),
  drawCircle: (map, payload) => map.drawCircle(payload),
  enableDrawSelect: (map) => map.enableDrawSelect(),
  enableDrawEdit: (map) => map.enableDrawEdit(),
  selectDrawing: (map, payload) => map.selectDrawing(payload?.id || payload),
  unselectDrawing: (map) => map.unselectDrawing(),
  getSelectedDrawing: (map) => map.getSelectedDrawing(),
  removeDrawing: (map, payload) => map.removeDrawing(payload?.id || payload),
  removeSelectedDrawing: (map) => map.removeSelectedDrawing(),
  updateDrawingProperties: (map, payload) =>
    map.updateDrawingProperties(payload?.id, payload?.properties || payload?.patch || payload),
  updateSelectedDrawingProperties: (map, payload) => map.updateSelectedDrawingProperties(payload?.properties || payload),
  clearDrawings: (map) => map.clearDrawings(),
  listDrawings: (map) => map.listDrawings(),
  exportGeoJSON: (map) => map.exportGeoJSON(),
  importGeoJSON: (map, payload) => map.importGeoJSON(payload?.geojson || payload),

  drawCommandPost: (map, payload) => map.drawCommandPost(payload),
  drawRoute: (map, payload) => map.drawRoute(payload),
  drawAssemblyArea: (map, payload) => map.drawAssemblyArea(payload),
  drawDefenseArea: (map, payload) => map.drawDefenseArea(payload),
  drawAttackArrow: (map, payload) => map.drawAttackArrow(payload),
  enablePlotSelect: (map) => map.enablePlotSelect(),
  selectPlot: (map, payload) => map.selectPlot(payload?.id || payload),
  unselectPlot: (map) => map.unselectPlot(),
  getSelectedPlot: (map) => map.getSelectedPlot(),
  removePlot: (map, payload) => map.removePlot(payload?.id || payload),
  removeSelectedPlot: (map) => map.removeSelectedPlot(),
  clearPlots: (map) => map.clearPlots(),
  listPlots: (map) => map.listPlots(),
  updatePlotProperties: (map, payload) =>
    map.updatePlotProperties(payload?.id, payload?.properties || payload?.patch || payload),
  updateSelectedPlotProperties: (map, payload) => map.updateSelectedPlotProperties(payload?.properties || payload),
  exportPlots: (map) => map.exportPlots(),
  importPlots: (map, payload) => map.importPlots(payload?.geojson || payload),

  createFenceFromDrawing: (map, payload) => map.createFenceFromDrawing(payload?.id, payload?.options),
  createFenceFromSelectedDrawing: (map, payload) => map.createFenceFromSelectedDrawing(payload),
  listFences: (map) => map.listFences(),
  getFence: (map, payload) => map.getFence(payload?.id || payload?.fenceId || payload),
  removeFence: (map, payload) => map.removeFence(payload?.id || payload?.fenceId || payload),
  enableFence: (map, payload) => map.enableFence(payload?.id || payload?.fenceId || payload),
  disableFence: (map, payload) => map.disableFence(payload?.id || payload?.fenceId || payload),
  exportFences: (map) => map.exportFences(),
  importFences: (map, payload) => map.importFences(payload?.geojson || payload),
  checkFencePoint: (map, payload) => map.checkFencePoint(payload),
  checkFencePoints: (map, payload) => map.checkFencePoints(payload?.targets || payload),

  measureDistance: (map, payload) => map.measureDistance(payload),
  measureArea: (map, payload) => map.measureArea(payload),
  clearMeasurements: (map) => map.clearMeasurements(),
  exportMeasurements: (map) => map.exportMeasurements(),
  importMeasurements: (map, payload) => map.importMeasurements(payload?.geojson || payload),
  listMeasurements: (map) => map.listMeasurements(),

  loadTrack: (map, payload) => map.loadTrack(payload?.track || payload, payload?.options),
  playTrack: (map) => map.playTrack(),
  pauseTrack: (map) => map.pauseTrack(),
  resumeTrack: (map) => map.resumeTrack(),
  stopTrack: (map) => map.stopTrack(),
  seekTrack: (map, payload) => map.seekTrack(payload?.progress ?? payload),
  setTrackSpeed: (map, payload) => map.setTrackSpeed(payload?.speed ?? payload),
  setTrackFollow: (map, payload) => map.setTrackFollow(payload?.enabled, payload?.options),
  clearTrack: (map) => map.clearTrack(),
  getTrackState: (map) => map.getTrackState(),

  addRadar: (map, payload) => map.addRadar(payload),
  addRadars: (map, payload) => map.addRadars(payload?.radars || payload),
  removeRadar: (map, payload) => map.removeRadar(payload?.id || payload?.radarId || payload),
  clearRadars: (map) => map.clearRadars(),
  updateRadar: (map, payload) => map.updateRadar(payload?.id || payload?.radarId, payload?.patch || payload),
  getRadar: (map, payload) => map.getRadar(payload?.id || payload?.radarId || payload),
  listRadars: (map) => map.listRadars(),
  startRadarScan: (map, payload) => map.startRadarScan(payload?.id || payload?.radarId || payload),
  stopRadarScan: (map, payload) => map.stopRadarScan(payload?.id || payload?.radarId || payload),
  setRadarScanAngle: (map, payload) => map.setRadarScanAngle(payload?.id || payload?.radarId, payload?.angle),
  setRadarTargets: (map, payload) => map.setRadarTargets(payload?.radarId || payload?.id, payload?.targets),
  addRadarTarget: (map, payload) => map.addRadarTarget(payload?.radarId || payload?.id, payload?.target),
  removeRadarTarget: (map, payload) => map.removeRadarTarget(payload?.radarId || payload?.id, payload?.targetId),
  clearRadarTargets: (map, payload) => map.clearRadarTargets(payload?.radarId || payload?.id || payload),
  clearRadarTargetTrail: (map, payload) => map.clearRadarTargetTrail(payload?.radarId || payload?.id, payload?.targetId),
  clearRadarTrails: (map, payload) => map.clearRadarTrails(payload?.radarId || payload?.id || payload),
  trackRadarTarget: (map, payload) => map.trackRadarTarget(payload?.radarId || payload?.id, payload?.targetId),
  untrackRadarTarget: (map, payload) => map.untrackRadarTarget(payload?.radarId || payload?.id || payload),
  linkRadarTargetToMarker: (map, payload) =>
    map.linkRadarTargetToMarker(payload?.radarId || payload?.id, payload?.targetId, payload?.markerId),
  exportRadars: (map) => map.exportRadars(),
  importRadars: (map, payload) => map.importRadars(payload?.data || payload),

  setHeatmapData: (map, payload) => map.setHeatmapData(payload?.points || payload, payload?.options),
  addHeatmapPoint: (map, payload) => map.addHeatmapPoint(payload),
  addHeatmapPoints: (map, payload) => map.addHeatmapPoints(payload?.points || payload),
  updateHeatmapPoint: (map, payload) => map.updateHeatmapPoint(payload?.id, payload?.patch || payload),
  removeHeatmapPoint: (map, payload) => map.removeHeatmapPoint(payload?.id || payload),
  clearHeatmap: (map) => map.clearHeatmap(),
  showHeatmap: (map) => map.showHeatmap(),
  hideHeatmap: (map) => map.hideHeatmap(),
  setHeatmapOptions: (map, payload) => map.setHeatmapOptions(payload),
  listHeatmapPoints: (map) => map.listHeatmapPoints(),
  exportHeatmap: (map) => map.exportHeatmap(),
  importHeatmap: (map, payload) => map.importHeatmap(payload?.data || payload),

  addPolyline: (map, payload) => map.addPolyline(payload),
  removePolyline: (map, payload) => map.removePolyline(payload?.id || payload),
  clearPolylines: (map) => map.clearPolylines(),
};

export function createQtMapBridge(map, options = {}) {
  const bridge = {
    map,
    eventNames: options.eventNames || DEFAULT_EVENT_NAMES,
    eventCleanups: [],

    bind(nextMap) {
      bridge.eventCleanups.forEach((cleanup) => cleanup?.());
      bridge.eventCleanups = [];
      bridge.map = nextMap;
      bridge.bindEvents();
      return bridge;
    },

    call(action, payload = null) {
      try {
        const handler = ACTIONS[action];
        if (!handler) {
          return bridge.createError(`Unsupported action: ${action}`);
        }

        return bridge.createSuccess(handler(bridge.map, payload));
      } catch (error) {
        console.error("QtMapBridge call failed", { action, payload, error });
        return bridge.createError(error?.message || String(error), error);
      }
    },

    emitToQt(eventName, data) {
      const message = {
        type: "event",
        name: eventName,
        data: bridge.toPlainData(data),
        timestamp: Date.now(),
      };

      const qtHost = window.qtMapBridgeHost || window.qtBridge || window.bridgeHost;
      if (qtHost?.onMapEvent) {
        qtHost.onMapEvent(JSON.stringify(message));
      }

      if (typeof window.onQtMapEvent === "function") {
        window.onQtMapEvent(message);
      }

      window.dispatchEvent(new CustomEvent("qt-map-event", { detail: message }));
    },

    bindEvents() {
      bridge.eventNames.forEach((eventName) => {
        const cleanup = bridge.map?.on?.(eventName, (data) => bridge.emitToQt(eventName, data));
        if (typeof cleanup === "function") bridge.eventCleanups.push(cleanup);
      });
    },

    createSuccess(data) {
      return {
        ok: true,
        data: bridge.toPlainData(data),
      };
    },

    createError(message, error = null) {
      return {
        ok: false,
        message,
        error: error
          ? {
              name: error.name,
              stack: error.stack,
            }
          : null,
      };
    },

    toPlainData(data) {
      if (data == null) return data;
      if (typeof data === "string" || typeof data === "number" || typeof data === "boolean") return data;

      try {
        return JSON.parse(JSON.stringify(data));
      } catch {
        return String(data);
      }
    },
  };

  bridge.bind(map);
  return bridge;
}

export function registerQtMapBridge(map, options = {}) {
  const bridge = createQtMapBridge(map, options);
  window.QtMapBridge = bridge;
  setupQtWebChannel(options);
  return bridge;
}

function setupQtWebChannel(options = {}) {
  const hostName = options.hostName || "qtMapBridgeHost";
  if (!window.qt?.webChannelTransport) return;

  const initialize = () => {
    if (!window.QWebChannel) return;

    new window.QWebChannel(window.qt.webChannelTransport, (channel) => {
      window.qtWebChannel = channel;
      window.qtMapBridgeHost = channel.objects?.[hostName] || null;
      window.dispatchEvent(
        new CustomEvent("qt-map-bridge-ready", {
          detail: {
            hostName,
            hasHost: Boolean(window.qtMapBridgeHost),
          },
        })
      );
    });
  };

  if (window.QWebChannel) {
    initialize();
    return;
  }

  const script = document.createElement("script");
  script.src = "qrc:///qtwebchannel/qwebchannel.js";
  script.onload = initialize;
  script.onerror = () => {
    console.warn("QtMapBridge: failed to load qwebchannel.js");
  };
  document.head.appendChild(script);
}
