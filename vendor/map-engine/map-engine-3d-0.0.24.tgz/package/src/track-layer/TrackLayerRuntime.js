import { clone, normalizeTrack, normalizeTrackPoint } from "../state/utils";

export default class TrackLayerRuntime {
  constructor(mapEngine) {
    this.mapEngine = mapEngine;
    this.tracks = new Map();
  }

  addTrack(track = {}) {
    const next = normalizeTrack(track);
    if (!next) return null;
    this.tracks.set(next.id, next);
    this.mapEngine.applyPatch({
      addTracks: [next],
      add: this.trackToObjects(next),
    });
    this.mapEngine.emit("runtime-track:add", clone(next));
    return clone(next);
  }

  updateTrack(id, patch = {}) {
    const trackId = String(id || patch.id || "");
    const previous = this.tracks.get(trackId) || this.getStoredTrack(trackId);
    if (!previous) return null;
    const next = normalizeTrack({ ...previous, ...patch, id: trackId });
    this.tracks.set(next.id, next);
    this.mapEngine.applyPatch({
      updateTracks: [next],
      update: this.trackToObjects(next),
    });
    this.mapEngine.emit("runtime-track:update", clone(next));
    return clone(next);
  }

  appendTrackPoint(id, point = {}, options = {}) {
    const trackId = String(id);
    const previous = this.tracks.get(trackId) || this.getStoredTrack(trackId);
    if (!previous) return null;
    const nextPoint = normalizeTrackPoint(point);
    if (!nextPoint) return clone(previous);
    const maxTailPoints = options.maxTailPoints ?? previous.maxTailPoints;
    const points = [...(previous.points || []), nextPoint];
    const next = normalizeTrack({
      ...previous,
      points: Number.isFinite(Number(maxTailPoints)) ? points.slice(-Number(maxTailPoints)) : points,
    });
    this.tracks.set(trackId, next);
    this.mapEngine.applyPatch({
      updateTracks: [next],
      update: this.trackToObjects(next),
    });
    this.mapEngine.emit("runtime-track:append", { id: trackId, point: clone(nextPoint), track: clone(next) });
    return clone(next);
  }

  removeTrack(id) {
    const trackId = String(id);
    this.tracks.delete(trackId);
    this.mapEngine.applyPatch({
      removeTracks: [trackId],
      remove: this.getTrackObjectIds(trackId),
    });
    this.mapEngine.emit("runtime-track:remove", { id: trackId });
    return true;
  }

  clearTracks() {
    const ids = new Set([
      ...Array.from(this.tracks.keys()),
      ...this.getStoredTracks().map((track) => track.id),
    ]);
    const objectIds = Array.from(ids).flatMap((id) => this.getTrackObjectIds(id));
    this.tracks.clear();
    this.mapEngine.applyPatch({
      removeTracks: Array.from(ids),
      remove: objectIds,
    });
    this.mapEngine.emit("runtime-track:clear", { ids: Array.from(ids) });
    return true;
  }

  getTrack(id) {
    return clone(this.tracks.get(String(id)) || this.getStoredTrack(id));
  }

  listTracks() {
    const merged = new Map(this.getStoredTracks().map((track) => [track.id, track]));
    this.tracks.forEach((track, id) => merged.set(id, track));
    return Array.from(merged.values()).map(clone);
  }

  getStoredTrack(id) {
    return this.mapEngine.store?.getTrack?.(id) || this.getStoredTracks().find((track) => track.id === String(id)) || null;
  }

  getStoredTracks() {
    return this.mapEngine.store?.listTracks?.() || this.mapEngine.getState?.().tracks || [];
  }

  trackToObjects(track = {}) {
    const points = Array.isArray(track.points) ? track.points : [];
    const coordinates = points.map((point) => point.position).filter(Boolean);
    const objects = [];
    const baseProperties = {
      ...(track.properties || {}),
      runtimeType: "track",
      trackId: track.id,
    };

    if (coordinates.length >= 2) {
      objects.push({
        id: getTrackObjectId(track.id, "line"),
        type: "line",
        geometry: { type: "LineString", coordinates },
        style: {
          strokeColor: track.style?.strokeColor || track.style?.color || "#22d3ee",
          strokeWidth: track.style?.strokeWidth ?? 3,
          ...(track.style?.line || {}),
        },
        properties: baseProperties,
      });
    }

    if (track.showCurrent !== false && coordinates.length) {
      const current = coordinates[coordinates.length - 1];
      objects.push({
        id: getTrackObjectId(track.id, "current"),
        type: "marker",
        position: current,
        style: {
          color: track.style?.currentColor || track.style?.color || "#f97316",
          ...(track.style?.current || {}),
        },
        properties: {
          ...baseProperties,
          current: true,
        },
      });
    }

    return objects;
  }

  getTrackObjectIds(id) {
    return [getTrackObjectId(id, "line"), getTrackObjectId(id, "current")];
  }
}

export function getTrackObjectId(id, part) {
  return `runtime-track:${id}:${part}`;
}
