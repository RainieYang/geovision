export default class CesiumTrackAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.entity = null;
  }

  destroy() {
    this.clear();
  }

  renderTrack(track) {
    this.clear();
    const coordinates = normalizeTrackCoordinates(track);
    if (coordinates.length < 2) return null;

    this.entity = this.viewer.entities.add({
      id: `${track.id || "track"}-line`,
      polyline: {
        positions: this.CesiumLib.Cartesian3.fromDegreesArray(coordinates.flat()),
        width: this.options.width || 4,
        material: this.CesiumLib.Color.fromCssColorString(this.options.color || "#22c55e"),
        clampToGround: true,
      },
      properties: {
        trackId: track.id || "track",
      },
    });
    this.viewer.scene.requestRender?.();
    return this.entity;
  }

  clear() {
    if (this.entity) {
      this.viewer.entities.remove(this.entity);
      this.entity = null;
      this.viewer.scene.requestRender?.();
    }
  }
}

function normalizeTrackCoordinates(track) {
  return (track?.points || [])
    .map((point) => [point.lng ?? point[0], point.lat ?? point[1]])
    .filter((coordinate) => Number.isFinite(coordinate[0]) && Number.isFinite(coordinate[1]));
}
