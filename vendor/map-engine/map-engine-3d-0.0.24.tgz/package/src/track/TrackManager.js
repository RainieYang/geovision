import CesiumTrackAdapter from "./CesiumTrackAdapter";
import OpenLayersTrackAdapter from "./OpenLayersTrackAdapter";

const DEFAULT_SPEED_KMH = 2000;
const DEFAULT_FOLLOW_THROTTLE = 220;

export default class TrackManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = options;
    this.adapter = this.createAdapter(engine, options);
    this.track = null;
    this.currentIndex = 0;
    this.currentDistance = 0;
    this.playStartedAt = 0;
    this.playStartedDistance = 0;
    this.interpolatedPoint = null;
    this.speed = options.speed || 1;
    this.status = "idle";
    this.rafId = null;
    this.markerOptions = options.marker || {};
    this.follow = Boolean(options.follow);
    this.followOptions = {
      zoom: 12,
      minZoom: 11,
      height: 18000,
      pitch: -55,
      duration: 120,
      ...(options.followOptions || {}),
    };
    this.followThrottle = Math.max(60, Number(options.followThrottle ?? DEFAULT_FOLLOW_THROTTLE));
    this.lastFollowAt = 0;
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumTrackAdapter(engine, options)
      : new OpenLayersTrackAdapter(engine, options);
  }

  destroy() {
    this.stopTimer();
    this.adapter?.destroy();
    this.adapter = null;
  }

  loadTrack(track, options = {}) {
    const normalized = normalizeTrack(track);
    if (!normalized) {
      console.warn("TrackManager: invalid track data");
      return null;
    }

    this.stopTimer();
    this.track = normalized;
    this.speed = options.speed || this.speed || 1;
    this.currentDistance = clampDistance(
      options.currentDistance ?? distanceAtIndex(normalized, options.currentIndex ?? 0),
      normalized.totalDistance
    );
    this.currentIndex = this.getIndexAtDistance(this.currentDistance);
    this.status = "loaded";
    this.markerOptions = { ...this.markerOptions, ...(options.marker || {}) };
    this.follow = Boolean(options.follow ?? this.follow);
    this.followOptions = { ...this.followOptions, ...(options.followOptions || {}) };
    this.followThrottle = Math.max(60, Number(options.followThrottle ?? this.followThrottle));
    this.lastFollowAt = 0;
    this.adapter.renderTrack(this.track);
    this.updatePlaybackFrame({ forceFollow: true });
    this.emit("track:load", this.getTrackState());
    return this.track;
  }

  restoreState(state = {}) {
    if (!state.track) return null;
    const track = this.loadTrack(state.track, {
      currentDistance: state.currentDistance,
      currentIndex: state.currentIndex || 0,
      speed: state.speed || 1,
      marker: state.markerOptions || {},
      follow: state.follow,
      followOptions: state.followOptions || {},
      followThrottle: state.followThrottle,
    });
    if (!track) return null;

    this.status = state.status === "playing" ? "paused" : (state.status || "loaded");
    this.updatePlaybackFrame({ forceFollow: true });
    if (state.status === "playing") this.playTrack();
    return this.getTrackState();
  }

  playTrack() {
    if (!this.track) return null;
    this.stopTimer();
    this.status = "playing";
    this.playStartedAt = 0;
    this.playStartedDistance = this.currentDistance;
    this.emit("track:play", this.getTrackState());
    this.rafId = window.requestAnimationFrame((timestamp) => this.tick(timestamp));
    return this.getTrackState();
  }

  pauseTrack() {
    if (!this.track) return null;
    this.stopTimer();
    this.status = "paused";
    this.emit("track:pause", this.getTrackState());
    return this.getTrackState();
  }

  resumeTrack() {
    if (!this.track) return null;
    if (this.status === "playing") return this.getTrackState();
    this.status = "playing";
    this.playStartedAt = 0;
    this.playStartedDistance = this.currentDistance;
    this.emit("track:resume", this.getTrackState());
    this.rafId = window.requestAnimationFrame((timestamp) => this.tick(timestamp));
    return this.getTrackState();
  }

  stopTrack() {
    if (!this.track) return null;
    this.stopTimer();
    this.currentDistance = 0;
    this.currentIndex = 0;
    this.status = "stopped";
    this.updatePlaybackFrame({ forceFollow: true });
    this.emit("track:stop", this.getTrackState());
    return this.getTrackState();
  }

  seekTrack(progress = 0) {
    if (!this.track) return null;
    const ratio = Math.max(0, Math.min(1, Number(progress) || 0));
    this.currentDistance = this.track.totalDistance * ratio;
    this.currentIndex = this.getIndexAtDistance(this.currentDistance);
    this.playStartedAt = 0;
    this.playStartedDistance = this.currentDistance;
    this.updatePlaybackFrame({ forceFollow: true });
    this.emit("track:tick", this.getTrackState());
    return this.getTrackState();
  }

  setTrackSpeed(speed = 1) {
    const nextSpeed = Math.max(0.25, Number(speed) || 1);
    if (this.status === "playing") {
      this.playStartedDistance = this.currentDistance;
      this.playStartedAt = 0;
    }
    this.speed = nextSpeed;
    return this.getTrackState();
  }

  clearTrack() {
    this.stopTimer();
    this.adapter.clear();
    if (this.track?.vehicleId) this.mapEngine.removeMarker(this.track.vehicleId);
    this.track = null;
    this.currentIndex = 0;
    this.currentDistance = 0;
    this.interpolatedPoint = null;
    this.status = "idle";
    this.follow = false;
    this.emit("track:clear", this.getTrackState());
  }

  tick(timestamp) {
    if (!this.track || this.status !== "playing") return;

    if (!this.playStartedAt) this.playStartedAt = timestamp;
    const elapsedSeconds = Math.max(0, (timestamp - this.playStartedAt) / 1000);
    const distanceDelta = elapsedSeconds * this.getPlaybackMetersPerSecond() * this.speed;
    this.currentDistance = clampDistance(this.playStartedDistance + distanceDelta, this.track.totalDistance);
    this.currentIndex = this.getIndexAtDistance(this.currentDistance);
    this.updatePlaybackFrame({ timestamp });

    if (this.currentDistance >= this.track.totalDistance) {
      this.stopTimer();
      this.status = "complete";
      this.updatePlaybackFrame({ forceFollow: true, timestamp });
      this.emit("track:tick", this.getTrackState());
      this.emit("track:complete", this.getTrackState());
      return;
    }

    this.emit("track:tick", this.getTrackState());
    this.rafId = window.requestAnimationFrame((nextTimestamp) => this.tick(nextTimestamp));
  }

  updatePlaybackFrame(options = {}) {
    const point = this.getPointAtDistance(this.currentDistance);
    if (!this.track || !point) return null;

    this.interpolatedPoint = point;
    this.updateMarker(point);
    this.followCurrentPoint(point, options);
    this.checkFence(point);
    return point;
  }

  updateMarker(point = this.getCurrentPoint()) {
    if (!this.track || !point) return null;

    const marker = {
      id: this.track.vehicleId,
      name: this.track.name || this.track.vehicleId,
      position: [point.lng, point.lat],
      color: "GREEN",
      label: {
        text: this.track.name || this.track.vehicleId,
        fillColor: "#22c55e",
      },
      data: {
        trackId: this.track.id,
        time: point.time,
        speed: point.speed,
        ...point.data,
      },
      cluster: false,
      ...this.markerOptions,
    };

    if (this.mapEngine.hasMarker?.(marker.id)) {
      return this.mapEngine.updateMarker?.(marker.id, marker);
    }

    return this.mapEngine.addMarker(marker);
  }

  followCurrentPoint(point = this.getCurrentPoint(), options = {}) {
    if (!this.follow || !point) return null;
    const now = options.timestamp || performanceNow();
    if (!options.forceFollow && now - this.lastFollowAt < this.followThrottle) return null;

    this.lastFollowAt = now;
    return this.engine?.centerAt?.([point.lng, point.lat], this.followOptions) || null;
  }

  checkFence(point = this.getCurrentPoint()) {
    if (!point || !this.track) return null;
    return this.mapEngine.checkFencePoint?.({
      id: this.track.vehicleId,
      name: this.track.name || this.track.vehicleId,
      position: [point.lng, point.lat],
      data: {
        trackId: this.track.id,
        time: point.time,
        speed: point.speed,
        ...point.data,
      },
    });
  }

  setFollow(enabled, options = {}) {
    this.follow = Boolean(enabled);
    this.followOptions = { ...this.followOptions, ...(options || {}) };
    this.lastFollowAt = 0;
    if (this.follow) this.followCurrentPoint(this.getCurrentPoint(), { forceFollow: true });
    return this.getTrackState();
  }

  getCurrentPoint() {
    return this.interpolatedPoint || this.getPointAtDistance(this.currentDistance);
  }

  getPointAtDistance(distance) {
    if (!this.track?.points?.length) return null;
    if (distance <= 0) return clonePoint(this.track.points[0]);
    if (distance >= this.track.totalDistance) return clonePoint(this.track.points[this.track.points.length - 1]);

    const segmentIndex = this.getIndexAtDistance(distance);
    const start = this.track.points[segmentIndex];
    const end = this.track.points[segmentIndex + 1];
    const segmentStart = this.track.cumulativeDistances[segmentIndex];
    const segmentEnd = this.track.cumulativeDistances[segmentIndex + 1];
    const ratio = segmentEnd === segmentStart ? 0 : (distance - segmentStart) / (segmentEnd - segmentStart);

    return {
      ...start,
      lng: interpolate(start.lng, end.lng, ratio),
      lat: interpolate(start.lat, end.lat, ratio),
      speed: interpolateNumber(start.speed, end.speed, ratio, this.track.playbackSpeedKmh),
      time: interpolateTime(start.time, end.time, ratio) || start.time,
      data: {
        ...(start.data || {}),
        interpolated: true,
      },
    };
  }

  getIndexAtDistance(distance) {
    if (!this.track?.cumulativeDistances?.length) return 0;
    const distances = this.track.cumulativeDistances;
    for (let index = 0; index < distances.length - 1; index += 1) {
      if (distance <= distances[index + 1]) return index;
    }
    return Math.max(0, distances.length - 2);
  }

  getPlaybackMetersPerSecond() {
    return (this.track?.playbackSpeedKmh || DEFAULT_SPEED_KMH) * 1000 / 3600;
  }

  getTrackState() {
    const progress = this.track?.totalDistance
      ? this.currentDistance / Math.max(1, this.track.totalDistance)
      : 0;

    return {
      track: this.track ? cloneTrack(this.track) : null,
      currentIndex: this.currentIndex,
      currentDistance: this.currentDistance,
      currentPoint: this.getCurrentPoint(),
      interpolatedPoint: this.getCurrentPoint(),
      speed: this.speed,
      status: this.status,
      progress,
      markerOptions: { ...this.markerOptions },
      follow: this.follow,
      followOptions: { ...this.followOptions },
      followThrottle: this.followThrottle,
    };
  }

  stopTimer() {
    if (!this.rafId) return;
    window.cancelAnimationFrame(this.rafId);
    this.rafId = null;
  }

  emit(eventName, payload) {
    this.mapEngine.emitLocal?.(eventName, payload);
  }
}

function normalizeTrack(track) {
  if (!track || !Array.isArray(track.points) || track.points.length < 2) return null;

  const points = track.points
    .map((point) => ({
      ...point,
      lng: Number(point.lng ?? point[0]),
      lat: Number(point.lat ?? point[1]),
      speed: normalizeSpeed(point.speed),
    }))
    .filter((point) => Number.isFinite(point.lng) && Number.isFinite(point.lat));

  if (points.length < 2) return null;

  const cumulativeDistances = [0];
  for (let index = 1; index < points.length; index += 1) {
    cumulativeDistances[index] = cumulativeDistances[index - 1] + distanceMeters(points[index - 1], points[index]);
  }

  const totalDistance = cumulativeDistances[cumulativeDistances.length - 1] || points.length - 1;
  const playbackSpeedKmh = normalizeSpeed(track.speedKmh ?? track.properties?.speedKmh)
    || averagePointSpeed(points)
    || DEFAULT_SPEED_KMH;

  return {
    id: track.id || `track-${Date.now()}`,
    name: track.name || "未命名轨迹",
    vehicleId: track.vehicleId || "track-vehicle",
    points,
    cumulativeDistances,
    totalDistance,
    playbackSpeedKmh,
    properties: {
      ...(track.properties || {}),
      playbackSpeedKmh,
    },
  };
}

function distanceAtIndex(track, index) {
  const safeIndex = Math.max(0, Math.min(track.cumulativeDistances.length - 1, Number(index) || 0));
  return track.cumulativeDistances[safeIndex] || 0;
}

function clampDistance(distance, totalDistance) {
  return Math.max(0, Math.min(Math.max(0, totalDistance || 0), Number(distance) || 0));
}

function distanceMeters(a, b) {
  const earthRadius = 6371008.8;
  const lat1 = toRadians(a.lat);
  const lat2 = toRadians(b.lat);
  const dLat = toRadians(b.lat - a.lat);
  const dLng = toRadians(b.lng - a.lng);
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h = sinLat * sinLat + Math.cos(lat1) * Math.cos(lat2) * sinLng * sinLng;
  return 2 * earthRadius * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}

function toRadians(degrees) {
  return degrees * Math.PI / 180;
}

function normalizeSpeed(speed) {
  const number = Number(speed);
  return Number.isFinite(number) && number > 0 ? number : null;
}

function averagePointSpeed(points) {
  const speeds = points.map((point) => normalizeSpeed(point.speed)).filter(Boolean);
  if (!speeds.length) return null;
  return speeds.reduce((sum, speed) => sum + speed, 0) / speeds.length;
}

function interpolate(start, end, ratio) {
  return start + (end - start) * ratio;
}

function interpolateNumber(start, end, ratio, fallback) {
  const a = Number(start);
  const b = Number(end);
  if (Number.isFinite(a) && Number.isFinite(b)) return interpolate(a, b, ratio);
  if (Number.isFinite(a)) return a;
  if (Number.isFinite(b)) return b;
  return fallback;
}

function interpolateTime(start, end, ratio) {
  const startSeconds = parseTimeSeconds(start);
  const endSeconds = parseTimeSeconds(end);
  if (startSeconds == null || endSeconds == null) return null;
  return formatTimeSeconds(interpolate(startSeconds, endSeconds, ratio));
}

function parseTimeSeconds(time) {
  if (typeof time !== "string") return null;
  const match = time.match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
  if (!match) return null;
  return Number(match[1]) * 3600 + Number(match[2]) * 60 + Number(match[3]);
}

function formatTimeSeconds(seconds) {
  const total = Math.max(0, Math.round(seconds)) % 86400;
  const hh = String(Math.floor(total / 3600)).padStart(2, "0");
  const mm = String(Math.floor((total % 3600) / 60)).padStart(2, "0");
  const ss = String(total % 60).padStart(2, "0");
  return `${hh}:${mm}:${ss}`;
}

function performanceNow() {
  return typeof performance !== "undefined" ? performance.now() : Date.now();
}

function clonePoint(point) {
  return {
    ...point,
    data: { ...(point.data || {}) },
  };
}

function cloneTrack(track) {
  return {
    ...track,
    points: track.points.map((point) => clonePoint(point)),
    cumulativeDistances: [...(track.cumulativeDistances || [])],
    properties: { ...(track.properties || {}) },
  };
}
