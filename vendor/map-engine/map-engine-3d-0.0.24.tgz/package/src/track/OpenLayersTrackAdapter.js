import Feature from "ol/Feature";
import LineString from "ol/geom/LineString";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import { Style, Stroke } from "ol/style";
import { fromLonLat } from "ol/proj";

export default class OpenLayersTrackAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new VectorLayer({
      source: this.source,
      zIndex: options.zIndex ?? 900,
      style: new Style({
        stroke: new Stroke({
          color: options.color || "#22c55e",
          width: options.width || 4,
        }),
      }),
    });

    this.map.addLayer(this.layer);
  }

  destroy() {
    this.clear();
    if (this.map && this.layer) this.map.removeLayer(this.layer);
  }

  renderTrack(track) {
    this.clear();
    const coordinates = normalizeTrackCoordinates(track);
    if (coordinates.length < 2) return null;

    const feature = new Feature({
      geometry: new LineString(coordinates.map((coordinate) => fromLonLat(coordinate))),
    });
    feature.setId(track.id || "track-line");
    this.source.addFeature(feature);
    return feature;
  }

  clear() {
    this.source.clear();
  }
}

function normalizeTrackCoordinates(track) {
  return (track?.points || [])
    .map((point) => [point.lng ?? point[0], point.lat ?? point[1]])
    .filter((coordinate) => Number.isFinite(coordinate[0]) && Number.isFinite(coordinate[1]));
}
