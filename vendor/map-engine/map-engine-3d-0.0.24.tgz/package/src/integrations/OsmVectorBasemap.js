import MVT from "ol/format/MVT";
import LayerGroup from "ol/layer/Group";
import VectorTileLayer from "ol/layer/VectorTile";
import VectorTileSource from "ol/source/VectorTile";
import { Circle as CircleStyle, Fill, Stroke, Style, Text } from "ol/style";
import { createXYZ } from "ol/tilegrid";
import { transformExtent } from "ol/proj";

const DEFAULT_DATASET_ID = "china-ethiopia";
const DEFAULT_ZOOM_BUCKETS = [0, 5, 8, 10, 12, 14, 16];

export const MILITARY_BASEMAP_PROFILES = Object.freeze({
  "osm-debug": Object.freeze({
    profile: "osm-debug",
    labels: Object.freeze({
      enabled: true,
      villageMinZoom: 12,
      townMinZoom: 10,
      minorRoadMinZoom: 14,
      buildingMinZoom: 13,
      poiMode: "all",
      declutter: true,
    }),
    performance: Object.freeze({ styleCache: true, zoomBuckets: DEFAULT_ZOOM_BUCKETS, logTileStats: false, logRenderStats: false }),
  }),
  "military-default": Object.freeze({
    profile: "military-default",
    labels: Object.freeze({
      enabled: true,
      villageMinZoom: 15,
      townMinZoom: 12,
      minorRoadMinZoom: 16,
      buildingMinZoom: 16,
      poiMode: "critical-only",
      declutter: true,
    }),
    performance: Object.freeze({ styleCache: true, zoomBuckets: DEFAULT_ZOOM_BUCKETS, logTileStats: false, logRenderStats: false }),
  }),
  "military-detail": Object.freeze({
    profile: "military-detail",
    labels: Object.freeze({
      enabled: true,
      villageMinZoom: 14,
      townMinZoom: 11,
      minorRoadMinZoom: 15,
      buildingMinZoom: 15,
      poiMode: "public-service",
      declutter: true,
    }),
    performance: Object.freeze({ styleCache: true, zoomBuckets: DEFAULT_ZOOM_BUCKETS, logTileStats: false, logRenderStats: false }),
  }),
});

export async function getOsmVectorServiceInfo(serviceUrl, timeout = 1200, datasetId = DEFAULT_DATASET_ID) {
  const normalizedUrl = normalizeServiceUrl(serviceUrl);
  if (!normalizedUrl || typeof fetch !== "function") {
    return { available: false, serviceUrl: normalizedUrl, datasetId, datasetVersion: null, tilejson: null };
  }

  const controller = typeof AbortController !== "undefined" ? new AbortController() : null;
  const timer = setTimeout(() => controller?.abort?.(), timeout);
  try {
    const response = await fetch(`${normalizedUrl}/data/${datasetId}.json?_map_probe=${Date.now()}`, {
      cache: "no-store",
      signal: controller?.signal,
    });
    if (!response.ok) return { available: false, serviceUrl: normalizedUrl, datasetId, datasetVersion: null, tilejson: null };
    const tilejson = await response.json();
    const valid = Array.isArray(tilejson?.tiles) && tilejson.tiles.length > 0;
    return {
      available: valid,
      serviceUrl: normalizedUrl,
      datasetId,
      datasetVersion: valid ? queryValue(tilejson.tiles[0], "v") : null,
      tilejson: valid ? tilejson : null,
    };
  } catch {
    return { available: false, serviceUrl: normalizedUrl, datasetId, datasetVersion: null, tilejson: null };
  } finally {
    clearTimeout(timer);
  }
}

function queryValue(url, name) {
  const match = String(url || "").match(new RegExp(`[?&]${name}=([^&#]+)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export async function probeOsmVectorService(serviceUrl, timeout = 1200) {
  return (await getOsmVectorServiceInfo(serviceUrl, timeout)).available;
}

export function createOsmVectorTileLayer(options = {}) {
  const serviceUrl = normalizeServiceUrl(options.serviceUrl || "http://127.0.0.1:8080");
  const datasetId = options.datasetId || DEFAULT_DATASET_ID;
  const fallbackMinZoom = finiteZoom(options.dataMinZoom ?? options.minimumLevel ?? options.minZoom, 4);
  const fallbackMaxZoom = finiteZoom(options.dataMaxZoom ?? options.localVectorDataMaxZoom, 13);
  const coverages = normalizeZoomCoverage(
    options.zoomCoverage ?? options.localVectorZoomCoverage,
    {
      id: datasetId,
      bounds: options.bounds || options.extent,
      minzoom: fallbackMinZoom,
      maxzoom: fallbackMaxZoom,
      tiles: [options.url || `${serviceUrl}/data/${datasetId}/{z}/{x}/{y}.pbf`],
    }
  );
  const sources = [];
  const childLayers = coverages.map((coverage, index) => {
    const extent = createWebMercatorExtent(coverage.bounds);
    const source = new VectorTileSource({
      attributions: "© OpenStreetMap contributors",
      format: new MVT({ layerName: "source-layer" }),
      url: coverage.tiles[0],
      tileGrid: createXYZ({
        minZoom: coverage.minzoom,
        maxZoom: coverage.maxzoom,
        tileSize: options.tileSize ?? 512,
      }),
      transition: 0,
      ...(extent ? { extent } : {}),
    });
    sources.push(source);
    const childLayer = new VectorTileLayer({
      source,
      declutter: options.declutter !== false,
      renderMode: "hybrid",
      renderBuffer: options.renderBuffer ?? 32,
      updateWhileAnimating: false,
      updateWhileInteracting: false,
      preload: 0,
      zIndex: index,
      ...(coverage.minzoom > 0 ? { minZoom: coverage.minzoom - 0.001 } : {}),
      ...(extent ? { extent } : {}),
    });
    childLayer.set("vectorCoverage", coverage);
    return childLayer;
  });
  const source = sources[0];
  const layer = childLayers.length === 1
    ? childLayers[0]
    : new LayerGroup({ layers: childLayers, zIndex: options.zIndex ?? 0 });
  if (childLayers.length === 1) layer.setZIndex(options.zIndex ?? 0);
  const dataMinZoom = Math.min(...coverages.map((coverage) => coverage.minzoom));
  const dataMaxZoom = Math.max(...coverages.map((coverage) => coverage.maxzoom));
  const performanceStats = createBasemapPerformanceStats();
  let baseMapLanguage = normalizeBaseMapLanguage(options.baseMapLanguage);
  let activeStyleName = options.style || "default";
  layer.set("basemapPerformanceStats", performanceStats);
  layer.set("vectorDataMinZoom", dataMinZoom);
  layer.set("vectorDataMaxZoom", dataMaxZoom);
  layer.set("vectorOverzoomEnabled", true);
  layer.set("vectorZoomCoverage", coverages);

  async function applyStyle(name = "default", view) {
    activeStyleName = name;
    const response = await fetch(`${serviceUrl}/styles/${name}.json`, { cache: "no-store" });
    if (!response.ok) throw new Error(`OSM vector style HTTP ${response.status}`);
    const styleJson = await response.json();
    const background = backgroundFrom(styleJson);
    const militaryConfig = normalizeMilitaryBasemapConfig(options.militaryBasemap, name);
    performanceStats.reset();
    const styleFunction = createStyleFunction(styleJson, view, {
      militaryConfig,
      performanceStats,
      baseMapLanguage,
    });
    childLayers.forEach((childLayer) => {
      childLayer.setStyle(styleFunction);
      childLayer.set("militaryBasemapConfig", militaryConfig);
      childLayer.changed();
    });
    layer.set("militaryBasemapConfig", militaryConfig);
    childLayers[0]?.setBackground?.(background);
    if (options.backgroundTarget) {
      options.backgroundTarget.style.background = background;
    }
    layer.changed();
    return {
      name,
      styleJson,
      background,
      sourceStable: childLayers.every((childLayer, index) => childLayer.getSource() === sources[index]),
      baseMapLanguage,
    };
  }

  async function setBaseMapLanguage(language, view) {
    baseMapLanguage = normalizeBaseMapLanguage(language);
    return applyStyle(activeStyleName, view);
  }

  return {
    layer,
    source,
    sources,
    childLayers,
    coverages,
    serviceUrl,
    dataMinZoom,
    dataMaxZoom,
    applyStyle,
    setBaseMapLanguage,
  };
}

export async function attachOsmVectorBasemap(mapEngine, options = {}) {
  if (mapEngine?.getType?.() !== "2d") {
    throw new Error("OsmVectorBasemap currently supports MapEngine 2D mode only");
  }

  const nativeMap = mapEngine.engine?.map;
  if (!nativeMap) throw new Error("MapEngine OpenLayers map is not initialized");

  const serviceUrl = String(options.serviceUrl || "http://127.0.0.1:8080").replace(/\/$/, "");
  const target = mapEngine.options?.container;
  const bundle = createOsmVectorTileLayer({
    ...options,
    serviceUrl,
    backgroundTarget: target,
    zIndex: 0,
  });
  const { layer, source, sources, coverages, dataMinZoom, dataMaxZoom } = bundle;
  nativeMap.addLayer(layer);
  const controls = createStyleControls(target, serviceUrl);

  async function applyStyle(name) {
    const view = nativeMap.getView();
    const center = view.getCenter()?.slice();
    const zoom = view.getZoom();
    const rotation = view.getRotation();
    const result = await bundle.applyStyle(name, view);
    if (center) view.setCenter(center);
    view.setZoom(zoom);
    view.setRotation(rotation);
    controls.setState(name, result.sourceStable);
    nativeMap.render();
    return { ...result, center, zoom, rotation };
  }

  controls.onSelect(applyStyle);
  await applyStyle(options.style || "default");

  return {
    layer,
    source,
    sources,
    coverages,
    serviceUrl,
    dataMinZoom,
    dataMaxZoom,
    applyStyle,
    destroy() {
      nativeMap.removeLayer(layer);
      controls.destroy();
    },
  };
}

export function createStyleFunction(styleJson, view, options = {}) {
  const majorClasses = new Set(["motorway", "motorway_link", "trunk", "trunk_link", "primary", "primary_link"]);
  const motorwayClasses = new Set(["motorway", "motorway_link", "trunk", "trunk_link"]);
  const primaryClasses = new Set(["primary", "primary_link"]);
  const secondaryClasses = new Set(["secondary", "secondary_link"]);
  const tertiaryClasses = new Set(["tertiary", "tertiary_link"]);
  const forestClasses = new Set(["forest", "wood"]);
  const criticalPoiClasses = new Set(["airport", "aerodrome", "station", "ferry_terminal", "hospital", "police", "fire_station", "townhall"]);
  const publicServicePoiClasses = new Set(["university", "school", "government", "townhall", "library", "stadium"]);
  const sharedStyles = new Map();
  const featureStyles = new WeakMap();
  const militaryConfig = normalizeMilitaryBasemapConfig(options.militaryConfig);
  const baseMapLanguage = normalizeBaseMapLanguage(options.baseMapLanguage);
  const stats = options.performanceStats;
  const colors = {
    landuse: paint(styleJson, "landuse-fill", "fill-color", "#e5e0d3"),
    land: paint(styleJson, "landcover-base", "fill-color", "#dbe5cf"),
    forest: paint(styleJson, "landcover-forest", "fill-color", "#b9d3ad"),
    water: paint(styleJson, "water-fill", "fill-color", "#9fc9e5"),
    waterLine: paint(styleJson, "waterway-line", "line-color", "#79b5d8"),
    boundary: paint(styleJson, "boundary-region", "line-color", "#98a1a6"),
    countryBoundary: paint(styleJson, "boundary-country", "line-color", "#6d7980"),
    building: paint(styleJson, "building-fill", "fill-color", "#d5d1cc"),
    buildingOutline: paint(styleJson, "building-fill", "fill-outline-color", "#b7b1aa"),
    roadCasing: paint(styleJson, "road-casing", "line-color", "#b6b7b8"),
    road: paint(styleJson, "road", "line-color", "#ffffff"),
    major: paint(styleJson, "major-road", "line-color", "#f3c988"),
    rail: paint(styleJson, "railway", "line-color", "#77747a"),
    label: paint(styleJson, "place-label", "text-color", "#3c4650"),
    halo: paint(styleJson, "place-label", "text-halo-color", "#ffffff"),
    roadLabel: paint(styleJson, "road-label", "text-color", "#6b7073"),
    poi: paint(styleJson, "poi-marker", "circle-color", "#607d8b"),
    poiLabel: paint(styleJson, "poi-label", "text-color", "#46545a"),
  };

  const shared = (key, factory) => {
    if (!sharedStyles.has(key)) {
      sharedStyles.set(key, factory());
      stats?.recordStyleCreation?.("shared");
    } else {
      stats?.recordCacheHit?.();
    }
    return sharedStyles.get(key);
  };
  const perFeature = (feature, key, factory) => {
    let cache = featureStyles.get(feature);
    if (!cache) {
      cache = new Map();
      featureStyles.set(feature, cache);
    }
    if (!cache.has(key)) {
      cache.set(key, factory());
      stats?.recordStyleCreation?.("feature");
    } else {
      stats?.recordCacheHit?.();
    }
    return cache.get(key);
  };

  return (feature, resolution) => {
    const sourceLayer = feature.get("source-layer");
    stats?.recordFeature?.(sourceLayer);
    const featureClass = feature.get("class");
    const geometryType = feature.getType();
    const currentViewZoom = view?.getZoom?.();
    const zoom = Number.isFinite(currentViewZoom)
      ? currentViewZoom
      : view.getZoomForResolution(resolution);
    const zoomBucket = resolveZoomBucket(zoom, militaryConfig.performance.zoomBuckets);
    const name = selectBaseMapLabel(feature, baseMapLanguage);
    if (sourceLayer === "landuse") {
      return shared("landuse", () => new Style({ fill: new Fill({ color: colors.landuse }) }));
    }
    if (sourceLayer === "landcover") {
      const forest = forestClasses.has(featureClass);
      return shared(`landcover:${forest}`, () => new Style({ fill: new Fill({ color: forest ? colors.forest : colors.land }) }));
    }
    if (sourceLayer === "water") {
      return shared("water", () => new Style({ fill: new Fill({ color: colors.water }) }));
    }
    if (sourceLayer === "waterway") {
      return shared(`waterway:${zoomBucket}`, () => new Style({
        stroke: new Stroke({ color: colors.waterLine, width: Math.max(0.7, (zoomBucket - 8) * 0.16) }),
      }));
    }
    if (sourceLayer === "boundary") {
      const country = String(feature.get("admin_level")) === "2";
      return shared(`boundary:${country}`, () => new Style({
        stroke: new Stroke({
          color: country ? colors.countryBoundary : colors.boundary,
          width: country ? 1.8 : 0.9,
          lineDash: country ? undefined : [6, 4],
        }),
      }));
    }
    if (sourceLayer === "building") {
      if (zoom < militaryConfig.labels.buildingMinZoom) return null;
      return shared("building", () => new Style({
        fill: new Fill({ color: colors.building }),
        stroke: new Stroke({ color: colors.buildingOutline, width: 0.6 }),
      }));
    }
    if (sourceLayer === "transportation") {
      if (feature.get("kind") === "railway") {
        if (zoom < 7) return null;
        return shared("railway", () => new Style({ stroke: new Stroke({ color: colors.rail, width: 1.3, lineDash: [6, 4] }) }));
      }
      if (!roadClassVisibleAtZoom(featureClass, zoom, motorwayClasses, primaryClasses, secondaryClasses, tertiaryClasses, militaryConfig)) {
        return null;
      }
      const major = majorClasses.has(featureClass);
      const width = Math.max(0.8, Math.min(5, 0.7 + (zoomBucket - 8) * 0.55));
      return shared(`road:${major}:${zoomBucket}`, () => [
        new Style({ stroke: new Stroke({ color: colors.roadCasing, width: width + 1.5 }) }),
        new Style({ stroke: new Stroke({ color: major ? colors.major : colors.road, width }) }),
      ]);
    }
    const roadRef = feature.get("ref");
    const overviewRoadName = militaryConfig.profile === "osm-debug" || zoom >= 12;
    if (sourceLayer === "transportation_name" && name && overviewRoadName && militaryConfig.labels.enabled && roadLabelVisibleAtZoom(featureClass, zoom, motorwayClasses, primaryClasses, secondaryClasses, tertiaryClasses, militaryConfig)) {
      stats?.recordLabelCandidate?.("road");
      const roadText = zoom < 12 && roadRef ? String(roadRef) : name;
      return perFeature(feature, `road-label:${zoomBucket}:${roadText}`, () => new Style({
        text: new Text({
          text: roadText,
          placement: "line",
          overflow: false,
          repeat: roadLabelRepeat(featureClass, motorwayClasses, primaryClasses, zoom, militaryConfig.profile),
          maxAngle: Math.PI / 5,
          padding: labelPadding(zoom, militaryConfig.profile, "road"),
          font: `${Math.max(10, Math.min(13, 10 + (zoomBucket - 8) * 0.4))}px "Noto Sans SC", "Microsoft YaHei"`,
          fill: new Fill({ color: colors.roadLabel }),
          stroke: new Stroke({ color: colors.halo, width: 2.2 }),
        }),
      }));
    }
    const poiZoom = poiMinZoom(featureClass, militaryConfig.profile);
    if (sourceLayer === "poi" && name && zoom >= poiZoom && poiVisible(featureClass, militaryConfig.labels.poiMode, criticalPoiClasses, publicServicePoiClasses)) {
      stats?.recordLabelCandidate?.("poi");
      const showLabel = zoom >= poiZoom;
      return perFeature(feature, `poi:${showLabel}:${name}`, () => new Style({
        image: new CircleStyle({
          radius: 3.2,
          fill: new Fill({ color: colors.poi }),
          stroke: new Stroke({ color: colors.halo, width: 1 }),
        }),
        text: showLabel ? new Text({
          text: name,
          padding: labelPadding(zoom, militaryConfig.profile, "place"),
          offsetY: 12,
          font: '11px "Noto Sans SC", "Microsoft YaHei"',
          fill: new Fill({ color: colors.poiLabel }),
          stroke: new Stroke({ color: colors.halo, width: 2.2 }),
        }) : undefined,
      }));
    }
    if (sourceLayer === "place" && name && militaryConfig.labels.enabled && placeVisibleAtZoom(featureClass, zoom, militaryConfig)) {
      stats?.recordLabelCandidate?.("place");
      return perFeature(feature, `place:${zoomBucket}:${name}`, () => new Style({
        zIndex: placeZIndex(featureClass),
        text: new Text({
          text: name,
          font: `${Math.max(11, Math.min(15, 11 + (zoomBucket - 10) * 0.8))}px "Noto Sans SC", "Microsoft YaHei"`,
          fill: new Fill({ color: colors.label }),
          stroke: new Stroke({ color: colors.halo, width: 2.4 }),
        }),
      }));
    }
    return null;
  };
}

export function normalizeBaseMapLanguage(language) {
  return String(language || "zh").toLowerCase() === "en" ? "en" : "zh";
}

export function selectBaseMapLabel(feature, language = "zh") {
  const property = (name) => {
    const value = feature?.get?.(name);
    return typeof value === "string" && value.trim() ? value.trim() : null;
  };
  const fields = normalizeBaseMapLanguage(language) === "en"
    ? ["name_en", "name_zh", "name"]
    : ["name_zh", "name_en", "name"];
  return fields.map(property).find(Boolean) || null;
}

function roadClassVisibleAtZoom(featureClass, zoom, motorway, primary, secondary, tertiary, config) {
  if (motorway.has(featureClass)) return zoom >= 5;
  if (primary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 9 : 8);
  if (secondary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 10 : 11);
  if (tertiary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 12 : 13);
  return zoom >= (config.profile === "osm-debug" ? 13 : 14);
}

function roadLabelVisibleAtZoom(featureClass, zoom, motorway, primary, secondary, tertiary, config) {
  if (motorway.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 8 : 12);
  if (primary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 10 : 12);
  if (secondary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 11 : config.profile === "military-default" ? 14 : 13);
  if (tertiary.has(featureClass)) return zoom >= (config.profile === "osm-debug" ? 12 : 15);
  return zoom >= config.labels.minorRoadMinZoom;
}

function placeVisibleAtZoom(featureClass, zoom, config) {
  if (featureClass === "country" || featureClass === "state") return zoom >= 4;
  if (featureClass === "city") return zoom >= 5;
  if (featureClass === "town") return zoom >= config.labels.townMinZoom;
  if (featureClass === "village") return zoom >= config.labels.villageMinZoom;
  if (featureClass === "suburb" || featureClass === "quarter") {
    const compactMinZoom = config.profile === "military-default" ? 14 : 13;
    return zoom >= Math.max(compactMinZoom, config.labels.townMinZoom);
  }
  if (featureClass === "neighbourhood" || featureClass === "hamlet") return zoom >= Math.max(15, config.labels.villageMinZoom);
  return zoom >= 15;
}

function placeZIndex(featureClass) {
  if (featureClass === "country" || featureClass === "state") return 30;
  if (featureClass === "city") return 25;
  if (featureClass === "town") return 20;
  if (featureClass === "suburb" || featureClass === "village") return 15;
  return 10;
}

function normalizeMilitaryBasemapConfig(config, styleName) {
  const styleProfile = styleName === "military-detail"
    ? "military-detail"
    : styleName === "osm-debug"
      ? "osm-debug"
      : "military-default";
  const requestedProfile = typeof config === "string" ? config : config?.profile;
  const profile = MILITARY_BASEMAP_PROFILES[requestedProfile] ? requestedProfile : styleProfile;
  const base = MILITARY_BASEMAP_PROFILES[profile] || MILITARY_BASEMAP_PROFILES["osm-debug"];
  const overrides = typeof config === "object" && config ? config : {};
  return {
    ...base,
    ...overrides,
    profile,
    labels: { ...base.labels, ...(overrides.labels || {}) },
    performance: {
      ...base.performance,
      ...(overrides.performance || {}),
      zoomBuckets: Array.isArray(overrides.performance?.zoomBuckets)
        ? overrides.performance.zoomBuckets.slice().sort((a, b) => a - b)
        : base.performance.zoomBuckets,
    },
  };
}

function normalizeZoomCoverage(value, fallback) {
  const entries = Array.isArray(value) && value.length ? value : [fallback];
  const normalized = entries.map((entry, index) => {
    const minzoom = finiteZoom(entry?.minzoom ?? entry?.minZoom, fallback.minzoom);
    const maxzoom = finiteZoom(entry?.maxzoom ?? entry?.maxZoom, fallback.maxzoom);
    const tiles = Array.isArray(entry?.tiles) && entry.tiles.length
      ? entry.tiles.map(String)
      : fallback.tiles;
    return {
      id: String(entry?.id || `${fallback.id}-${index}`),
      bounds: Array.isArray(entry?.bounds) && entry.bounds.length >= 4
        ? entry.bounds.slice(0, 4).map(Number)
        : fallback.bounds,
      minzoom,
      maxzoom: Math.max(minzoom, maxzoom),
      tiles,
    };
  });
  return normalized.sort((first, second) => first.minzoom - second.minzoom);
}

function finiteZoom(value, fallback) {
  const zoom = Number(value);
  return Number.isFinite(zoom) ? Math.max(0, Math.floor(zoom)) : fallback;
}

function resolveZoomBucket(zoom, buckets = DEFAULT_ZOOM_BUCKETS) {
  const value = Number.isFinite(Number(zoom)) ? Number(zoom) : 0;
  let bucket = buckets[0] ?? 0;
  for (const candidate of buckets) {
    if (value < candidate) break;
    bucket = candidate;
  }
  return bucket;
}

function roadLabelRepeat(featureClass, motorway, primary, zoom, profile) {
  if (profile === "military-default" && zoom < 14) {
    if (motorway.has(featureClass)) return 1600;
    if (primary.has(featureClass)) return 1400;
    return 1200;
  }
  if (motorway.has(featureClass)) return 1100;
  if (primary.has(featureClass)) return 800;
  return 650;
}

function labelPadding(zoom, profile, kind) {
  if (profile !== "military-default" || zoom >= 14) return [0, 0, 0, 0];
  return kind === "place" ? [16, 24, 16, 24] : [10, 18, 10, 18];
}

function poiVisible(featureClass, mode, critical, publicService) {
  if (mode === "all") return true;
  if (critical.has(featureClass)) return true;
  return mode === "public-service" && publicService.has(featureClass);
}

function poiMinZoom(featureClass, profile) {
  if (profile === "osm-debug") return 12;
  if (featureClass === "airport" || featureClass === "aerodrome") return 8;
  if (featureClass === "ferry_terminal") return 9;
  if (featureClass === "station") return profile === "military-default" ? 14 : 10;
  if (["hospital", "police", "fire_station", "townhall"].includes(featureClass)) {
    return profile === "military-default" ? 14 : 13;
  }
  return 15;
}

function createBasemapPerformanceStats() {
  const state = { featureCalls: 0, styleCreations: 0, sharedStyleCreations: 0, featureStyleCreations: 0, cacheHits: 0, labelCandidates: 0, featuresByLayer: {}, labelsByKind: {} };
  return {
    recordFeature(layer) {
      state.featureCalls += 1;
      const key = layer || "unknown";
      state.featuresByLayer[key] = (state.featuresByLayer[key] || 0) + 1;
    },
    recordStyleCreation(kind) {
      state.styleCreations += 1;
      if (kind === "shared") state.sharedStyleCreations += 1;
      else state.featureStyleCreations += 1;
    },
    recordCacheHit() { state.cacheHits += 1; },
    recordLabelCandidate(kind) {
      state.labelCandidates += 1;
      state.labelsByKind[kind] = (state.labelsByKind[kind] || 0) + 1;
    },
    snapshot() { return JSON.parse(JSON.stringify(state)); },
    reset() {
      state.featureCalls = 0;
      state.styleCreations = 0;
      state.sharedStyleCreations = 0;
      state.featureStyleCreations = 0;
      state.cacheHits = 0;
      state.labelCandidates = 0;
      state.featuresByLayer = {};
      state.labelsByKind = {};
    },
  };
}

function paint(styleJson, id, property, fallback) {
  return styleJson.layers.find((layer) => layer.id === id)?.paint?.[property] ?? fallback;
}

function backgroundFrom(styleJson) {
  return styleJson.layers.find((layer) => layer.type === "background")?.paint?.["background-color"] || "#eef1f3";
}

function normalizeServiceUrl(serviceUrl) {
  return String(serviceUrl || "").replace(/\/$/, "");
}

function createWebMercatorExtent(bounds) {
  if (!bounds) return null;
  const values = Array.isArray(bounds)
    ? bounds.slice(0, 4).map(Number)
    : String(bounds).split(",").slice(0, 4).map((value) => Number(value.trim()));
  if (values.length !== 4 || !values.every(Number.isFinite)) return null;
  return transformExtent(values, "EPSG:4326", "EPSG:3857");
}

function createStyleControls(target, serviceUrl) {
  const element = document.createElement("div");
  element.className = "osm-vector-basemap-controls";
  element.innerHTML = `
    <div class="osm-vector-basemap-title">OSM 矢量底图</div>
    <div class="osm-vector-basemap-actions">
      <button type="button" data-style="default">默认样式</button>
      <button type="button" data-style="military">军工样式</button>
    </div>
    <div class="osm-vector-basemap-status">正在连接 8080 服务…</div>
  `;
  const css = document.createElement("style");
  css.textContent = `
    @font-face{font-family:"Noto Sans SC";src:url("${serviceUrl}/fonts/NotoSansSC-VF.ttf") format("truetype");font-style:normal;font-weight:100 900;font-display:swap}
    .osm-vector-basemap-controls{position:absolute;right:16px;top:16px;z-index:1500;padding:10px 12px;border:1px solid #64727c66;border-radius:7px;background:#f8fafbee;color:#33434b;font:12px "Noto Sans SC","Microsoft YaHei",sans-serif;box-shadow:0 3px 14px #17262d30}
    .osm-vector-basemap-title{font-weight:600;margin-bottom:8px}.osm-vector-basemap-actions{display:flex;gap:6px}.osm-vector-basemap-actions button{padding:6px 10px;border:1px solid #9aa8af;border-radius:5px;background:#fff;color:#34444d;cursor:pointer}.osm-vector-basemap-actions button.active{background:#526b78;color:#fff;border-color:#526b78}.osm-vector-basemap-status{margin-top:7px;color:#3b6a5c}
  `;
  document.head.appendChild(css);
  target.appendChild(element);
  let handler = null;
  element.addEventListener("click", (event) => {
    const name = event.target?.dataset?.style;
    if (name && handler) handler(name).catch((error) => api.setError(error.message));
  });
  const api = {
    onSelect(next) { handler = next; },
    setState(name, stable) {
      element.querySelectorAll("button").forEach((button) => button.classList.toggle("active", button.dataset.style === name));
      element.querySelector(".osm-vector-basemap-status").textContent = stable ? `${name} · source 未重建` : "错误：source 已变化";
    },
    setError(message) { element.querySelector(".osm-vector-basemap-status").textContent = message; },
    destroy() { element.remove(); css.remove(); },
  };
  return api;
}
