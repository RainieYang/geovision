﻿import TileLayer from "ol/layer/Tile";
import XYZ from "ol/source/XYZ";
import { createOsmVectorTileLayer } from "../integrations/OsmVectorBasemap";

const TIANDITU_ANNOTATION_TYPES = {
  vec: "cva",
  img: "cia",
  ter: "cta",
};

const TIANDITU_TYPES = new Set(["vec", "img", "ter", "cva", "cia", "cta"]);
const TIANDITU_SUBDOMAINS = ["0", "1", "2", "3", "4", "5", "6", "7"];
const TIANDITU_DEFAULT_PROTOCOL = "https";

export default class LayerManager {
  constructor({ engineType, map, viewer, CesiumLib } = {}) {
    this.engineType = engineType;
    this.map = map;
    this.viewer = viewer;
    this.CesiumLib = CesiumLib;
    this.layers = new Map();
    this.baseLayerIds = [];
    this.tiandituNetworkProbed = false;
  }

  setBaseLayer(options = {}) {
    this.clearBaseLayers();

    const provider = options.provider || options.baseMapProvider || "tianditu";
    const baseType = this.resolveTiandituType(options);
    const baseId = options.id || "base-layer";

    const baseLayer = this.addLayer({
      ...options,
      id: baseId,
      provider,
      type: baseType,
      zIndex: options.zIndex ?? 0,
    });

    if (baseLayer) {
      this.baseLayerIds.push(baseId);
    }

    const showAnnotation = options.showAnnotation !== false;
    const annotationType = TIANDITU_ANNOTATION_TYPES[baseType];

    if (provider === "tianditu" && showAnnotation && annotationType) {
      const annotationId = options.annotationId || `${baseId}-annotation`;
      const annotationLayer = this.addLayer({
        ...options,
        id: annotationId,
        provider: "tianditu",
        type: annotationType,
        zIndex: options.annotationZIndex ?? (options.zIndex ?? 0) + 1,
      });

      if (annotationLayer) {
        this.baseLayerIds.push(annotationId);
      }
    }

    return baseLayer;
  }

  addLayers(layers = []) {
    if (!Array.isArray(layers)) return [];
    return layers.map((options) => this.addLayer(options)).filter(Boolean);
  }

  addLayer(options = {}) {
    const id = options.id || `layer-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    if (this.layers.has(id)) {
      this.removeLayer(id);
    }

    const provider = options.provider || options.source || "xyz";
    let layer = null;

    if (provider === "tianditu") {
      layer = this.createTiandituLayer(options);
    }

    if (provider === "xyz") {
      layer = this.createXYZLayer(options);
    }

    if (provider === "mvt") {
      layer = this.createMvtLayer(options);
    }

    if (!layer) {
      console.warn("LayerManager: unsupported layer provider", provider);
      return null;
    }

    this.layers.set(id, {
      id,
      provider,
      layer,
      options: { ...options, id },
    });

    this.setVisible(id, options.visible !== false);

    if (typeof options.opacity === "number") {
      this.setOpacity(id, options.opacity);
    }

    if (typeof options.zIndex === "number") {
      this.setZIndex(id, options.zIndex);
    }

    if (provider === "tianditu") {
      console.info("LayerManager: Tianditu layer added", {
        id,
        type: this.resolveTiandituType(options),
        engineType: this.engineType,
      });
    }

    return layer;
  }

  removeLayer(id) {
    const record = this.layers.get(id);
    if (!record) return false;

    if (this.engineType === "2d" && this.map) {
      this.map.removeLayer(record.layer);
    }

    if (this.engineType === "3d" && this.viewer) {
      this.viewer.imageryLayers.remove(record.layer, true);
    }

    this.layers.delete(id);
    this.baseLayerIds = this.baseLayerIds.filter((layerId) => layerId !== id);
    return true;
  }

  getLayer(id) {
    return this.layers.get(id)?.layer || null;
  }

  getNativeLayer(id) {
    return this.getLayer(id);
  }

  getLayerRecord(id) {
    return this.layers.get(id) || null;
  }

  getLayerInfo(id) {
    const record = this.layers.get(id);
    if (!record) return null;

    return {
      id: record.id,
      provider: record.provider,
      type: this.resolveLayerType(record.options),
      visible: this.getVisible(id),
      opacity: this.getOpacity(id),
      zIndex: record.options.zIndex ?? 0,
      options: { ...record.options },
    };
  }

  listLayers() {
    return Array.from(this.layers.keys())
      .map((id) => this.getLayerInfo(id))
      .filter(Boolean)
      .sort((a, b) => (a.zIndex ?? 0) - (b.zIndex ?? 0));
  }

  hasLayer(id) {
    return this.layers.has(id);
  }

  showLayer(id) {
    return this.setVisible(id, true);
  }

  hideLayer(id) {
    return this.setVisible(id, false);
  }

  setLayerVisible(id, visible) {
    return this.setVisible(id, visible);
  }

  getVisible(id) {
    const layer = this.getLayer(id);
    if (!layer) return false;

    if (this.engineType === "2d") {
      return layer.getVisible();
    }

    if (this.engineType === "3d") {
      return layer.show !== false;
    }

    return false;
  }

  setVisible(id, visible) {
    const layer = this.getLayer(id);
    if (!layer) return false;

    if (this.engineType === "2d") {
      layer.setVisible(visible);
    }

    if (this.engineType === "3d") {
      layer.show = visible;
    }

    return true;
  }

  getOpacity(id) {
    const layer = this.getLayer(id);
    if (!layer) return null;

    if (this.engineType === "2d") {
      return layer.getOpacity();
    }

    if (this.engineType === "3d") {
      return layer.alpha ?? 1;
    }

    return null;
  }

  setLayerOpacity(id, opacity) {
    return this.setOpacity(id, opacity);
  }

  setOpacity(id, opacity) {
    const layer = this.getLayer(id);
    if (!layer) return false;

    if (this.engineType === "2d") {
      layer.setOpacity(opacity);
    }

    if (this.engineType === "3d") {
      layer.alpha = opacity;
    }

    return true;
  }

  setLayerZIndex(id, zIndex) {
    return this.setZIndex(id, zIndex);
  }

  setZIndex(id, zIndex) {
    const record = this.layers.get(id);
    if (!record) return false;

    record.options.zIndex = zIndex;

    if (this.engineType === "2d") {
      record.layer.setZIndex(zIndex);
    }

    if (this.engineType === "3d") {
      this.sortCesiumLayers();
    }

    return true;
  }

  clearLayers() {
    Array.from(this.layers.keys()).forEach((id) => this.removeLayer(id));
  }

  clearOverlayLayers() {
    Array.from(this.layers.keys())
      .filter((id) => !this.baseLayerIds.includes(id))
      .forEach((id) => this.removeLayer(id));
  }

  clearBaseLayers() {
    [...this.baseLayerIds].forEach((id) => this.removeLayer(id));
    this.baseLayerIds = [];
  }

  getBaseLayerIds() {
    return [...this.baseLayerIds];
  }

  destroy() {
    this.clearLayers();
    this.map = null;
    this.viewer = null;
    this.CesiumLib = null;
  }

  createTiandituLayer(options = {}) {
    const tk = this.resolveTiandituTk(options);

    if (!tk) {
      console.warn("LayerManager: tiandituTk is required for Tianditu layers");
      return null;
    }

    const layerOptions = {
      ...options,
      tk,
      url: this.createTiandituUrl({ ...options, tk }),
      minimumLevel: options.minimumLevel ?? 0,
      maximumLevel: options.maximumLevel ?? 18,
    };

    if (this.engineType === "3d") {
      return this.createCesiumTiandituLayer(layerOptions);
    }

    return this.createXYZLayer(layerOptions);
  }

  resolveTiandituTk(options = {}) {
    return options.tk || options.tiandituTk || options.token;
  }

  createXYZLayer(options = {}) {
    const { url, minimumLevel = 0, maximumLevel = 18 } = options;

    if (!url) {
      console.warn("LayerManager: url is required for XYZ layers");
      return null;
    }

    if (this.engineType === "2d") {
      const layer = new TileLayer({
        source: new XYZ({
          url,
          minZoom: minimumLevel,
          maxZoom: maximumLevel,
          crossOrigin: options.crossOrigin ?? "anonymous",
        }),
      });

      this.map.addLayer(layer);
      return layer;
    }

    if (this.engineType === "3d") {
      const providerOptions = {
        url,
        minimumLevel,
        maximumLevel,
      };

      const rectangle = this.createCesiumRectangle(options);
      if (rectangle) providerOptions.rectangle = rectangle;

      const provider = new this.CesiumLib.UrlTemplateImageryProvider(providerOptions);

      provider.errorEvent?.addEventListener?.((error) => {
        console.warn("LayerManager: Cesium XYZ tile error", {
          message: error?.message,
          x: error?.x,
          y: error?.y,
          level: error?.level,
          timesRetried: error?.timesRetried,
          retry: error?.retry,
          url,
        });
      });

      return this.viewer.imageryLayers.addImageryProvider(provider);
    }

    return null;
  }

  createMvtLayer(options = {}) {
    if (this.engineType !== "2d" || !this.map) {
      console.warn("LayerManager: MVT basemap currently supports 2D only");
      return null;
    }

    const bundle = createOsmVectorTileLayer({
      ...options,
      serviceUrl: options.localVectorServiceUrl || options.serviceUrl,
      backgroundTarget: this.map.getTargetElement?.(),
    });
    bundle.layer.set("applyNamedStyle", bundle.applyStyle);
    bundle.layer.set("applyBaseMapLanguage", bundle.setBaseMapLanguage);
    bundle.layer.set("vectorServiceUrl", bundle.serviceUrl);
    bundle.layer.set("vectorDataMaxZoom", bundle.dataMaxZoom);
    bundle.layer.set("vectorOverzoomEnabled", true);
    this.map.addLayer(bundle.layer);
    const styleReady = bundle.applyStyle(
      options.localVectorStyle || options.style || "default",
      this.map.getView()
    ).catch((error) => {
      console.error("LayerManager: MVT style load failed", error);
      return { applied: false, error };
    });
    bundle.layer.set("styleReady", styleReady);
    return bundle.layer;
  }

  setBaseMapStyle(name = "default") {
    const record = this.baseLayerIds
      .map((id) => this.layers.get(id))
      .find((item) => item?.provider === "mvt");
    const applyStyle = record?.layer?.get?.("applyNamedStyle");
    if (!applyStyle) return Promise.resolve(false);
    return applyStyle(name, this.map?.getView?.()).then((result) => ({ ...result, applied: true }));
  }

  setBaseMapLanguage(language = "zh") {
    const record = this.baseLayerIds
      .map((id) => this.layers.get(id))
      .find((item) => item?.provider === "mvt");
    const applyLanguage = record?.layer?.get?.("applyBaseMapLanguage");
    if (!applyLanguage) return Promise.resolve({ applied: false, baseMapLanguage: language });
    return applyLanguage(language, this.map?.getView?.()).then((result) => ({ ...result, applied: true }));
  }

  getBaseMapPerformanceStats({ reset = false } = {}) {
    const record = this.baseLayerIds
      .map((id) => this.layers.get(id))
      .find((item) => item?.provider === "mvt");
    const stats = record?.layer?.get?.("basemapPerformanceStats");
    if (!stats?.snapshot) return null;
    const snapshot = stats.snapshot();
    if (reset) stats.reset?.();
    return snapshot;
  }

  createCesiumRectangle(options = {}) {
    if (!this.CesiumLib) return null;

    const bounds = options.bounds || options.rectangle || options.extent;
    if (!bounds) return null;

    const values = Array.isArray(bounds)
      ? bounds
      : String(bounds)
          .split(",")
          .map((value) => Number(value.trim()));

    if (values.length < 4) return null;

    const [west, south, east, north] = values.map(Number);
    if (![west, south, east, north].every(Number.isFinite)) return null;

    return this.CesiumLib.Rectangle.fromDegrees(west, south, east, north);
  }

  createTiandituUrl(options = {}) {
    const tk = this.resolveTiandituTk(options);
    const type = this.resolveTiandituType(options);
    const projection = options.projection || "w";
    const subdomain = options.subdomain || "t0";
    const protocol = this.resolveTiandituProtocol(options);

    return `${protocol}://${subdomain}.tianditu.gov.cn/DataServer?T=${type}_${projection}&x={x}&y={y}&l={z}&tk=${tk}`;
  }

  resolveTiandituProtocol(options = {}) {
    const protocol = options.protocol || options.scheme || options.tiandituProtocol || TIANDITU_DEFAULT_PROTOCOL;
    return String(protocol).replace(/:$/, "");
  }

  createTiandituWmtsUrl(options = {}) {
    const tk = this.resolveTiandituTk(options);
    const type = this.resolveTiandituType(options);
    const projection = options.projection || "w";
    const protocol = this.resolveTiandituProtocol(options);

    return `${protocol}://t{s}.tianditu.gov.cn/${type}_${projection}/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=${type}&STYLE=default&TILEMATRIXSET=${projection}&FORMAT=tiles&TILEMATRIX={TileMatrix}&TILEROW={TileRow}&TILECOL={TileCol}&tk=${tk}`;
  }

  createTiandituTileMatrixLabels(maximumLevel = 18) {
    return Array.from({ length: maximumLevel + 1 }, (_, level) => String(level));
  }

  getTiandituSubdomain(x = 0, y = 0, level = 0, subdomains = TIANDITU_SUBDOMAINS) {
    const tileX = Number.isFinite(x) ? x : 0;
    const tileY = Number.isFinite(y) ? y : 0;
    const tileLevel = Number.isFinite(level) ? level : 0;
    const index = Math.abs((tileX + tileY + tileLevel) % subdomains.length);
    return String(subdomains[index] ?? "0").replace(/^t/, "");
  }

  buildTiandituWmtsTileUrl({
    type,
    projection,
    tk,
    x,
    y,
    level,
    subdomain,
    tileMatrixLabels,
    protocol = TIANDITU_DEFAULT_PROTOCOL,
  } = {}) {
    const tileMatrix = tileMatrixLabels?.[level] ?? String(level);
    const resolvedSubdomain = subdomain ?? this.getTiandituSubdomain(x, y, level);

    return `${protocol}://t${resolvedSubdomain}.tianditu.gov.cn/${type}_${projection}/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0&LAYER=${type}&STYLE=default&TILEMATRIXSET=${projection}&FORMAT=tiles&TILEMATRIX=${tileMatrix}&TILEROW=${y}&TILECOL=${x}&tk=${tk}`;
  }

  probeTiandituNetwork({ tk, sampleUrl, protocol = TIANDITU_DEFAULT_PROTOCOL } = {}) {
    if (this.tiandituNetworkProbed || !tk) return;
    this.tiandituNetworkProbed = true;

    const capabilitiesUrl = `${protocol}://t0.tianditu.gov.cn/img_w/wmts?SERVICE=WMTS&REQUEST=GetCapabilities&VERSION=1.0.0&tk=${tk}`;

    fetch(capabilitiesUrl)
      .then((response) => {
        console.log("LayerManager: Tianditu WMTS fetch status " + JSON.stringify({
          status: response.status,
          ok: response.ok,
          url: capabilitiesUrl,
        }));
      })
      .catch((error) => {
        console.error("LayerManager: Tianditu WMTS fetch failed " + JSON.stringify({
          message: error?.message || String(error),
          url: capabilitiesUrl,
        }));
      });

    if (!sampleUrl) return;

    const image = new Image();
    image.onload = () => {
      console.log("LayerManager: Tianditu sample image loaded " + JSON.stringify({
        width: image.naturalWidth,
        height: image.naturalHeight,
        url: sampleUrl,
      }));
    };
    image.onerror = () => {
      console.error("LayerManager: Tianditu sample image failed " + JSON.stringify({
        url: sampleUrl,
      }));
    };
    image.src = sampleUrl;
  }

  createCesiumTiandituLayer(options = {}) {
    if (!this.viewer || !this.CesiumLib) return null;

    const tk = this.resolveTiandituTk(options);
    const type = this.resolveTiandituType(options);
    const projection = options.projection || "w";
    const protocol = this.resolveTiandituProtocol(options);
    const minimumLevel = options.minimumLevel ?? 0;
    const maximumLevel = options.maximumLevel ?? 18;
    const subdomains = options.subdomains || TIANDITU_SUBDOMAINS;
    const tileMatrixLabels = this.createTiandituTileMatrixLabels(maximumLevel);
    const sampleUrl = this.buildTiandituWmtsTileUrl({
      type,
      projection,
      tk,
      x: 0,
      y: 0,
      level: minimumLevel,
      tileMatrixLabels,
      protocol,
    });

    this.probeTiandituNetwork({ tk, sampleUrl, protocol });

    const provider = new this.CesiumLib.WebMapTileServiceImageryProvider({
      url: this.createTiandituWmtsUrl({ ...options, tk, type, projection }),
      layer: type,
      style: "default",
      format: "tiles",
      tileMatrixSetID: projection,
      tileMatrixLabels,
      subdomains,
      minimumLevel,
      maximumLevel,
    });

    provider.errorEvent?.addEventListener?.((error) => {
      const x = error?.x;
      const y = error?.y;
      const level = error?.level;
      const subdomain = this.getTiandituSubdomain(x, y, level, subdomains);
      const tileMatrix = tileMatrixLabels?.[level] ?? String(level);
      const url = this.buildTiandituWmtsTileUrl({
        type,
        projection,
        tk,
        x,
        y,
        level,
        subdomain,
        tileMatrixLabels,
        protocol,
      });

      console.warn("LayerManager: Cesium Tianditu tile error " + JSON.stringify({
        message: error?.message,
        x: error?.x,
        y: error?.y,
        level: error?.level,
        TILECOL: x,
        TILEROW: y,
        TILEMATRIX: tileMatrix,
        timesRetried: error?.timesRetried,
        retry: error?.retry,
        type,
        projection,
        protocol,
        subdomain,
        tkPresent: Boolean(tk),
        tkLength: tk?.length ?? 0,
        url,
      }));
    });

    const layer = this.viewer.imageryLayers.addImageryProvider(provider);
    this.viewer.scene.requestRender?.();
    return layer;
  }

  resolveLayerType(options = {}) {
    if ((options.provider || options.source) === "tianditu") {
      return this.resolveTiandituType(options);
    }

    return options.type || options.layerType || options.provider || options.source || "xyz";
  }

  resolveTiandituType(options = {}) {
    const requestedType = options.tdtType || options.tiandituType || options.type || options.baseMapType;

    if (TIANDITU_TYPES.has(requestedType)) {
      return requestedType;
    }

    return "vec";
  }

  sortCesiumLayers() {
    if (!this.viewer) return;

    const records = Array.from(this.layers.values()).sort(
      (a, b) => (a.options.zIndex ?? 0) - (b.options.zIndex ?? 0)
    );

    records.forEach((record) => {
      this.viewer.imageryLayers.lowerToBottom(record.layer);
    });

    records.forEach((record) => {
      this.viewer.imageryLayers.raiseToTop(record.layer);
    });
  }
}




