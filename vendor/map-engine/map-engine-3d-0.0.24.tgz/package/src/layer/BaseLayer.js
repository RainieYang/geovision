
class BaseLayer {
    constructor(viewer, CesiumLib) {
        this.viewer = viewer;
        this.CesiumLib = CesiumLib;
        this.currentLayer = null;
        this.layers = new Map();
    }
addLayer(options = {}) {
  const { id, provider = "tianditu" } = options;

  let layer;

  if (provider === "tianditu") {
    layer = this.createTiandituProvider(options);
  }

  if (provider === "xyz") {
    layer = this.createXYZProvider(options);
  }

  if (!layer) return;

  const imageryLayer = this.viewer.imageryLayers.addImageryProvider(layer);

  if (id) {
    this.layers.set(id, imageryLayer);
  }

  return imageryLayer;
}
    setLayer(options = {}) {
        const { provider = "xyz" } = options;

        if (provider === "tianditu") {
            return this.setTiandituLayer(options);
        }

        if (provider === "wmts") {
            return this.setWMTSLayer(options);
        }

        if (provider === "xyz") {
            return this.setXYZLayer(options);
        }

        console.warn("BaseLayer: 不支持的底图类型", provider);
    }

    /**
     * XYZ / TMS / 普通瓦片
     */
    setXYZLayer(options = {}) {
        if (!this.viewer) return;

        const {
            url,
            minimumLevel = 0,
            maximumLevel = 18,
        } = options;

        if (!url) {
            console.warn("BaseLayer: 缺少瓦片地址 url");
            return;
        }

        const provider = new this.CesiumLib.UrlTemplateImageryProvider({
            url,
            minimumLevel,
            maximumLevel,
        });

        return this.replaceLayer(provider);
    }

    setWMTSLayer(options = {}) {
        if (!this.viewer) return;

        const {
            url,
            layer,
            style = "default",
            format = "tiles",
            tileMatrixSetID = "w",
            tileMatrixLabels,
            minimumLevel = 0,
            maximumLevel = 18,
        } = options;

        if (!url || !layer) {
            console.warn("BaseLayer: WMTS 缺少 url 或 layer");
            return;
        }

        const provider = new this.CesiumLib.WebMapTileServiceImageryProvider({
            url,
            layer,
            style,
            format,
            tileMatrixSetID,
            tileMatrixLabels,
            minimumLevel,
            maximumLevel,
        });

        return this.replaceLayer(provider);
    }

    /**
     * 天地图
     */
    createTiandituProvider(options = {}) {
  const {
    tk,
    type = "img",
    projection = "w",
    subdomain = "t0",
    minimumLevel = 1,
    maximumLevel = 18,
  } = options;

  if (!tk) {
    console.warn("BaseLayer: 天地图缺少 tk");
    return null;
  }

  const url =
    `https://${subdomain}.tianditu.gov.cn/${type}_${projection}/wmts?` +
    `SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0` +
    `&LAYER=${type}` +
    `&STYLE=default` +
    `&TILEMATRIXSET=${projection}` +
    `&FORMAT=tiles` +
    `&TILEMATRIX={z}` +
    `&TILEROW={y}` +
    `&TILECOL={x}` +
    `&tk=${tk}`;

  return new this.CesiumLib.UrlTemplateImageryProvider({
    url,
    minimumLevel,
    maximumLevel,
  });
}
setTiandituLayer(options = {}) {
  const provider = this.createTiandituProvider(options);

  if (!provider) return;

  return this.replaceLayer(provider);
}

    /**
     * 替换当前底图
     */
    replaceLayer(provider) {
        this.clear();

        this.currentLayer =
            this.viewer.imageryLayers.addImageryProvider(provider);

        return this.currentLayer;
    }

    /**
     * 清除当前底图
     */
    clear() {
        if (this.currentLayer && this.viewer) {
            this.viewer.imageryLayers.remove(this.currentLayer, true);
            this.currentLayer = null;
        }
    }
}

export default BaseLayer;