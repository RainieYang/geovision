export function clone(value) {
  if (value == null) return value;
  return JSON.parse(JSON.stringify(value));
}

export function isLngLat(value) {
  return (
    Array.isArray(value) &&
    value.length >= 2 &&
    Number.isFinite(Number(value[0])) &&
    Number.isFinite(Number(value[1]))
  );
}

export function normalizeView(view = {}) {
  const center = isLngLat(view.center) ? [Number(view.center[0]), Number(view.center[1])] : [104.0668, 30.5728];
  const zoom = Number.isFinite(Number(view.zoom)) ? Number(view.zoom) : 10;
  const next = { center, zoom };

  if (Number.isFinite(Number(view.pitch))) next.pitch = Number(view.pitch);
  if (Number.isFinite(Number(view.heading))) next.heading = Number(view.heading);
  if (Number.isFinite(Number(view.roll))) next.roll = Number(view.roll);
  if (Number.isFinite(Number(view.cameraHeight))) next.cameraHeight = Number(view.cameraHeight);

  return next;
}

export function normalizeObject(object = {}) {
  if (!object.id) return null;

  const type = object.type || (object.position ? "marker" : "custom");
  const next = {
    id: String(object.id),
    type,
    style: { ...(object.style || {}) },
    properties: { ...(object.properties || {}) },
  };

  if (object.geometry) {
    next.geometry = clone(object.geometry);
  }

  if (isLngLat(object.position)) {
    next.position = [Number(object.position[0]), Number(object.position[1])];
    // Keep an optional absolute height for 3D presentations. 2D consumers
    // continue to read only longitude/latitude, while Cesium can retain the
    // altitude required by models and situation primitives.
    if (Number.isFinite(Number(object.position[2]))) next.position.push(Number(object.position[2]));
  }

  return next;
}

export function normalizeLayer(layer = {}) {
  if (!layer.id) return null;
  return {
    ...clone(layer),
    id: String(layer.id),
    visible: layer.visible !== false,
    opacity: Number.isFinite(Number(layer.opacity)) ? Number(layer.opacity) : layer.opacity,
  };
}

export function normalizeTemporalObject(object = {}) {
  if (!object.id) return null;
  const keyframes = (Array.isArray(object.keyframes) ? object.keyframes : [])
    .map((keyframe) => ({
      ...clone(keyframe),
      time: normalizeTime(keyframe?.time),
      position: normalizePosition(keyframe?.position),
      properties: { ...(keyframe?.properties || {}) },
      style: { ...(keyframe?.style || {}) },
    }))
    .filter((keyframe) => Number.isFinite(keyframe.time))
    .sort((a, b) => a.time - b.time);

  return {
    ...clone(object),
    id: String(object.id),
    type: object.type || "marker",
    keyframes,
    properties: { ...(object.properties || {}) },
    style: { ...(object.style || {}) },
  };
}

function normalizePosition(position) {
  if (!isLngLat(position)) return undefined;
  const next = [Number(position[0]), Number(position[1])];
  if (Number.isFinite(Number(position[2]))) next.push(Number(position[2]));
  return next;
}

export function normalizeTrack(track = {}) {
  if (!track.id) return null;
  return {
    ...clone(track),
    id: String(track.id),
    points: (Array.isArray(track.points) ? track.points : [])
      .map(normalizeTrackPoint)
      .filter(Boolean)
      .sort((a, b) => (a.time ?? 0) - (b.time ?? 0)),
    properties: { ...(track.properties || {}) },
    style: { ...(track.style || {}) },
  };
}

export function normalizeLayerGroup(group = {}) {
  if (!group.id) return null;
  return {
    ...clone(group),
    id: String(group.id),
    name: group.name || String(group.id),
    visible: group.visible !== false,
    layerIds: Array.isArray(group.layerIds) ? group.layerIds.map(String) : [],
    objectIds: Array.isArray(group.objectIds) ? group.objectIds.map(String) : [],
    properties: { ...(group.properties || {}) },
  };
}

export function normalizeState(state = {}) {
  return {
    version: Number.isFinite(Number(state.version)) ? Number(state.version) : 1,
    objects: (Array.isArray(state.objects) ? state.objects : []).map(normalizeObject).filter(Boolean),
    layers: (Array.isArray(state.layers) ? state.layers : []).map(normalizeLayer).filter(Boolean),
    temporal: (Array.isArray(state.temporal) ? state.temporal : []).map(normalizeTemporalObject).filter(Boolean),
    tracks: (Array.isArray(state.tracks) ? state.tracks : []).map(normalizeTrack).filter(Boolean),
    groups: (Array.isArray(state.groups) ? state.groups : []).map(normalizeLayerGroup).filter(Boolean),
    view: normalizeView(state.view),
  };
}

export function mergeObject(previous = {}, patch = {}) {
  const merged = {
    ...previous,
    ...patch,
    style: { ...(previous.style || {}), ...(patch.style || {}) },
    properties: { ...(previous.properties || {}), ...(patch.properties || {}) },
  };

  if (patch.geometry) merged.geometry = clone(patch.geometry);
  if (patch.position) merged.position = patch.position;

  return normalizeObject(merged);
}

export function normalizeTime(value) {
  if (value instanceof Date) return value.getTime();
  if (typeof value === "string") {
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : Number(value);
  }
  return Number(value);
}

export function normalizeTrackPoint(point = {}) {
  const position = isLngLat(point.position)
    ? point.position
    : isLngLat(point.coordinates)
      ? point.coordinates
      : isLngLat(point)
        ? point
        : null;
  if (!position) return null;
  const next = {
    ...clone(point),
    position: [Number(position[0]), Number(position[1])],
  };
  const time = normalizeTime(point.time ?? point.timestamp);
  if (Number.isFinite(time)) next.time = time;
  return next;
}
