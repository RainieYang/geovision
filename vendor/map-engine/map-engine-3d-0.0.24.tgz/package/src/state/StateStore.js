import {
  clone,
  mergeObject,
  normalizeLayer,
  normalizeLayerGroup,
  normalizeObject,
  normalizeState,
  normalizeTemporalObject,
  normalizeTrack,
  normalizeView,
} from "./utils";

export default class StateStore {
  constructor(initialState = {}) {
    this.version = 1;
    this.objectsById = new Map();
    this.layersById = new Map();
    this.temporalById = new Map();
    this.tracksById = new Map();
    this.groupsById = new Map();
    this.view = normalizeView(initialState.view);
    this.setState(initialState);
  }

  setState(state = {}) {
    const next = normalizeState(state);
    const previous = this.getState();

    this.version = next.version;
    this.objectsById = new Map(next.objects.map((object) => [object.id, object]));
    this.layersById = new Map(next.layers.map((layer) => [layer.id, layer]));
    this.temporalById = new Map(next.temporal.map((object) => [object.id, object]));
    this.tracksById = new Map(next.tracks.map((track) => [track.id, track]));
    this.groupsById = new Map(next.groups.map((group) => [group.id, group]));
    this.view = next.view;

    return this.diff(previous, this.getState());
  }

  applyPatch(patch = {}) {
    const added = [];
    const updated = [];
    const removed = [];
    const layerAdded = [];
    const layerUpdated = [];
    const layerRemoved = [];
    const temporalAdded = [];
    const temporalUpdated = [];
    const temporalRemoved = [];
    const trackAdded = [];
    const trackUpdated = [];
    const trackRemoved = [];
    const groupAdded = [];
    const groupUpdated = [];
    const groupRemoved = [];

    (Array.isArray(patch.remove) ? patch.remove : []).forEach((id) => {
      const key = String(id);
      if (this.objectsById.delete(key)) removed.push(key);
    });

    (Array.isArray(patch.add) ? patch.add : []).forEach((object) => {
      const next = normalizeObject(object);
      if (!next) return;
      this.objectsById.set(next.id, next);
      added.push(next);
    });

    (Array.isArray(patch.update) ? patch.update : []).forEach((object) => {
      if (!object?.id) return;
      const previous = this.objectsById.get(String(object.id));
      const next = mergeObject(previous || {}, object);
      if (!next) return;
      this.objectsById.set(next.id, next);
      updated.push(next);
    });

    (Array.isArray(patch.removeLayers) ? patch.removeLayers : []).forEach((id) => {
      const key = String(id);
      if (this.layersById.delete(key)) layerRemoved.push(key);
    });

    (Array.isArray(patch.addLayers) ? patch.addLayers : []).forEach((layer) => {
      const next = normalizeLayer(layer);
      if (!next) return;
      this.layersById.set(next.id, next);
      layerAdded.push(next);
    });

    (Array.isArray(patch.updateLayers) ? patch.updateLayers : []).forEach((layer) => {
      if (!layer?.id) return;
      const previous = this.layersById.get(String(layer.id)) || {};
      const next = normalizeLayer({ ...previous, ...layer });
      if (!next) return;
      this.layersById.set(next.id, next);
      layerUpdated.push(next);
    });

    (Array.isArray(patch.removeTemporal) ? patch.removeTemporal : []).forEach((id) => {
      const key = String(id);
      if (this.temporalById.delete(key)) temporalRemoved.push(key);
    });

    (Array.isArray(patch.addTemporal) ? patch.addTemporal : []).forEach((object) => {
      const next = normalizeTemporalObject(object);
      if (!next) return;
      this.temporalById.set(next.id, next);
      temporalAdded.push(next);
    });

    (Array.isArray(patch.updateTemporal) ? patch.updateTemporal : []).forEach((object) => {
      if (!object?.id) return;
      const previous = this.temporalById.get(String(object.id)) || {};
      const next = normalizeTemporalObject({ ...previous, ...object });
      if (!next) return;
      this.temporalById.set(next.id, next);
      temporalUpdated.push(next);
    });

    (Array.isArray(patch.removeTracks) ? patch.removeTracks : []).forEach((id) => {
      const key = String(id);
      if (this.tracksById.delete(key)) trackRemoved.push(key);
    });

    (Array.isArray(patch.addTracks) ? patch.addTracks : []).forEach((track) => {
      const next = normalizeTrack(track);
      if (!next) return;
      this.tracksById.set(next.id, next);
      trackAdded.push(next);
    });

    (Array.isArray(patch.updateTracks) ? patch.updateTracks : []).forEach((track) => {
      if (!track?.id) return;
      const previous = this.tracksById.get(String(track.id)) || {};
      const next = normalizeTrack({ ...previous, ...track });
      if (!next) return;
      this.tracksById.set(next.id, next);
      trackUpdated.push(next);
    });

    (Array.isArray(patch.removeGroups) ? patch.removeGroups : []).forEach((id) => {
      const key = String(id);
      if (this.groupsById.delete(key)) groupRemoved.push(key);
    });

    (Array.isArray(patch.addGroups) ? patch.addGroups : []).forEach((group) => {
      const next = normalizeLayerGroup(group);
      if (!next) return;
      this.groupsById.set(next.id, next);
      groupAdded.push(next);
    });

    (Array.isArray(patch.updateGroups) ? patch.updateGroups : []).forEach((group) => {
      if (!group?.id) return;
      const previous = this.groupsById.get(String(group.id)) || {};
      const next = normalizeLayerGroup({ ...previous, ...group });
      if (!next) return;
      this.groupsById.set(next.id, next);
      groupUpdated.push(next);
    });

    if (patch.view) {
      this.view = normalizeView({ ...this.view, ...patch.view });
    }

    this.version += 1;

    return {
      objects: { added, updated, removed },
      layers: { added: layerAdded, updated: layerUpdated, removed: layerRemoved },
      temporal: { added: temporalAdded, updated: temporalUpdated, removed: temporalRemoved },
      tracks: { added: trackAdded, updated: trackUpdated, removed: trackRemoved },
      groups: { added: groupAdded, updated: groupUpdated, removed: groupRemoved },
      viewChanged: Boolean(patch.view),
    };
  }

  getState() {
    return {
      version: this.version,
      objects: Array.from(this.objectsById.values()).map(clone),
      layers: Array.from(this.layersById.values()).map(clone),
      temporal: Array.from(this.temporalById.values()).map(clone),
      tracks: Array.from(this.tracksById.values()).map(clone),
      groups: Array.from(this.groupsById.values()).map(clone),
      view: clone(this.view),
    };
  }

  getObject(id) {
    return clone(this.objectsById.get(String(id)) || null);
  }

  listObjects() {
    return Array.from(this.objectsById.values()).map(clone);
  }

  getTrack(id) {
    return clone(this.tracksById.get(String(id)) || null);
  }

  listTracks() {
    return Array.from(this.tracksById.values()).map(clone);
  }

  getLayerGroup(id) {
    return clone(this.groupsById.get(String(id)) || null);
  }

  listLayerGroups() {
    return Array.from(this.groupsById.values()).map(clone);
  }

  diff(previous, next) {
    const previousObjects = new Map(previous.objects.map((object) => [object.id, object]));
    const nextObjects = new Map(next.objects.map((object) => [object.id, object]));
    const previousLayers = new Map(previous.layers.map((layer) => [layer.id, layer]));
    const nextLayers = new Map(next.layers.map((layer) => [layer.id, layer]));
    const previousTemporal = new Map(previous.temporal.map((object) => [object.id, object]));
    const nextTemporal = new Map(next.temporal.map((object) => [object.id, object]));
    const previousTracks = new Map(previous.tracks.map((track) => [track.id, track]));
    const nextTracks = new Map(next.tracks.map((track) => [track.id, track]));
    const previousGroups = new Map(previous.groups.map((group) => [group.id, group]));
    const nextGroups = new Map(next.groups.map((group) => [group.id, group]));

    return {
      objects: {
        added: next.objects.filter((object) => !previousObjects.has(object.id)),
        updated: next.objects.filter((object) => previousObjects.has(object.id)),
        removed: previous.objects.filter((object) => !nextObjects.has(object.id)).map((object) => object.id),
      },
      layers: {
        added: next.layers.filter((layer) => !previousLayers.has(layer.id)),
        updated: next.layers.filter((layer) => previousLayers.has(layer.id)),
        removed: previous.layers.filter((layer) => !nextLayers.has(layer.id)).map((layer) => layer.id),
      },
      temporal: {
        added: next.temporal.filter((object) => !previousTemporal.has(object.id)),
        updated: next.temporal.filter((object) => previousTemporal.has(object.id)),
        removed: previous.temporal.filter((object) => !nextTemporal.has(object.id)).map((object) => object.id),
      },
      tracks: {
        added: next.tracks.filter((track) => !previousTracks.has(track.id)),
        updated: next.tracks.filter((track) => previousTracks.has(track.id)),
        removed: previous.tracks.filter((track) => !nextTracks.has(track.id)).map((track) => track.id),
      },
      groups: {
        added: next.groups.filter((group) => !previousGroups.has(group.id)),
        updated: next.groups.filter((group) => previousGroups.has(group.id)),
        removed: previous.groups.filter((group) => !nextGroups.has(group.id)).map((group) => group.id),
      },
      viewChanged: JSON.stringify(previous.view) !== JSON.stringify(next.view),
    };
  }
}
