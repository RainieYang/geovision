import CesiumHeatmapAdapter from "./CesiumHeatmapAdapter";
import OpenLayersHeatmapAdapter from "./OpenLayersHeatmapAdapter";
import {
  cloneHeatmapPoint,
  exportHeatmapCollection,
  importHeatmapCollection,
  normalizeHeatmapOptions,
  normalizeHeatmapPoint,
  normalizeHeatmapPoints,
} from "./heatmapUtils";

export default class HeatmapManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = normalizeHeatmapOptions(options);
    this.visible = this.options.visible !== false;
    this.points = new Map();
    this.adapter = this.createAdapter(engine, this.options);
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumHeatmapAdapter(engine, options)
      : new OpenLayersHeatmapAdapter(engine, options);
  }

  setData(points = [], options = {}) {
    this.options = normalizeHeatmapOptions({ ...this.options, ...options });
    this.visible = this.options.visible !== false;
    this.points.clear();
    normalizeHeatmapPoints(points).forEach((point) => this.points.set(point.id, point));
    this.render();
    this.emit("heatmap:update", this.exportHeatmap());
    return this.exportHeatmap();
  }

  addPoint(point) {
    const normalized = normalizeHeatmapPoint(point, this.points.size);
    if (!normalized) return null;
    this.points.set(normalized.id, normalized);
    this.render();
    this.emit("heatmap:update", this.exportHeatmap());
    return cloneHeatmapPoint(normalized);
  }

  addPoints(points = []) {
    if (!Array.isArray(points)) return [];
    const added = points.map((point) => this.addPoint(point)).filter(Boolean);
    return added;
  }

  updatePoint(id, patch = {}) {
    const existing = this.points.get(id);
    if (!existing) return null;
    const normalized = normalizeHeatmapPoint({ ...existing, ...patch, id }, this.points.size);
    if (!normalized) return null;
    this.points.set(id, normalized);
    this.render();
    this.emit("heatmap:update", this.exportHeatmap());
    return cloneHeatmapPoint(normalized);
  }

  removePoint(id) {
    const existing = this.points.get(id);
    if (!existing) return null;
    this.points.delete(id);
    this.render();
    this.emit("heatmap:update", this.exportHeatmap());
    return cloneHeatmapPoint(existing);
  }

  clear() {
    this.points.clear();
    this.render();
    this.emit("heatmap:clear", this.exportHeatmap());
  }

  show() {
    this.visible = true;
    this.options = normalizeHeatmapOptions({ ...this.options, visible: true });
    this.render();
    this.emit("heatmap:show", this.exportHeatmap());
    return this.exportHeatmap();
  }

  hide() {
    this.visible = false;
    this.options = normalizeHeatmapOptions({ ...this.options, visible: false });
    this.render();
    this.emit("heatmap:hide", this.exportHeatmap());
    return this.exportHeatmap();
  }

  setOptions(options = {}) {
    this.options = normalizeHeatmapOptions({ ...this.options, ...options });
    this.visible = this.options.visible !== false;
    this.render();
    this.emit("heatmap:update", this.exportHeatmap());
    return this.exportHeatmap();
  }

  listPoints() {
    return Array.from(this.points.values()).map((point) => cloneHeatmapPoint(point));
  }

  exportHeatmap() {
    return exportHeatmapCollection(this.listPoints(), this.options, this.visible);
  }

  importHeatmap(data) {
    const next = importHeatmapCollection(data);
    this.options = next.options;
    this.visible = next.visible;
    this.points.clear();
    next.points.forEach((point) => this.points.set(point.id, point));
    this.render();
    return this.exportHeatmap();
  }

  render() {
    this.adapter?.render?.(this.listPoints(), { ...this.options, visible: this.visible });
    this.mapEngine.heatmapStore = this.exportHeatmap();
  }

  destroy() {
    this.adapter?.destroy();
    this.adapter = null;
  }

  emit(eventName, payload) {
    this.mapEngine.emitLocal?.(eventName, payload);
  }
}
