import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import HeatmapLayer from "ol/layer/Heatmap";
import VectorSource from "ol/source/Vector";
import { fromLonLat } from "ol/proj";

export default class OpenLayersHeatmapAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new HeatmapLayer({
      source: this.source,
      blur: options.blur,
      radius: options.radius,
      gradient: options.gradient,
      weight: (feature) => feature.get("weight") ?? 1,
      zIndex: options.zIndex,
    });
    this.layer.setOpacity(options.opacity);
    this.layer.setVisible(options.visible !== false);
    this.map.addLayer(this.layer);
  }

  render(points = [], options = {}) {
    this.applyOptions(options);
    this.source.clear();

    if (options.visible === false) return;

    points.forEach((point) => {
      const feature = new Feature({
        geometry: new Point(fromLonLat(point.position)),
        weight: point.weight,
        heatmapPoint: point,
      });
      feature.setId(point.id);
      this.source.addFeature(feature);
    });
  }

  applyOptions(options = {}) {
    if (!this.layer) return;
    this.layer.setBlur(options.blur);
    this.layer.setRadius(options.radius);
    if (options.gradient) this.layer.setGradient(options.gradient);
    this.layer.setOpacity(options.opacity);
    this.layer.setZIndex(options.zIndex);
    this.layer.setVisible(options.visible !== false);
  }

  destroy() {
    this.source?.clear();
    if (this.map && this.layer) this.map.removeLayer(this.layer);
    this.source = null;
    this.layer = null;
    this.map = null;
  }
}
