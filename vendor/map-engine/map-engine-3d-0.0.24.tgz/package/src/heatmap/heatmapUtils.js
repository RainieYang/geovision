export const DEFAULT_HEATMAP_OPTIONS = {
  visible: true,
  radius: 28,
  blur: 18,
  opacity: 0.72,
  gradient: ["rgba(0,0,255,0)", "#22c55e", "#facc15", "#ef4444"],
  zIndex: 1160,
  canvasSize: 512,
};

export function normalizeHeatmapOptions(options = {}) {
  const radius = readPositiveNumber(options.radius, DEFAULT_HEATMAP_OPTIONS.radius);
  const blur = readPositiveNumber(options.blur, DEFAULT_HEATMAP_OPTIONS.blur);
  const opacity = clamp(readNumber(options.opacity, DEFAULT_HEATMAP_OPTIONS.opacity), 0, 1);
  const zIndex = Math.trunc(readNumber(options.zIndex, DEFAULT_HEATMAP_OPTIONS.zIndex));
  const canvasSize = Math.max(128, Math.min(2048, Math.trunc(readNumber(options.canvasSize, DEFAULT_HEATMAP_OPTIONS.canvasSize))));
  const gradient = Array.isArray(options.gradient) && options.gradient.length >= 2
    ? options.gradient.map((color) => String(color)).filter(Boolean)
    : DEFAULT_HEATMAP_OPTIONS.gradient;

  return {
    ...DEFAULT_HEATMAP_OPTIONS,
    ...options,
    visible: options.visible !== false,
    radius,
    blur,
    opacity,
    gradient,
    zIndex,
    canvasSize,
  };
}

export function normalizeHeatmapPoint(point, index = 0) {
  if (!point || typeof point !== "object") return null;

  const position = Array.isArray(point.position)
    ? point.position
    : [point.lng ?? point.lon ?? point.longitude, point.lat ?? point.latitude];
  const lng = Number(position[0]);
  const lat = Number(position[1]);

  if (!Number.isFinite(lng) || !Number.isFinite(lat) || Math.abs(lng) > 180 || Math.abs(lat) > 90) {
    console.warn("HeatmapManager: point.position is invalid", point);
    return null;
  }

  const weight = clamp(readNumber(point.weight, 1), 0, 1);
  const id = point.id || `heatmap-point-${index + 1}`;

  return {
    ...point,
    id,
    position: [lng, lat],
    weight,
    data: { ...(point.data || {}) },
  };
}

export function normalizeHeatmapPoints(points = []) {
  if (!Array.isArray(points)) return [];
  return points.map((point, index) => normalizeHeatmapPoint(point, index)).filter(Boolean);
}

export function cloneHeatmapPoint(point) {
  return {
    ...point,
    position: [...point.position],
    data: { ...(point.data || {}) },
  };
}

export function exportHeatmapCollection(points = [], options = {}, visible = true) {
  return {
    type: "HeatmapCollection",
    visible,
    options: normalizeHeatmapOptions({ ...options, visible }),
    points: points.map((point) => cloneHeatmapPoint(point)),
  };
}

export function importHeatmapCollection(data) {
  const points = Array.isArray(data) ? data : data?.points;
  const options = normalizeHeatmapOptions(data?.options || {});
  const visible = data?.visible ?? options.visible;
  return {
    visible: visible !== false,
    options: { ...options, visible: visible !== false },
    points: normalizeHeatmapPoints(points || []),
  };
}

export function getHeatmapBounds(points = []) {
  if (!points.length) return null;

  const lngs = points.map((point) => point.position[0]);
  const lats = points.map((point) => point.position[1]);
  let west = Math.min(...lngs);
  let east = Math.max(...lngs);
  let south = Math.min(...lats);
  let north = Math.max(...lats);

  const lngSpan = Math.max(east - west, 0.01);
  const latSpan = Math.max(north - south, 0.01);
  const paddingLng = lngSpan * 0.2;
  const paddingLat = latSpan * 0.2;

  west = clamp(west - paddingLng, -180, 180);
  east = clamp(east + paddingLng, -180, 180);
  south = clamp(south - paddingLat, -90, 90);
  north = clamp(north + paddingLat, -90, 90);

  if (west === east) {
    west = clamp(west - 0.005, -180, 180);
    east = clamp(east + 0.005, -180, 180);
  }

  if (south === north) {
    south = clamp(south - 0.005, -90, 90);
    north = clamp(north + 0.005, -90, 90);
  }

  return { west, south, east, north };
}

function readPositiveNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : fallback;
}

function readNumber(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
