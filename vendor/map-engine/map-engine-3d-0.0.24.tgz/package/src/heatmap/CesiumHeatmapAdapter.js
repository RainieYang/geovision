import { getHeatmapBounds } from "./heatmapUtils";

export default class CesiumHeatmapAdapter {
  constructor(engine) {
    this.engine = engine;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.imageryLayer = null;
    this.points = [];
    this.options = {};
    this.bounds = null;
    this.currentCanvasKey = "";
    this.renderTimer = null;
    this.postRenderListener = null;
    this.pendingImageryLayer = null;
    this.renderSerial = 0;
  }

  render(points = [], options = {}) {
    this.points = points;
    this.options = options;
    this.bounds = this.getRenderBounds(points, options);

    if (!this.viewer || options.visible === false || !points.length || !this.bounds) {
      this.unbindCameraEvents();
      this.clear();
      return;
    }

    this.bindCameraEvents();
    this.renderNow();
  }

  renderNow() {
    if (!this.viewer || this.options.visible === false || !this.points.length || !this.bounds) return;

    try {
      const canvasSize = this.getCanvasSize(this.bounds, this.options);
      this.currentCanvasKey = this.getRenderKey(this.bounds, canvasSize);
      const canvas = this.createCanvas(this.points, this.bounds, this.options, canvasSize);
      const renderSerial = (this.renderSerial += 1);

      const provider = new this.CesiumLib.SingleTileImageryProvider({
        url: canvas.toDataURL("image/png"),
        rectangle: this.CesiumLib.Rectangle.fromDegrees(this.bounds.west, this.bounds.south, this.bounds.east, this.bounds.north),
      });

      const nextLayer = this.viewer.imageryLayers.addImageryProvider(provider);
      const previousPendingLayer = this.pendingImageryLayer;
      this.pendingImageryLayer = nextLayer;
      nextLayer.alpha = 0;
      nextLayer.show = this.options.visible !== false;
      this.removeLayer(previousPendingLayer);

      this.whenProviderReady(provider, () => {
        if (renderSerial !== this.renderSerial || !this.viewer || this.options.visible === false) {
          this.removeLayer(nextLayer);
          return;
        }

        const previousLayer = this.imageryLayer;
        this.imageryLayer = nextLayer;
        this.pendingImageryLayer = null;
        nextLayer.alpha = this.options.opacity;
        nextLayer.show = true;
        this.removeLayer(previousLayer);
        this.viewer.scene.requestRender?.();
      });

      this.viewer.scene.requestRender?.();
    } catch (error) {
      console.warn("CesiumHeatmapAdapter: render failed", error);
    }
  }

  scheduleRender() {
    if (this.renderTimer || !this.viewer || !this.bounds) return;
    const setTimer = typeof window !== "undefined" ? window.setTimeout : setTimeout;
    this.renderTimer = setTimer(() => {
      this.renderTimer = null;
      this.renderNow();
    }, 80);
  }

  bindCameraEvents() {
    if (this.postRenderListener || !this.viewer?.scene?.postRender) return;
    this.postRenderListener = () => {
      if (!this.bounds || !this.points.length || this.options.visible === false) return;
      const nextBounds = this.getRenderBounds(this.points, this.options);
      if (!nextBounds) return;
      const nextSize = this.getCanvasSize(nextBounds, this.options);
      const nextKey = this.getRenderKey(nextBounds, nextSize);
      if (nextKey !== this.currentCanvasKey) {
        this.bounds = nextBounds;
        this.scheduleRender();
      }
    };
    this.viewer.scene.postRender.addEventListener(this.postRenderListener);
  }

  unbindCameraEvents() {
    if (this.renderTimer && typeof window !== "undefined") {
      window.clearTimeout(this.renderTimer);
      this.renderTimer = null;
    }
    if (this.postRenderListener && this.viewer?.scene?.postRender) {
      this.viewer.scene.postRender.removeEventListener(this.postRenderListener);
    }
    this.postRenderListener = null;
    this.currentCanvasKey = "";
  }

  getCanvasSize(bounds, options = {}) {
    const fallback = Math.max(128, Math.min(2048, Number(options.canvasSize) || 512));
    const maxSize = Math.max(fallback, Math.min(4096, Number(options.maxCanvasSize) || 2048));
    const minSize = Math.min(256, fallback);
    const redrawStep = Math.max(16, Number(options.redrawStep) || 64);
    const screenBounds = this.getScreenBounds(bounds);

    if (!screenBounds) {
      return { width: fallback, height: fallback };
    }

    return {
      width: this.quantizeSize(screenBounds.width, minSize, maxSize, redrawStep),
      height: this.quantizeSize(screenBounds.height, minSize, maxSize, redrawStep),
      screenWidth: screenBounds.width,
      screenHeight: screenBounds.height,
    };
  }

  quantizeSize(value, minSize, maxSize, redrawStep) {
    const size = Math.ceil(Math.max(minSize, value) / redrawStep) * redrawStep;
    return Math.max(minSize, Math.min(maxSize, size));
  }

  getRenderKey(bounds, canvasSize) {
    const roundCoord = (value) => Math.round(value * 1000) / 1000;
    return [
      `${canvasSize.width}x${canvasSize.height}`,
      roundCoord(bounds.west),
      roundCoord(bounds.south),
      roundCoord(bounds.east),
      roundCoord(bounds.north),
    ].join(":");
  }

  getScreenBounds(bounds) {
    if (!this.viewer?.scene) return null;
    const points = [
      [bounds.west, bounds.south],
      [bounds.west, bounds.north],
      [bounds.east, bounds.south],
      [bounds.east, bounds.north],
    ];
    const screenPoints = points
      .map((point) => {
        try {
          const cartesian = this.CesiumLib.Cartesian3.fromDegrees(point[0], point[1]);
          return this.viewer.scene.cartesianToCanvasCoordinates(cartesian);
        } catch {
          return null;
        }
      })
      .filter(Boolean);

    if (screenPoints.length < 2) return null;

    const xs = screenPoints.map((point) => point.x);
    const ys = screenPoints.map((point) => point.y);
    return {
      width: Math.max(...xs) - Math.min(...xs),
      height: Math.max(...ys) - Math.min(...ys),
    };
  }

  getRenderBounds(points, options = {}) {
    const bounds = getHeatmapBounds(points);
    if (!bounds) return null;

    const pixelPadding = (Number(options.radius) || 28) + (Number(options.blur) || 18);
    const centerLng = (bounds.west + bounds.east) / 2;
    const centerLat = (bounds.south + bounds.north) / 2;
    const centerScreen = this.projectLngLat([centerLng, centerLat]);

    if (!centerScreen) return bounds;

    const eastLngLat = this.pickLngLatFromScreen(centerScreen.x + pixelPadding, centerScreen.y);
    const westLngLat = this.pickLngLatFromScreen(centerScreen.x - pixelPadding, centerScreen.y);
    const northLngLat = this.pickLngLatFromScreen(centerScreen.x, centerScreen.y - pixelPadding);
    const southLngLat = this.pickLngLatFromScreen(centerScreen.x, centerScreen.y + pixelPadding);
    const lngPadding = Math.max(
      Math.abs((eastLngLat?.[0] ?? centerLng) - centerLng),
      Math.abs(centerLng - (westLngLat?.[0] ?? centerLng)),
      0.01
    );
    const latPadding = Math.max(
      Math.abs((northLngLat?.[1] ?? centerLat) - centerLat),
      Math.abs(centerLat - (southLngLat?.[1] ?? centerLat)),
      0.01
    );

    return {
      west: Math.max(-180, bounds.west - lngPadding),
      east: Math.min(180, bounds.east + lngPadding),
      south: Math.max(-90, bounds.south - latPadding),
      north: Math.min(90, bounds.north + latPadding),
    };
  }

  projectLngLat(position) {
    if (!this.viewer?.scene || !Array.isArray(position)) return null;
    try {
      const cartesian = this.CesiumLib.Cartesian3.fromDegrees(position[0], position[1]);
      return this.viewer.scene.cartesianToCanvasCoordinates(cartesian) || null;
    } catch {
      return null;
    }
  }

  pickLngLatFromScreen(x, y) {
    if (!this.viewer) return null;
    return this.engine?.getLngLatFromScreen?.(new this.CesiumLib.Cartesian2(x, y)) || null;
  }

  createCanvas(points, bounds, options, canvasSize) {
    const width = canvasSize.width;
    const height = canvasSize.height;
    const screenWidth = Math.max(1, canvasSize.screenWidth || width);
    const screenHeight = Math.max(1, canvasSize.screenHeight || height);
    const canvasScale = Math.max(width / screenWidth, height / screenHeight);
    const radius = Math.max(1, (Number(options.radius) || 28) * canvasScale);
    const blur = Math.max(1, (Number(options.blur) || 18) * canvasScale);
    const drawRadius = radius + blur;
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;

    const context = canvas.getContext("2d");
    context.clearRect(0, 0, width, height);

    points.forEach((point) => {
      const x = ((point.position[0] - bounds.west) / (bounds.east - bounds.west)) * width;
      const y = (1 - (point.position[1] - bounds.south) / (bounds.north - bounds.south)) * height;
      const gradient = context.createRadialGradient(x, y, Math.max(1, radius * 0.15), x, y, drawRadius);
      gradient.addColorStop(0, "rgba(0,0,0,1)");
      gradient.addColorStop(Math.max(0.1, radius / drawRadius), "rgba(0,0,0,0.72)");
      gradient.addColorStop(1, "rgba(0,0,0,0)");

      context.globalAlpha = point.weight;
      context.fillStyle = gradient;
      context.beginPath();
      context.arc(x, y, drawRadius, 0, Math.PI * 2);
      context.fill();
    });

    context.globalAlpha = 1;
    this.colorize(context, width, height, options.gradient);
    return canvas;
  }

  colorize(context, width, height, gradientColors = []) {
    const palette = this.createPalette(gradientColors);
    const image = context.getImageData(0, 0, width, height);
    const data = image.data;

    for (let index = 0; index < data.length; index += 4) {
      const alpha = data[index + 3];
      if (!alpha) continue;
      const paletteIndex = Math.min(255, Math.max(0, alpha)) * 4;
      data[index] = palette[paletteIndex];
      data[index + 1] = palette[paletteIndex + 1];
      data[index + 2] = palette[paletteIndex + 2];
      data[index + 3] = Math.min(230, alpha);
    }

    context.putImageData(image, 0, 0);
  }

  createPalette(colors) {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 1;
    const context = canvas.getContext("2d");
    const gradient = context.createLinearGradient(0, 0, 256, 0);
    const stops = colors.length >= 2 ? colors : ["rgba(0,0,255,0)", "#22c55e", "#facc15", "#ef4444"];
    stops.forEach((color, index) => {
      gradient.addColorStop(index / (stops.length - 1), color);
    });
    context.fillStyle = gradient;
    context.fillRect(0, 0, 256, 1);
    return context.getImageData(0, 0, 256, 1).data;
  }

  clear() {
    this.removeImageryLayer();
  }

  removeImageryLayer() {
    this.removeLayer(this.pendingImageryLayer);
    this.removeLayer(this.imageryLayer);
    this.pendingImageryLayer = null;
    this.imageryLayer = null;
  }

  removeLayer(layer) {
    if (!this.viewer || !layer) return;
    this.viewer.imageryLayers.remove(layer, true);
    this.viewer.scene.requestRender?.();
  }

  whenProviderReady(provider, callback) {
    if (provider?.readyPromise?.then) {
      provider.readyPromise.then(callback).catch(() => callback());
      return;
    }

    if (typeof window !== "undefined") {
      window.requestAnimationFrame(() => window.requestAnimationFrame(callback));
      return;
    }

    callback();
  }

  destroy() {
    this.unbindCameraEvents();
    this.clear();
    this.viewer = null;
  }
}
