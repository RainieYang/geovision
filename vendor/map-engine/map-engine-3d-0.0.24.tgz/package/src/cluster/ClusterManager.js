import CesiumClusterAdapter from "./CesiumClusterAdapter";
import OpenLayersClusterAdapter from "./OpenLayersClusterAdapter";

const DEFAULT_OPTIONS = {
  enabled: false,
  distance: 56,
  minDistance: 18,
  minClusterSize: 2,
  maxClusterZoom: 15,
};

export default class ClusterManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.enabled = Boolean(this.options.enabled);
    this.adapter = this.createAdapter(engine);

    if (this.enabled) this.adapter.enable(this.getClusterMarkers(), this.options);
  }

  createAdapter(engine) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumClusterAdapter(this.mapEngine, engine)
      : new OpenLayersClusterAdapter(this.mapEngine, engine);
  }

  enable(options = {}) {
    this.options = { ...this.options, ...options, enabled: true };
    this.enabled = true;
    this.adapter.enable(this.getClusterMarkers(), this.options);
    this.emit("cluster:enable", this.getState());
    return this.getState();
  }

  disable() {
    this.enabled = false;
    this.options = { ...this.options, enabled: false };
    this.adapter.disable();
    this.emit("cluster:disable", this.getState());
    return this.getState();
  }

  isEnabled() {
    return this.enabled;
  }

  setOptions(options = {}) {
    this.options = { ...this.options, ...options };
    if (this.enabled) this.refresh();
    return this.getState();
  }

  refresh() {
    if (!this.enabled) return this.getState();
    this.adapter.refresh(this.getClusterMarkers(), this.options);
    return this.getState();
  }

  getClusterMarkers() {
    return this.mapEngine
      .listMarkers()
      .filter((marker) => marker?.cluster !== false);
  }

  getState() {
    return {
      enabled: this.enabled,
      options: { ...this.options },
      markerCount: this.getClusterMarkers().length,
    };
  }

  destroy() {
    this.adapter?.destroy();
    this.adapter = null;
  }

  emit(eventName, payload) {
    this.mapEngine.emitLocal?.(eventName, payload);
  }
}
