import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import Cluster from "ol/source/Cluster";
import { Circle as CircleStyle, Fill, Stroke, Style, Text } from "ol/style";
import { fromLonLat, toLonLat } from "ol/proj";
import { unByKey } from "ol/Observable";

export default class OpenLayersClusterAdapter {
  constructor(mapEngine, engine) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.source = new VectorSource();
    this.clusterSource = null;
    this.layer = null;
    this.clickKey = null;
    this.pointerKey = null;
  }

  enable(markers, options) {
    if (!this.engine?.map) return;
    if (!this.layer) this.createLayer(options);
    this.engine.markerLayer?.setVisible(false);
    this.bindEvents();
    this.refresh(markers, options);
  }

  refresh(markers, options) {
    if (!this.engine?.map) return;
    if (!this.layer) this.createLayer(options);

    this.source.clear();
    markers.forEach((marker) => {
      if (!Array.isArray(marker.position) || marker.position.length < 2) return;
      const feature = new Feature({
        geometry: new Point(fromLonLat(marker.position)),
        id: marker.id,
        name: marker.name,
        popup: marker.popup || null,
        markerData: marker.data || {},
        rawMarker: marker,
      });
      feature.setId(marker.id);
      this.source.addFeature(feature);
    });

    this.clusterSource.setDistance(options.distance ?? 56);
    this.clusterSource.setMinDistance(options.minDistance ?? 18);
  }

  disable() {
    this.unbindEvents();
    this.engine?.markerLayer?.setVisible(true);
    if (this.layer) this.layer.setVisible(false);
  }

  destroy() {
    this.disable();
    if (this.layer && this.engine?.map) this.engine.map.removeLayer(this.layer);
    this.source.clear();
    this.layer = null;
    this.clusterSource = null;
  }

  createLayer(options) {
    this.clusterSource = new Cluster({
      distance: options.distance ?? 56,
      minDistance: options.minDistance ?? 18,
      source: this.source,
    });

    this.layer = new VectorLayer({
      source: this.clusterSource,
      zIndex: 1100,
      style: (feature) => this.createStyle(feature),
    });

    this.engine.map.addLayer(this.layer);
  }

  createStyle(clusterFeature) {
    const features = clusterFeature.get("features") || [];
    if (features.length === 1) {
      const marker = features[0].get("rawMarker");
      return this.engine.createMarkerStyle(marker);
    }

    const count = String(features.length);
    const radius = Math.min(28, 15 + Math.log(features.length) * 4);

    return new Style({
      image: new CircleStyle({
        radius,
        fill: new Fill({ color: "rgba(14, 165, 233, 0.86)" }),
        stroke: new Stroke({ color: "rgba(255, 255, 255, 0.92)", width: 2 }),
      }),
      text: new Text({
        text: count,
        font: "700 13px Arial, Microsoft YaHei, sans-serif",
        fill: new Fill({ color: "#ffffff" }),
      }),
    });
  }

  bindEvents() {
    if (this.clickKey || !this.engine?.map) return;

    this.clickKey = this.engine.map.on("singleclick", (event) => {
      const clusterFeature = this.engine.map.forEachFeatureAtPixel(
        event.pixel,
        (feature) => feature,
        {
          layerFilter: (layer) => layer === this.layer,
          hitTolerance: 8,
        }
      );

      if (!clusterFeature) return;
      const features = clusterFeature.get("features") || [];
      if (features.length === 1) {
        const markerFeature = features[0];
        const marker = markerFeature.get("rawMarker") || {};
        this.engine.emit("click", {
          type: "marker",
          target: markerFeature,
          id: marker.id,
          name: marker.name,
          lnglat: toLonLat(event.coordinate),
          screenPosition: event.pixel,
          originalEvent: event,
        });
        this.engine.showMarkerPopup(markerFeature, event.pixel, marker.popup);
        return;
      }

      const center = toLonLat(clusterFeature.getGeometry().getCoordinates());
      const payload = {
        count: features.length,
        center,
        markers: features.map((feature) => feature.get("rawMarker")),
        originalEvent: event,
      };

      this.mapEngine.emitLocal("cluster:click", payload);
      this.expand(center);
      this.mapEngine.emitLocal("cluster:expand", payload);
    });

    this.pointerKey = this.engine.map.on("pointermove", (event) => {
      const hit = this.engine.map.hasFeatureAtPixel(event.pixel, {
        layerFilter: (layer) => layer === this.layer,
        hitTolerance: 8,
      });
      const target = this.engine.map.getTargetElement();
      if (target && hit) target.style.cursor = "pointer";
    });
  }

  unbindEvents() {
    if (this.clickKey) {
      unByKey(this.clickKey);
      this.clickKey = null;
    }
    if (this.pointerKey) {
      unByKey(this.pointerKey);
      this.pointerKey = null;
    }
  }

  expand(center) {
    const view = this.engine.map?.getView();
    if (!view) return;
    const zoom = view.getZoom() ?? 10;
    view.animate({
      center: fromLonLat(center),
      zoom: Math.min(zoom + 2, 18),
      duration: 260,
    });
  }
}
