export default class CesiumClusterAdapter {
  constructor(mapEngine, engine) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.entities = new Map();
    this.cameraListener = null;
    this.markers = [];
    this.options = {};
  }

  enable(markers, options) {
    if (!this.engine?.viewer) return;
    this.options = options;
    this.bindCamera();
    this.refresh(markers, options);
  }

  refresh(markers, options = this.options) {
    if (!this.engine?.viewer) return;
    this.markers = markers;
    this.options = options;
    this.clearClusterEntities();
    this.setMarkerVisibility(true);

    const clusters = this.createClusters(markers, options);
    clusters.forEach((cluster) => {
      if (cluster.markers.length < (options.minClusterSize ?? 2)) return;
      cluster.markers.forEach((marker) => this.setMarkerVisible(marker.id, false));
      this.addClusterEntity(cluster);
    });
  }

  disable() {
    this.clearClusterEntities();
    this.setMarkerVisibility(true);
    this.unbindCamera();
  }

  destroy() {
    this.disable();
  }

  bindCamera() {
    if (this.cameraListener || !this.engine?.viewer) return;
    this.cameraListener = () => this.refresh(this.markers, this.options);
    this.engine.viewer.camera.moveEnd.addEventListener(this.cameraListener);
  }

  unbindCamera() {
    if (!this.cameraListener || !this.engine?.viewer) return;
    this.engine.viewer.camera.moveEnd.removeEventListener(this.cameraListener);
    this.cameraListener = null;
  }

  createClusters(markers, options) {
    const viewer = this.engine.viewer;
    const Cesium = this.engine.CesiumLib;
    const distance = options.distance ?? 56;
    const cameraHeight = viewer.camera.positionCartographic.height;
    const zoom = this.engine.getApproxZoom(cameraHeight);
    if (zoom >= (options.maxClusterZoom ?? 15)) return [];

    const candidates = markers
      .filter((marker) => Array.isArray(marker.position) && marker.position.length >= 2)
      .map((marker) => {
        const cartesian = Cesium.Cartesian3.fromDegrees(marker.position[0], marker.position[1]);
        const screen = this.worldToScreen(cartesian);
        return screen ? { marker, screen } : null;
      })
      .filter(Boolean);

    const clusters = [];
    candidates.forEach((candidate) => {
      const cluster = clusters.find((item) => {
        const dx = item.screen.x - candidate.screen.x;
        const dy = item.screen.y - candidate.screen.y;
        return Math.sqrt(dx * dx + dy * dy) <= distance;
      });

      if (cluster) {
        cluster.items.push(candidate);
        cluster.screen.x = (cluster.screen.x * (cluster.items.length - 1) + candidate.screen.x) / cluster.items.length;
        cluster.screen.y = (cluster.screen.y * (cluster.items.length - 1) + candidate.screen.y) / cluster.items.length;
      } else {
        clusters.push({ items: [candidate], screen: { ...candidate.screen } });
      }
    });

    return clusters.map((cluster) => {
      const clusterMarkers = cluster.items.map((item) => item.marker);
      return {
        markers: clusterMarkers,
        center: getCenter(clusterMarkers),
      };
    });
  }

  addClusterEntity(cluster) {
    const Cesium = this.engine.CesiumLib;
    const id = `cluster-${cluster.markers.map((marker) => marker.id).join("-")}`;
    const entity = this.engine.viewer.entities.add({
      id,
      name: `${cluster.markers.length} 个点位`,
      position: Cesium.Cartesian3.fromDegrees(cluster.center[0], cluster.center[1]),
      point: {
        pixelSize: Math.min(46, 28 + Math.log(cluster.markers.length) * 5),
        color: Cesium.Color.fromCssColorString("rgba(14, 165, 233, 0.86)"),
        outlineColor: Cesium.Color.WHITE,
        outlineWidth: 2,
        heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: 0,
      },
      label: {
        text: String(cluster.markers.length),
        font: "700 14px sans-serif",
        fillColor: Cesium.Color.WHITE,
        style: Cesium.LabelStyle.FILL,
        pixelOffset: new Cesium.Cartesian2(0, 5),
        heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: 0,
      },
      properties: {
        clusterData: {
          count: cluster.markers.length,
          center: cluster.center,
          markers: cluster.markers,
        },
      },
    });
    this.entities.set(id, entity);
  }

  handleClusterClick(entity, movement) {
    const data = entity.properties?.clusterData?.getValue?.() || entity.properties?.clusterData;
    if (!data) return false;
    const payload = {
      count: data.count,
      center: data.center,
      markers: data.markers,
      originalEvent: movement,
    };
    this.mapEngine.emitLocal("cluster:click", payload);
    this.expand(data.center);
    this.mapEngine.emitLocal("cluster:expand", payload);
    return true;
  }

  isClusterEntity(entity) {
    return Boolean(entity?.properties?.clusterData);
  }

  expand(center) {
    const viewer = this.engine.viewer;
    const Cesium = this.engine.CesiumLib;
    if (!viewer || !Array.isArray(center)) return;
    const height = Math.max(1500, viewer.camera.positionCartographic.height * 0.38);
    viewer.camera.flyTo({
      destination: Cesium.Cartesian3.fromDegrees(center[0], center[1], height),
      orientation: {
        heading: 0,
        pitch: Cesium.Math.toRadians(-90),
        roll: 0,
      },
      duration: 0.45,
    });
  }

  worldToScreen(cartesian) {
    const viewer = this.engine?.viewer;
    const Cesium = this.engine?.CesiumLib;
    if (!viewer || !Cesium || !cartesian) return null;

    try {
      if (typeof Cesium.SceneTransforms?.wgs84ToWindowCoordinates === "function") {
        return Cesium.SceneTransforms.wgs84ToWindowCoordinates(viewer.scene, cartesian);
      }

      if (typeof Cesium.SceneTransforms?.worldToWindowCoordinates === "function") {
        return Cesium.SceneTransforms.worldToWindowCoordinates(viewer.scene, cartesian);
      }

      if (typeof viewer.scene?.cartesianToCanvasCoordinates === "function") {
        return viewer.scene.cartesianToCanvasCoordinates(cartesian);
      }
    } catch (error) {
      console.warn("CesiumClusterAdapter: world to screen failed", error);
    }

    return null;
  }

  setMarkerVisibility(visible) {
    this.markers.forEach((marker) => this.setMarkerVisible(marker.id, visible));
  }

  setMarkerVisible(id, visible) {
    const entity = this.engine.markers.get(id);
    if (entity) entity.show = visible;
  }

  clearClusterEntities() {
    this.entities.forEach((entity) => this.engine.viewer?.entities.remove(entity));
    this.entities.clear();
  }
}

function getCenter(markers) {
  const sum = markers.reduce((result, marker) => {
    result[0] += marker.position[0];
    result[1] += marker.position[1];
    return result;
  }, [0, 0]);
  return [sum[0] / markers.length, sum[1] / markers.length];
}
