import { createFeature, createFeatureCollection, enrichMeasurements, getGeometryCenter, normalizeFeatureCollection } from "../draw/geojson";

export default class CesiumMeasureAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.viewer = engine.viewer;
    this.CesiumLib = engine.CesiumLib;
    this.handler = null;
    this.mode = null;
    this.points = [];
    this.tempEntities = [];
    this.entities = new Map();
    this.features = [];
    this.onCreate = null;
    this.onClear = null;
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setClearHandler(handler) {
    this.onClear = handler;
  }

  destroy() {
    this.stop();
    this.removeAllEntities();
    this.features = [];
  }

  measureDistance(options = {}) {
    return this.start("LineString", "Distance", options);
  }

  measureArea(options = {}) {
    return this.start("Polygon", "Area", options);
  }

  start(mode, measureType, options = {}) {
    this.stop();
    this.mode = mode;
    this.points = [];
    this.handler = new this.CesiumLib.ScreenSpaceEventHandler(this.viewer.scene.canvas);
    this.viewer.scene.canvas.style.cursor = "crosshair";
    this.viewer.scene.canvas.oncontextmenu = (event) => event.preventDefault();

    this.viewer.screenSpaceEventHandler.removeInputAction(
      this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK
    );

    this.handler.setInputAction((movement) => {
      const point = this.getLngLatFromScreen(movement.position);
      if (!point) return;

      this.points.push(point);
      this.renderTempPoint(point);
      this.renderTempShape(mode);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_CLICK);

    this.handler.setInputAction(() => {
      const feature = this.createMeasureFeature(mode, measureType, options);
      if (feature) this.finish(feature);
    }, this.CesiumLib.ScreenSpaceEventType.LEFT_DOUBLE_CLICK);

    this.handler.setInputAction(() => this.cancelCurrentSketch(), this.CesiumLib.ScreenSpaceEventType.RIGHT_CLICK);
    return this;
  }

  stop() {
    if (this.handler) {
      this.handler.destroy();
      this.handler = null;
    }

    this.mode = null;
    this.points = [];
    this.clearTempEntities();

    if (this.viewer?.scene?.canvas) {
      this.viewer.scene.canvas.style.cursor = "";
      this.viewer.scene.canvas.oncontextmenu = null;
    }
  }

  createMeasureFeature(mode, measureType, options = {}) {
    if (mode === "LineString" && this.points.length >= 2) {
      return createFeature(
        { type: "LineString", coordinates: [...this.points] },
        {
          id: options.id,
          measureRole: "measure",
          measureType,
          ...(options.properties || {}),
        }
      );
    }

    if (mode === "Polygon" && this.points.length >= 3) {
      return createFeature(
        { type: "Polygon", coordinates: [[...this.points, this.points[0]]] },
        {
          id: options.id,
          measureRole: "measure",
          measureType,
          ...(options.properties || {}),
        }
      );
    }

    return null;
  }

  finish(feature) {
    const nextFeature = enrichMeasurements(feature);
    this.features.push(nextFeature);
    this.clearTempEntities();
    this.renderFeature(nextFeature);
    this.onCreate?.(nextFeature);
    this.points = [];
    this.viewer.scene.requestRender?.();
    return nextFeature;
  }

  clear() {
    this.stop();
    this.removeAllEntities();
    this.features = [];
    this.viewer.scene.requestRender?.();
    this.onClear?.();
  }

  exportGeoJSON() {
    return createFeatureCollection(this.features.map((feature) => ({
      type: "Feature",
      geometry: feature.geometry,
      properties: { ...feature.properties },
    })));
  }

  importGeoJSON(geojson) {
    const collection = normalizeFeatureCollection(geojson);
    this.stop();
    this.removeAllEntities();
    this.features = collection.features.map((feature) => enrichMeasurements({
      type: "Feature",
      geometry: feature.geometry,
      properties: {
        ...(feature.properties || {}),
        measureRole: "measure",
      },
    }));
    this.features.forEach((feature) => this.renderFeature(feature));
    this.viewer.scene.requestRender?.();
    return this.exportGeoJSON();
  }

  removeAllEntities() {
    this.entities.forEach((entity) => this.viewer.entities.remove(entity));
    this.entities.clear();
  }

  listMeasurements() {
    return this.exportGeoJSON().features;
  }

  renderFeature(feature) {
    const id = feature.properties?.id || `measure-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    feature.properties = { ...(feature.properties || {}), id };
    let entity = null;

    if (feature.geometry.type === "LineString") {
      entity = this.viewer.entities.add({
        id,
        polyline: {
          positions: this.CesiumLib.Cartesian3.fromDegreesArray(feature.geometry.coordinates.flat()),
          width: 4,
          material: this.CesiumLib.Color.CYAN,
          clampToGround: true,
        },
        properties: { measureFeature: feature, measureFeatureId: id },
      });
    }

    if (feature.geometry.type === "Polygon") {
      const ring = feature.geometry.coordinates?.[0] || [];
      entity = this.viewer.entities.add({
        id,
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(ring.flat()),
          material: this.CesiumLib.Color.CYAN.withAlpha(0.22),
          outline: true,
          outlineColor: this.CesiumLib.Color.CYAN,
          heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        },
        properties: { measureFeature: feature, measureFeatureId: id },
      });
    }

    if (entity) {
      this.entities.set(id, entity);
      this.renderMeasureLabel(feature, id);
    }

    return entity;
  }

  renderMeasureLabel(feature, id) {
    const measureText = feature.properties?.measureText;
    const center = getGeometryCenter(feature.geometry);
    if (!measureText || !center) return null;

    const label = this.viewer.entities.add({
      id: `${id}-measure-label`,
      position: this.CesiumLib.Cartesian3.fromDegrees(center[0], center[1]),
      properties: { measureFeature: feature, measureFeatureId: id },
      label: {
        text: measureText,
        font: "600 14px sans-serif",
        fillColor: this.CesiumLib.Color.WHITE,
        outlineColor: this.CesiumLib.Color.BLACK,
        outlineWidth: 4,
        style: this.CesiumLib.LabelStyle.FILL_AND_OUTLINE,
        pixelOffset: new this.CesiumLib.Cartesian2(0, -14),
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });

    this.entities.set(`${id}-measure-label`, label);
    return label;
  }

  renderTempPoint(coordinate) {
    const entity = this.viewer.entities.add({
      position: this.CesiumLib.Cartesian3.fromDegrees(coordinate[0], coordinate[1]),
      point: {
        pixelSize: 7,
        color: this.CesiumLib.Color.CYAN,
        outlineColor: this.CesiumLib.Color.WHITE,
        outlineWidth: 2,
        heightReference: this.CesiumLib.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY,
      },
    });

    this.tempEntities.push(entity);
    this.viewer.scene.requestRender?.();
    return entity;
  }

  renderTempShape(mode) {
    this.tempEntities
      .filter((entity) => entity.__measureTempShape)
      .forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = this.tempEntities.filter((entity) => !entity.__measureTempShape);

    let entity = null;

    if (mode === "LineString" && this.points.length >= 2) {
      entity = this.viewer.entities.add({
        polyline: {
          positions: this.CesiumLib.Cartesian3.fromDegreesArray(this.points.flat()),
          width: 2,
          material: this.CesiumLib.Color.CYAN,
          clampToGround: true,
        },
      });
    }

    if (mode === "Polygon" && this.points.length >= 3) {
      const ring = [...this.points, this.points[0]];
      entity = this.viewer.entities.add({
        polygon: {
          hierarchy: this.CesiumLib.Cartesian3.fromDegreesArray(ring.flat()),
          material: this.CesiumLib.Color.CYAN.withAlpha(0.16),
          outline: true,
          outlineColor: this.CesiumLib.Color.CYAN,
        },
      });
    }

    if (entity) {
      entity.__measureTempShape = true;
      this.tempEntities.push(entity);
      this.viewer.scene.requestRender?.();
    }
  }

  clearTempEntities() {
    this.tempEntities.forEach((entity) => this.viewer.entities.remove(entity));
    this.tempEntities = [];
  }

  cancelCurrentSketch() {
    this.points = [];
    this.clearTempEntities();
    this.viewer.scene.requestRender?.();
  }

  getLngLatFromScreen(screenPosition) {
    if (!screenPosition) return null;

    const groundPoint = this.engine.pickGroundLngLat?.(screenPosition);
    if (groundPoint) return groundPoint;

    let cartesian = null;

    if (!cartesian) {
      const ray = this.viewer.camera.getPickRay(screenPosition);
      cartesian = ray ? this.viewer.scene.globe.pick(ray, this.viewer.scene) : null;
    }

    if (!cartesian && this.viewer.scene.pickPositionSupported) {
      try {
        cartesian = this.viewer.scene.pickPosition(screenPosition);
      } catch (error) {
        cartesian = null;
      }
    }

    if (!cartesian) {
      cartesian = this.viewer.camera.pickEllipsoid(
        screenPosition,
        this.viewer.scene.globe.ellipsoid
      );
    }

    if (!cartesian) return null;

    const cartographic = this.CesiumLib.Cartographic.fromCartesian(cartesian);
    return [
      this.CesiumLib.Math.toDegrees(cartographic.longitude),
      this.CesiumLib.Math.toDegrees(cartographic.latitude),
    ];
  }
}
