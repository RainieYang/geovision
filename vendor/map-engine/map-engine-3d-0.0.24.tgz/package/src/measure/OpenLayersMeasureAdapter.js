import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import Draw from "ol/interaction/Draw";
import GeoJSON from "ol/format/GeoJSON";
import { Style, Circle as CircleStyle, Fill, Stroke, Text } from "ol/style";
import { fromLonLat } from "ol/proj";
import { createFeature, enrichMeasurements, getGeometryCenter, normalizeFeatureCollection } from "../draw/geojson";

export default class OpenLayersMeasureAdapter {
  constructor(engine, options = {}) {
    this.engine = engine;
    this.options = options;
    this.map = engine.map;
    this.source = new VectorSource();
    this.layer = new VectorLayer({
      source: this.source,
      zIndex: options.zIndex ?? 1300,
      style: (feature) => this.createStyle(feature),
    });
    this.draw = null;
    this.geojson = new GeoJSON();
    this.features = [];
    this.contextMenuHandler = null;
    this.onCreate = null;
    this.onClear = null;

    this.map.addLayer(this.layer);
  }

  setCreateHandler(handler) {
    this.onCreate = handler;
  }

  setClearHandler(handler) {
    this.onClear = handler;
  }

  destroy() {
    this.stop();
    if (this.map && this.layer) this.map.removeLayer(this.layer);
    this.source.clear();
    this.features = [];
  }

  measureDistance(options = {}) {
    return this.startDraw("LineString", "Distance", options);
  }

  measureArea(options = {}) {
    return this.startDraw("Polygon", "Area", options);
  }

  startDraw(type, measureType, options = {}) {
    this.stop();

    this.draw = new Draw({
      source: this.source,
      type,
    });

    this.draw.on("drawend", (event) => {
      const feature = this.normalizeDrawnFeature(event.feature, measureType, options);
      this.features.push(feature);
      this.onCreate?.(feature);
      window.setTimeout(() => this.renderAll(), 0);
    });

    this.map.addInteraction(this.draw);
    this.bindContextCancel();
    return this;
  }

  stop() {
    if (this.draw) {
      this.map.removeInteraction(this.draw);
      this.draw = null;
    }

    if (this.contextMenuHandler) {
      this.map.getViewport().removeEventListener("contextmenu", this.contextMenuHandler);
      this.contextMenuHandler = null;
    }
  }

  bindContextCancel() {
    this.contextMenuHandler = (event) => {
      event.preventDefault();
      this.draw?.abortDrawing?.();
    };
    this.map.getViewport().addEventListener("contextmenu", this.contextMenuHandler);
  }

  normalizeDrawnFeature(olFeature, measureType, options = {}) {
    const exported = this.geojson.writeFeatureObject(olFeature, {
      featureProjection: "EPSG:3857",
      dataProjection: "EPSG:4326",
    });

    return enrichMeasurements(createFeature(exported.geometry, {
      id: options.id,
      measureRole: "measure",
      measureType,
      ...(options.properties || {}),
    }));
  }

  clear() {
    this.stop();
    this.source.clear();
    this.features = [];
    this.onClear?.();
  }

  exportGeoJSON() {
    return {
      type: "FeatureCollection",
      features: this.features.map((feature) => ({
        type: "Feature",
        geometry: feature.geometry,
        properties: { ...feature.properties },
      })),
    };
  }

  importGeoJSON(geojson) {
    const collection = normalizeFeatureCollection(geojson);
    this.stop();
    this.source.clear();
    this.features = collection.features.map((feature) => enrichMeasurements({
      type: "Feature",
      geometry: feature.geometry,
      properties: {
        ...(feature.properties || {}),
        measureRole: "measure",
      },
    }));
    this.renderAll();
    return this.exportGeoJSON();
  }

  listMeasurements() {
    return this.exportGeoJSON().features;
  }

  renderAll() {
    this.source.clear();
    this.features.forEach((feature) => this.source.addFeature(this.createOlFeature(feature)));
  }

  createOlFeature(feature) {
    const olFeature = this.geojson.readFeature(feature, {
      featureProjection: "EPSG:3857",
      dataProjection: "EPSG:4326",
    });
    olFeature.setProperties({ measureFeature: feature, ...feature.properties });
    return olFeature;
  }

  createStyle(feature) {
    const measureFeature = feature?.get("measureFeature");
    const styles = [new Style({
      image: new CircleStyle({
        radius: 5,
        fill: new Fill({ color: "rgba(56, 189, 248, 0.95)" }),
        stroke: new Stroke({ color: "#ffffff", width: 2 }),
      }),
      fill: new Fill({ color: "rgba(45, 212, 191, 0.16)" }),
      stroke: new Stroke({ color: "#38bdf8", width: 3 }),
    })];

    const measureText = measureFeature?.properties?.measureText;
    const labelCenter = getGeometryCenter(measureFeature?.geometry);
    if (measureText && labelCenter) {
      styles.push(new Style({
        geometry: new Point(fromLonLat(labelCenter)),
        text: new Text({
          text: measureText,
          font: "600 13px Arial, Microsoft YaHei, sans-serif",
          fill: new Fill({ color: "#ffffff" }),
          stroke: new Stroke({ color: "rgba(15, 23, 42, 0.92)", width: 4 }),
          offsetY: -10,
        }),
      }));
    }

    return styles;
  }
}
