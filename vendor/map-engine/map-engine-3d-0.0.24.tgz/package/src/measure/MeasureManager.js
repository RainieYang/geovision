import CesiumMeasureAdapter from "./CesiumMeasureAdapter";
import OpenLayersMeasureAdapter from "./OpenLayersMeasureAdapter";
import { createFeatureCollection, normalizeFeatureCollection } from "../draw/geojson";

export default class MeasureManager {
  constructor(mapEngine, engine, options = {}) {
    this.mapEngine = mapEngine;
    this.engine = engine;
    this.options = options;
    this.adapter = this.createAdapter(engine, options);
    this.adapter.setCreateHandler?.((feature) => this.handleCreate(feature));
    this.adapter.setClearHandler?.(() => this.handleClear());
  }

  createAdapter(engine, options) {
    return this.mapEngine.getType() === "3d"
      ? new CesiumMeasureAdapter(engine, options)
      : new OpenLayersMeasureAdapter(engine, options);
  }

  destroy() {
    this.adapter?.destroy();
    this.adapter = null;
  }

  measureDistance(options = {}) {
    this.mapEngine.drawManager?.stop?.();
    return this.adapter.measureDistance(options);
  }

  measureArea(options = {}) {
    this.mapEngine.drawManager?.stop?.();
    return this.adapter.measureArea(options);
  }

  stop() {
    return this.adapter?.stop?.();
  }

  clear() {
    this.adapter?.clear();
    this.syncStore();
    this.mapEngine.emitLocal?.("measure:clear", createFeatureCollection());
  }

  exportGeoJSON() {
    return this.adapter?.exportGeoJSON() || createFeatureCollection();
  }

  importGeoJSON(geojson) {
    return this.adapter?.importGeoJSON(normalizeFeatureCollection(geojson));
  }

  listMeasurements() {
    return this.adapter?.listMeasurements?.() || [];
  }

  handleCreate(feature) {
    this.syncStore();
    this.mapEngine.emitLocal?.("measure:create", feature);
  }

  handleClear() {
    this.syncStore();
    this.mapEngine.emitLocal?.("measure:clear", createFeatureCollection());
  }

  syncStore() {
    this.mapEngine.measureStore = this.exportGeoJSON();
  }
}
