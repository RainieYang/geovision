import { createFeatureCollection, normalizeFeatureCollection } from "../draw/geojson";

const FENCE_ROLE = "fence";
const DEFAULT_FENCE_TYPE = "taskArea";

export default class FenceManager {
  constructor(mapEngine, options = {}) {
    this.mapEngine = mapEngine;
    this.options = options;
    this.targetFenceState = new Map();
  }

  createFenceFromDrawing(id, options = {}) {
    if (!id) return null;

    const existing = this.findFenceByDrawingId(id);
    const fenceId = options.fenceId || existing?.properties?.fenceId || id;
    const nextProperties = this.createFenceProperties({
      ...existing?.properties,
      ...options,
      fenceId,
    });

    const feature = this.mapEngine.drawManager?.updateDrawingProperties(id, {
      ...nextProperties,
      ...(options.properties || {}),
    });

    if (!feature) return null;

    this.emit(existing ? "fence:update" : "fence:create", feature);
    return feature;
  }

  createFenceFromSelectedDrawing(options = {}) {
    const selected = this.mapEngine.drawManager?.getSelectedDrawing?.();
    const id = selected?.properties?.id;
    if (!id) return null;
    return this.createFenceFromDrawing(id, options);
  }

  listFences() {
    return this.getDrawings().filter((feature) => this.isFence(feature));
  }

  getFence(fenceId) {
    if (!fenceId) return null;
    return this.listFences().find((feature) => this.getFenceId(feature) === fenceId) || null;
  }

  removeFence(fenceId) {
    const feature = this.getFence(fenceId);
    if (!feature) return null;

    const removed = this.mapEngine.drawManager?.removeDrawing(feature.properties?.id);
    if (!removed) return null;

    this.removeFenceFromTargetState(fenceId);
    this.emit("fence:delete", removed);
    return removed;
  }

  enableFence(fenceId) {
    return this.setFenceEnabled(fenceId, true);
  }

  disableFence(fenceId) {
    return this.setFenceEnabled(fenceId, false);
  }

  setFenceEnabled(fenceId, enabled) {
    const feature = this.getFence(fenceId);
    if (!feature) return null;

    const updated = this.mapEngine.drawManager?.updateDrawingProperties(feature.properties?.id, {
      enabled,
      status: enabled ? "active" : "disabled",
    });

    if (!updated) return null;

    this.emit(enabled ? "fence:enable" : "fence:disable", updated);
    this.emit("fence:update", updated);
    return updated;
  }

  exportFences() {
    return createFeatureCollection(this.listFences().map((feature) => this.cloneFeature(feature)));
  }

  importFences(geojson) {
    const collection = normalizeFeatureCollection(geojson);
    const incomingFences = collection.features
      .filter((feature) => feature?.geometry)
      .map((feature) => this.normalizeFenceFeature(feature));

    const incomingFenceIds = new Set(incomingFences.map((feature) => this.getFenceId(feature)));
    const existingNonReplaced = this.getDrawings().filter((feature) => {
      if (!this.isFence(feature)) return true;
      return !incomingFenceIds.has(this.getFenceId(feature));
    });

    const result = this.mapEngine.drawManager?.importGeoJSON(
      createFeatureCollection([...existingNonReplaced, ...incomingFences])
    );

    incomingFences.forEach((feature) => this.emit("fence:create", feature));
    return result;
  }

  checkFencePoint(target = {}) {
    const position = this.normalizeTargetPosition(target);
    const targetId = target.id || target.name || "anonymous";
    const previousFenceIds = this.targetFenceState.get(targetId) || new Set();
    const insideFences = this.listFences().filter((fence) => this.isTargetInsideFence(position, fence));
    const currentFenceIds = new Set(insideFences.map((fence) => this.getFenceId(fence)));
    const enteredFences = insideFences.filter((fence) => !previousFenceIds.has(this.getFenceId(fence)));
    const leftFences = Array.from(previousFenceIds)
      .filter((fenceId) => !currentFenceIds.has(fenceId))
      .map((fenceId) => this.getFence(fenceId))
      .filter(Boolean);

    const result = {
      target,
      vehicle: target,
      insideFences,
      enteredFences,
      leftFences,
    };

    enteredFences.forEach((fence) => this.emit("fence:enter", { ...result, fence }));
    leftFences.forEach((fence) => this.emit("fence:leave", { ...result, fence }));

    this.targetFenceState.set(targetId, currentFenceIds);
    return result;
  }

  checkFencePoints(targets = []) {
    if (!Array.isArray(targets)) return [];
    return targets.map((target) => this.checkFencePoint(target));
  }

  clearTargetState(targetId) {
    if (targetId) {
      this.targetFenceState.delete(targetId);
      return;
    }

    this.targetFenceState.clear();
  }

  getDrawings() {
    return this.mapEngine.drawManager?.listDrawings?.() || [];
  }

  findFenceByDrawingId(id) {
    return this.getDrawings().find((feature) => feature.properties?.id === id && this.isFence(feature)) || null;
  }

  createFenceProperties(options = {}) {
    const enabled = options.enabled !== false;
    const fenceId = options.fenceId || options.id || `fence-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    return {
      featureRole: FENCE_ROLE,
      fenceId,
      name: options.name || "未命名围栏",
      fenceType: options.fenceType || DEFAULT_FENCE_TYPE,
      enabled,
      status: enabled ? "active" : "disabled",
      extra: options.extra || {},
    };
  }

  normalizeFenceFeature(feature) {
    const properties = {
      ...(feature.properties || {}),
    };
    const fenceProperties = this.createFenceProperties({
      ...properties,
      fenceId: properties.fenceId || properties.id,
    });

    return {
      type: "Feature",
      geometry: feature.geometry,
      properties: {
        ...properties,
        ...fenceProperties,
        id: properties.id || fenceProperties.fenceId,
      },
    };
  }

  isFence(feature) {
    return feature?.properties?.featureRole === FENCE_ROLE;
  }

  getFenceId(feature) {
    return feature?.properties?.fenceId || feature?.properties?.id || null;
  }

  isFenceEnabled(feature) {
    return feature?.properties?.enabled !== false && feature?.properties?.status !== "disabled";
  }

  isTargetInsideFence(position, fence) {
    if (!position || !this.isFenceEnabled(fence) || fence?.geometry?.type !== "Polygon") return false;

    const ring = fence.geometry.coordinates?.[0] || [];
    if (ring.length < 4) return false;

    return pointInPolygon(position, ring);
  }

  normalizeTargetPosition(target = {}) {
    const position = target.position || target.lnglat || target.coordinate || target.coordinates;
    if (!Array.isArray(position) || position.length < 2) return null;

    const lng = Number(position[0]);
    const lat = Number(position[1]);
    if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;

    return [lng, lat];
  }

  removeFenceFromTargetState(fenceId) {
    this.targetFenceState.forEach((fenceIds) => {
      fenceIds.delete(fenceId);
    });
  }

  cloneFeature(feature) {
    return {
      type: "Feature",
      geometry: JSON.parse(JSON.stringify(feature.geometry)),
      properties: JSON.parse(JSON.stringify(feature.properties || {})),
    };
  }

  emit(eventName, payload) {
    this.mapEngine.emitLocal?.(eventName, payload);
  }
}

function pointInPolygon(point, ring = []) {
  if (!point || ring.length < 4) return false;

  const x = point[0];
  const y = point[1];
  let inside = false;

  for (let i = 0, j = ring.length - 1; i < ring.length; j = i, i += 1) {
    const xi = ring[i][0];
    const yi = ring[i][1];
    const xj = ring[j][0];
    const yj = ring[j][1];
    const intersects = yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi || Number.EPSILON) + xi;

    if (intersects) inside = !inside;
  }

  return inside;
}
